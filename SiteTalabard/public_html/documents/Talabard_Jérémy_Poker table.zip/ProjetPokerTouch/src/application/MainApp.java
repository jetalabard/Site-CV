package application;

import ihm.controleur.action_menu.ActionRedimensionHeight;
import ihm.controleur.action_menu.ActionRedimensionWidth;
import ihm.vue.menu.FenetreDemarrage;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * demarrage de l'application
 * @author J�r�my
 *
 */
public class MainApp extends Application {
	/**
	 * largeur fenetre
	 */
	public Number tailleWidth;
	/**
	 * hauteur fenetre
	 */
	public Number tailleHeight;
	/*____________________________________________________________*/
	/**
	 * demarrage de l'application
	 */
	@Override
	public void start(Stage primaryStage) {
		tailleHeight=0;
		tailleWidth=0;
		lancerApplication(primaryStage);
	}
	/*____________________________________________________________*/
	/**
	 * execute l'application
	 * @param primaryStage
	 */
	private void lancerApplication(Stage primaryStage) {
		FenetreDemarrage root = new FenetreDemarrage(primaryStage);
		Scene scene = new Scene(root);
		scene= associeCssEtFont(scene);
		primaryStage = initialiseLeStage(primaryStage,scene);
		primaryStage.show();

	}

	/*____________________________________________________________*/
	/**
	 * associe le css et la font par mail
	 * @param scene
	 * @return la scene modifi�
	 */
	private Scene associeCssEtFont(Scene scene) 
	{
		scene.getStylesheets().add(getClass().getResource("../ihm/vue/application.css").toExternalForm());
		scene.getStylesheets().add(getClass().getResource("../ihm/vue/Menu.css").toExternalForm());
		return scene;
	}
	/*____________________________________________________________*/
	/**
	 * initialise le stage
	 * @param primaryStage
	 * @param scene
	 * @return
	 */
	private Stage initialiseLeStage(Stage primaryStage, Scene scene) {
		primaryStage.setHeight(1080);
		primaryStage.setWidth(1920);

		primaryStage.heightProperty().addListener(new ActionRedimensionHeight(this));		
		primaryStage.widthProperty().addListener(new ActionRedimensionWidth(this));	

		primaryStage.centerOnScreen(); 
		primaryStage.setFullScreen(true);

		primaryStage.setMinHeight(690);
		primaryStage.setMinWidth(1188);

		primaryStage.setScene(scene);
		return primaryStage;

	}
	/*____________________________________________________________*/
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		launch(args);
	}

	/*____________________________________________________________*/

	/**
	 * largeur de la fenetre
	 * @param taille
	 */
	public void setTailleWidth(Number taille){
		tailleWidth=taille;		
	}

	/*____________________________________________________________*/
	/**
	 *  hauteur de la fenetre
	 * @param taille
	 */
	public void setTailleHeight(Number taille){
		tailleHeight=taille;		
	}
}
