package application.dataloader;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import application.metier.Carte;
import application.modele.ListeCartes;

/**
 * permet de parser le fichier xml contenant la liste des cartes
 * @author J�r�my
 *
 */
public class ParserCartes extends DefaultHandler{ 
	/**
	 * liste des cartes
	 */
	private ArrayList<Carte> paquet; 
	/**
	 * une carte
	 */
	private Carte carte; 
	/**
	 * flux de lecture du fichier
	 */
	private StringBuffer buffer; 
	
	/*____________________________________________________________*/
	/**
	 * constructeur
	 */
	public ParserCartes(){ 
		super(); 
	} 
	/*____________________________________________________________*/
	/**
	 * creer le parser saxe
	 * @return parser
	 */
	private SAXParser creerParser() {
		SAXParserFactory fabrique=SAXParserFactory.newInstance();
		SAXParser parser=null;;
		try {
			parser = fabrique.newSAXParser();
		} catch (ParserConfigurationException | SAXException e) {
			e.printStackTrace();
		}
		return parser;
	}
	/*____________________________________________________________*/
	/**
	 * remplir l'objet carte avec les bonnes valeurs
	 * @param attributes
	 */
	private void remplirCarte(Attributes attributes) {
		carte.setNom(attributes.getValue("nom"));
		carte.setCouleur(attributes.getValue("couleur"));
		carte.setValeur(Integer.parseInt(attributes.getValue("valeur")));
		carte.setImage(attributes.getValue("image"));
	}
	/*____________________________________________________________*/
	/**
	 * creer les nouvelles cartes � partir des elements lu
	 */
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException{ 
		if(qName.equals("Paquet")){ 
			paquet = new ArrayList<Carte>(); 
		}else if(qName.equals("Carte")){ 
			carte = new Carte(); 
			ListeCartes.getInstance().getListeCarte().add(carte);
			try{ 
				remplirCarte(attributes);
				paquet.add(carte);
			}catch(Exception e){ 
				throw new SAXException(e); 
			} 
		}else { 
			buffer = new StringBuffer(); 
		} 
	} 
	/*____________________________________________________________*/
	/**
	 * d�tection fin de balise 
	 */
	public void endElement(String uri, String localName, String qName) throws SAXException{ 
	} 
	/*____________________________________________________________*/
	/**
	 * d�tection de caract�res 
	 */
	public void characters(char[] ch,int start, int length) 
			throws SAXException{ 
		String lecture = new String(ch,start,length); 
		if(buffer != null) buffer.append(lecture);        
	} 
	/*____________________________________________________________*/
	/**
	 * d�but du parsing 
	 */
	public void startDocument() throws SAXException { 
	} 
	/*____________________________________________________________*/
	/**
	 * fin du parsing 
	 */
	public void endDocument() throws SAXException { 
	} 
	/*____________________________________________________________*/
	/**
	 * charge le fichier xml contenant les cartes
	 */
	public void charger() {
		SAXParser parser = creerParser();
		
		File fichier=new File("./bin/application/dataloader/cartesPoker.xml");
		
		DefaultHandler handler=new ParserCartes();
		try {
			parser.parse(fichier, handler);
		} catch (SAXException | IOException e) {
			e.printStackTrace();
		}
	}
	/*____________________________________________________________*/
	
	/**
	 * retourne le paquet de carte
	 * @return
	 */
	public ArrayList<Carte> getPaquet() {
		return paquet;
	}
}
