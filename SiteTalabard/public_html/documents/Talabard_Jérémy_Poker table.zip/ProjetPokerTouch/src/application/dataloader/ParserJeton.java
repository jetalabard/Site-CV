package application.dataloader;

import ihm.vue.plateau.Dimension;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.jdom2.Attribute;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

import application.metier.Jeton;
import application.metier.Joueur;

/**
 * permet de parser le fichier des jetons pour �crire une nouvelles images de la pile
 * @author J�r�my
 *
 */
public class ParserJeton {

	/**
	 * document pars�
	 */
	private  Document documentLecture;
	/**
	 * element racine du fichier lu
	 */
	private  Element racineLecture;
	/**
	 * element courant pars�
	 */
	private  Element jetoncourant;
	/**
	 * element racine du fichier ecrit
	 */
	private  Element racineEcriture;
	/**
	 * ecrit dans un fichier
	 */
	private  FileWriter writer;
	/**
	 * Constructeur
	 */
	public ParserJeton() {
		racineEcriture=new Element("AnchorPane");
	}
	/**
	 * met � jour le document des jetons du joueur pass� en parametre
	 * @param j
	 */
	public void mettreAJourDocumentJeton(Joueur j){
		creerFichierDesJetonsDuJoueur(j.getEmplacement());
		determinerLaTailleDesPiles(j.getListeJeton());
		creerLesPilesDeJetons(j.getListeJeton(),0,false);
	}
	/**
	 * met � jour le document des jetons mis�s du joueur pass� en parametre
	 * @param j
	 */
	public void mettreAJourDocumentMisesJoueur(Joueur j){
		creerFichierDesMisesDuJoueur(j.getEmplacement());
		determinerLaTailleDesPiles(j.getListeJetonMise());
		creerLesPilesDeJetons(j.getListeJetonMise(),-1000,false);
	}
	/**
	 * met � jour le document des jetons du pot pass� en parametre
	 * @param j
	 */
	public void mettreAJourDocumentPotPrincipal(Map<String, Jeton> pot){
		creerFichierDuPotPrincipal();
		determinerLaTailleDesPiles(pot);
		creerLesPilesDeJetons(pot,-1000,true);
	}
	
	/**
	 * �crit le document
	 * @param file
	 */
	private  void creerDocument(File file) {		
		try {
			writer=new FileWriter(file);
			ajouteImporte();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * ajoute les import au document
	 */
	private void ajouteImporte() {
		try {
			writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\n");
			writer.write("<?import javafx.geometry.*?>\n");
			writer.write("<?import java.lang.*?>\n");
			writer.write("<?import javafx.scene.layout.*?>\n");
			writer.write("<?import javafx.scene.*?>\n");
			writer.write("<?import javafx.scene.shape.*?>\n");
			writer.write("<?import javafx.scene.paint.*?>\n");
			writer.write("<?import javafx.scene.image.*?>\n");
			writer.write("<?import javafx.scene.transform.*?>\n");
			writer.write("<?import javafx.scene.effect.*?>\n");
			writer.write("<?import javafx.scene.text.*?>\n\n");			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	/**
	 * cr�� un anchorpane
	 */
	private  void creerAnchorPane() {		

		creerAttributEtAjouterDansRacine("cacheShape","false");
		creerAttributEtAjouterDansRacine("centerShape","false");
		gereTaille();
		creerAttributEtAjouterDansRacine("scaleShape","false");
		creerAttributEtAjouterDansRacine("scaleX","0.6");
		creerAttributEtAjouterDansRacine("scaleY","0.6");
	}
	/**
	 * gere les tailles 
	 */
	private void gereTaille() {
		creerAttributEtAjouterDansRacine("maxHeight","-20.0");
		creerAttributEtAjouterDansRacine("maxWidth","150.0");
		creerAttributEtAjouterDansRacine("minHeight","20.0");
		creerAttributEtAjouterDansRacine("minWidth","150.0");
		creerAttributEtAjouterDansRacine("prefHeight","20.0");
		creerAttributEtAjouterDansRacine("prefWidth","150.0");

	}
	/**
	 * ajoute des elements � la racine du document
	 * @param attribut1
	 * @param attribut2
	 */
	private void creerAttributEtAjouterDansRacine(String attribut1,String attribut2) {
		Attribute attribut=new Attribute(attribut1,attribut2);
		racineEcriture.setAttribute(attribut);
	}
	/**
	 * r�cupere l'image des jetons
	 * @param string
	 */
	private void recupererImageJeton(String string){
		SAXBuilder sxb = new SAXBuilder();
		recupereDocument(sxb,string);
		racineLecture = documentLecture.getRootElement();
		List<Element> group = racineLecture.getChildren();
		Iterator<Element> i = group.iterator();
		while(i.hasNext())
		{
			jetoncourant = (Element)i.next();
		}
	}

	/**
	 * recupere le document
	 * @param sxb
	 * @param string
	 */
	private void recupereDocument(SAXBuilder sxb, String string) {
		try
		{
			String path=new String("./src/ressources/jeton/jeton_"+string+".fxml");
			documentLecture = sxb.build(new File(path));
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	/**
	 * construit l'image de la pile de jetons du joueur
	 * @param emplacement
	 */
	private void creerFichierDesJetonsDuJoueur(int emplacement) {
		File file=new File("./bin/ressources/jeton/pileJetonsJoueur_"+emplacement+".fxml");		
		creerDocument(file);
		creerAnchorPane();	
	}
	/**
	 * construit l'image de la pile de jetons mis� du joueur
	 * @param emplacement
	 */
	private void creerFichierDesMisesDuJoueur(int emplacement) {
		File file=new File("./bin/ressources/jeton/pileJetonsMises_"+emplacement+".fxml");
		creerDocument(file);
		creerAnchorPane();	
	}
	/**
	 * construit l'image de la pile de jetons du pot
	 * @param emplacement
	 */
	private void creerFichierDuPotPrincipal() {
		File file=new File("./bin/ressources/jeton/potPrincipal.fxml");
		creerDocument(file);
		creerAnchorPane();	
	}
	/**
	 * determine la taille des piles et redimensionne
	 * @param map
	 */
	private void determinerLaTailleDesPiles(Map<String, Jeton> map){
		boolean estDejaModif=false;
		for(Entry<String, Jeton> entry:map.entrySet()){
			int nombreDeCeJeton=entry.getValue().getQuantite();
			if(nombreDeCeJeton>29 && estDejaModif==false){
				Dimension.getInstance().affecterDimensionDuParser(0.3, -17, 80, 40);
				estDejaModif=true;
			}else if(estDejaModif==false){
				Dimension.getInstance().affecterDimensionDuParser(0.5, -25, 120, 30);
			}
		}
	}	
	/**
	 * construit les piles de jetons � une certaine position
	 * @param map
	 * @param posX
	 * @param pot
	 */
	private synchronized void creerLesPilesDeJetons(Map<String, Jeton> map, int posX, boolean pot){
		int positionX=posX;
		int positionXInside=posX;
		for (Entry<String,Jeton> entry:map.entrySet()){
			recupererImageJeton(entry.getKey());
			Element children=new Element("children");
			racineEcriture.addContent(children);
			int nombreDeJetons=entry.getValue().getQuantite();
			int positionY=-210;
			if(pot){
				positionY=-210-100;
			}			
			int nombreDePile=0;
			for(int i=0;i<nombreDeJetons;i++){
				if(i%Dimension.getInstance().getParserTailleDePile()==0){
					nombreDePile+=1;
					positionY=(int) (-210-(Dimension.getInstance().getParserDistanceTop()*nombreDePile));
					positionXInside=(int) (positionX+(Dimension.getInstance().getParserDistanceRight()*nombreDePile));
				}
				AjouterUnJetonIci(Dimension.getInstance().getParserScale(), positionXInside, positionY, children);	
				positionY=(int) (positionY+Dimension.getInstance().getParserDistanceTop());
			}
			positionX=(int) (positionXInside+Dimension.getInstance().getParserDistanceRight());
		}
		ecritLeDocumentDansFichier();	
	}
	/**
	 * ecrit le document dans un fichier
	 */
	private void ecritLeDocumentDansFichier() {
		try
		{
			XMLOutputter sortie = new XMLOutputter(Format.getPrettyFormat());
			sortie.output(racineEcriture, writer);
		}
		catch (java.io.IOException e){
			e.printStackTrace();
		}
	}
	/**
	 * ajoute jeton � cette position
	 * @param scale
	 * @param positionX
	 * @param positionY
	 * @param children
	 */
	private void AjouterUnJetonIci(double scale, double positionX, double positionY, Element children){
			jetoncourant.getChildren().get(0).setAttribute("layoutY",String.valueOf(positionY));
			jetoncourant.getChildren().get(0).setAttribute("layoutX",String.valueOf(positionX));
			jetoncourant.getChildren().get(0).setAttribute("scaleX",String.valueOf(scale));
			jetoncourant.getChildren().get(0).setAttribute("scaleY",String.valueOf(scale));
			children.addContent(jetoncourant.cloneContent());
			positionY=positionY-Dimension.getInstance().getParserDistanceTop();
	}

}
