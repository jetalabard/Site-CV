package application.dataloader.reseau;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Acceptation_T extends Thread {

	private Socket socket;
	private ServerSocket socketserver;
	private ArrayList<Socket> listeClients;

	private BufferedReader in;
	private PrintWriter out;

	private ArrayList<Reception_T> listeReception_T;
	private boolean threadFermer;

	public Acceptation_T(ArrayList<Socket> listeClients2, ServerSocket socketserver) {
		this.listeClients = new ArrayList<Socket>();
		this.listeClients = listeClients2;
		this.socketserver = socketserver;
		listeReception_T = new ArrayList<Reception_T>();
		threadFermer = false;
	}

	@Override
	public void run() {
		try {
			tantQueVrai();
		} catch (IOException e) {
			gereIOException(e);

		}
	}

	private void tantQueVrai() throws IOException {
		if(threadFermer ==false)
		{
			while(true){
				socket = socketserver.accept();
				listeClients.add(socket);

				try 
				{
					in = new BufferedReader(new InputStreamReader(socket.getInputStream()));			
					out = new PrintWriter(socket.getOutputStream());
					Reception_T reception_T = new Reception_T(out,in,socket);
					listeReception_T.add(reception_T);
					reception_T.start();

				} catch (IOException e) {
					gereIOException(e);
				}
			}
		}
		else {
			gereIOException(null);
		}
	}

	public void fermer() {
		if(this.getListeReception_T().size()>0)
		{
			for(Reception_T r : this.getListeReception_T())
			{
				r.fermer();
			}
		}
		listeClients = new ArrayList<Socket>();
		threadFermer = true;
	}

	private void gereIOException(IOException e) {
		e.printStackTrace();
		fermer();
	}

	public ArrayList<Reception_T> getListeReception_T() {
		return listeReception_T;
	}

	public void setListeReception_T(ArrayList<Reception_T> listeReception_T) {
		this.listeReception_T = listeReception_T;
	}

	
}
