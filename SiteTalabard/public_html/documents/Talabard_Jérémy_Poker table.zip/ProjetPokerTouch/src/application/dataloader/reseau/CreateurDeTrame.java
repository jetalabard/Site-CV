package application.dataloader.reseau;


import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import application.metier.Carte;
import application.metier.Jeton;


public class CreateurDeTrame {

	private String idTrame;
	private Object[] params;
	private JSONObject trame;

	public CreateurDeTrame(String idTrame, Object... params) {
		this.idTrame = idTrame;
		this.params = params;
		chercherTrame();
	}

	private void chercherTrame() {
		switch (idTrame) {
		case "1RJ":
			construireDonnerValeurJeton();
			break;
		case "3DO":
			construireDonnerCarte();
			break;
		case "3PE":
			construirePerdu();
			break;
		case "3PB":
			construireBlind();
			break;
		case "3GB":
			construireBlind();
			break;
		case "3KO":
			construireDefaut();
			break;
		case "3DV":
			construireDefaut();
			break;
		case "3JO":
			construireJouerEtDonnerPlusGrandeMise();
			break;
		case "3NT":
			construireDefaut();
			break;
		case "3NJ":
			construireDefaut();
			break;
		case "3GA":
			construireGagnerArgent();
			break;
		case "3CA":
			construireDonnerCartesMilieu();
			break;
		default:
			break;
		}
	}

	private void construirePerdu() {
		trame = new JSONObject();
		try {
			trame.put("idTrame", idTrame);
			trame.put("perduPartie", params[0]);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	private void construireGagnerArgent() {
		trame = new JSONObject();
		try {
			trame.put("idTrame", idTrame);
			trame.put("gagnePartie", params[0]);
			if((boolean)params[0] == false)
			{
				trame.put("argentGagne", params[6]);
				ajouteListeJetonsGagne();
			}
			
		} catch (JSONException e) {
			e.printStackTrace();
		}

	}

	private void ajouteListeJetonsGagne() {
		try {
			JSONArray jetons = new JSONArray();
			
			jetons.put(construireJeton(params[1]));
			jetons.put(construireJeton(params[2]));
			jetons.put(construireJeton(params[3]));
			jetons.put(construireJeton(params[4]));
			jetons.put(construireJeton(params[5]));
			
			trame.put("jetons",jetons);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
	}

	private void construireDonnerCartesMilieu() {
		trame = new JSONObject();
		try {
			trame.put("idTrame", idTrame);
			@SuppressWarnings("unchecked")
			ArrayList<Carte> cartes =  (ArrayList<Carte>) params[0];
			JSONArray cartesArray = new JSONArray();
			for(int i=0;i<cartes.size();i++)
			{
				cartesArray.put(construireCarte(cartes.get(i)));
			}
			trame.put("cartes",cartesArray);


		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	private void construireJouerEtDonnerPlusGrandeMise() {
		trame = new JSONObject();
		try {
			trame.put("idTrame", idTrame);
			trame.put("miseMax",params[0]);
			trame.put("peutChecker", params[1]);
		} catch (JSONException e) {
			e.printStackTrace();
		}

	}

	private void construireBlind() {
		trame = new JSONObject();
		try {
			trame.put("idTrame", idTrame);
			trame.put("somme",params[0]);
		} catch (JSONException e) {
			e.printStackTrace();
		}

	}
	private void construireDonnerValeurJeton() {
		trame = new JSONObject();
		try {
			trame.put("idTrame", idTrame);
			trame.put("estPersonnalise", params[0]);
			trame.put("argentDepart", params[1]);
			trame.put("impossible", params[2]);
			
			if((boolean)params[0] == true)
			{
				ajouteListeJetons();
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}

	}

	private void ajouteListeJetons() throws JSONException {
		JSONArray jetons = new JSONArray();
		
		jetons.put(construireJeton(params[3]));
		jetons.put(construireJeton(params[4]));
		jetons.put(construireJeton(params[5]));
		jetons.put(construireJeton(params[6]));
		jetons.put(construireJeton(params[7]));

		trame.put("jetons",jetons);
	}

	private JSONObject construireJeton(Object params2) {
		JSONObject unJeton = new JSONObject();
		try {
			unJeton.put("valeur",((Jeton) params2).getValeur());
			unJeton.put("quantite",((Jeton) params2).getQuantite());
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return unJeton;

	}

	private JSONObject construireCarte(Object params2) {

		JSONObject unJeton = new JSONObject();
		try {
			unJeton.put("carte",((Carte) params2).toString());
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return unJeton;

	}

	private void construireDonnerCarte() {
		trame = new JSONObject();
		try {
			trame.put("idTrame", idTrame);
			trame.put("carte1", params[0]);
			trame.put("carte2", params[1]);

		} catch (JSONException e) {
			e.printStackTrace();
		}

	}

	private void construireDefaut() {
		trame = new JSONObject();
		try {
			trame.put("idTrame", idTrame);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	public JSONObject getTrame() {
		return trame;
	}
}
