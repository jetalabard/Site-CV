package application.dataloader.reseau;

import ihm.controleur.action_table.ActionCliquerChargement;
import ihm.controleur.action_table.affichage.ActionAfficherMainJoueur;
import ihm.controleur.action_table.envoietelephone.ActionEnvoyerValeurJetonEtArgentAuJoueur;
import ihm.controleur.actionjoueur.Checker;
import ihm.controleur.actionjoueur.Connecter;
import ihm.controleur.actionjoueur.GererActionJoueur;
import ihm.controleur.actionjoueur.PayerBlind;
import ihm.controleur.actionjoueur.Quitter;
import ihm.controleur.actionjoueur.Relance;
import ihm.controleur.actionjoueur.SeCoucher;
import ihm.controleur.actionjoueur.Tapis;
import ihm.vue.plateau.PlateauDeJeu;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.util.Iterator;

import javafx.application.Platform;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import application.metier.Joueur;
import application.modele.Partie;

public class Reception_T extends Thread {

	private BufferedReader in;
	private PrintWriter out;

	private Socket socketClient;
	private boolean threadFermer;
	
	private boolean existe;

	public Reception_T(PrintWriter out, BufferedReader in, Socket socket){
		setExiste(false);
		threadFermer = false;
		this.in = in;
		this.out = out;
		this.socketClient = socket;
	}

	public void run() {
		while(true){
			if(threadFermer == false)
			{
				try {
					analyseMessage();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

	private void analyseMessage() throws IOException {
		try{
		String	message = in.readLine();
			if(message != null) {
				StringBuilder builder = new StringBuilder();
				builder.append(message);
				analyseDeLaTrameRecu(builder);
			} 
		}
		catch (Exception e) {
			quitter(2);
			fermer();

		}
	}

	private void analyseDeLaTrameRecu(StringBuilder builder) {
		try {
			synchronized (this) {
				analyserTrame(new JSONObject(builder.toString()));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	private void analyserTrame(JSONObject message) {
		try {
			String idTrame = (String) message.get("idTrame");
			switch (idTrame) {
			case "1RJ":
				connexion(message);
				break;
			case "1QU":
				quitter(0);
				break;
			case "2CH":
				coucher();
				break;
			case "2OB":
				recevoirBlind();
				break;
			case "2SV":
				action(socketClient,"Suivre",null);
				break;
			case "2CK":
				action(socketClient,"Checker",null);
				break;
			case "2TP":
				action(socketClient,"Tapis",null);
				break;
			case "2MI":
				relance(message);
				break;
			default:
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void coucher() {
		if(Partie.getInstance().getJeuEncours().isDevoiler() ==true)
		{
			new ActionAfficherMainJoueur(socketClient);
		}
		else {
			action(socketClient,"SeCoucher",null);
		}
	}

	private void quitter(int i) {
		
		Quitter quitte = new Quitter("Quitter");
		Joueur joueurQuiQuitte = null;
		Iterator<Joueur> iter =Partie.getInstance().getListeJoueur().iterator();
		while(iter.hasNext())
		{
			Joueur j = iter.next();
			if(j.getCommunication().getSocketClient() == socketClient)
			{
				quitte.setMode(i);
				j.setAction(quitte);
				joueurQuiQuitte = j;
			}
		}
		new GererActionJoueur(joueurQuiQuitte);
	}

	private void relance(JSONObject message) {
		try {
			action(socketClient,"Relance",message.getJSONArray("jetons"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void recevoirBlind() {
		PayerBlind payeBlind = new PayerBlind("PayerBlind");
		for(Joueur j : Partie.getInstance().getListeJoueur())
		{
			if(j.getCommunication().getSocketClient() ==socketClient)
			{
				j.setAction(payeBlind);
				new GererActionJoueur(j);
			}
		}
	}

	private void action(Socket socketClient,String action,JSONArray param) {
		for(Joueur j:Partie.getInstance().getListeJoueur())
		{
			if(j.getCommunication().getSocketClient() == socketClient)
			{
				if(param !=null)
				{
					gererMisePourRelance(j,param);
				}
				faireAction(action,j);
				this.notify();
			}
		}
	}

	private void gererMisePourRelance(Joueur j, JSONArray param) {
		for(int i =0;i<5;i++)
		{

			JSONObject obj = null;
			int valeur = 0;
			int quantite = 0;
			try {
				obj = (JSONObject) param.get(i);
				valeur = obj.getInt("idJeton");
				quantite = obj.getInt("quantite");
			} catch (JSONException e1) {
				e1.printStackTrace();
			}
			modifieQuantiteListeDeJetons(j,valeur,quantite);
		}

	}

	private void modifieQuantiteListeDeJetons(Joueur j, int valeur, int quantite) {
		j.getListeJeton().get((String.valueOf(valeur-1))).setQuantite(
				j.getListeJeton().get((String.valueOf(valeur-1))).getQuantite()-quantite);

		j.getListeJetonMise().get((String.valueOf(valeur-1))).setQuantite(
				j.getListeJetonMise().get((String.valueOf(valeur-1))).getQuantite()+quantite);

	}

	private void faireAction(String action, Joueur j) {
		switch (action) {
		case "SeCoucher":
			j.setAction(new SeCoucher("SeCoucher"));
			break;
		case "Relance":
			j.setAction(new Relance("Relance"));
			break;
		case "Tapis":
			j.setAction(new Tapis("Tapis"));
			break;
		case "Checker":
			j.setAction(new Checker("Checker"));
			break;
		default:
			break;
		}
	}

	private void connexion(JSONObject message) throws JSONException 
	{
		if(Partie.getInstance().isEncours() == true)
		{
			if(Partie.getInstance().getJeuEncours() != null && Partie.getInstance().getJeuEncours().isEncours() == true)
			{
				impossibleReessayerPlusTard();
			}
			else
			{
				connecte(message);
			}
		}
		else{
			connecte(message);
		}

	}

	private void connecte(JSONObject message) throws JSONException {
		if(Partie.getInstance().getNbJoueur()<10)
		{
			activeJoueur(message);
		}
		else
		{
			impossibleReessayerPlusTard();
		}
	}

	private void impossibleReessayerPlusTard() {

		CreateurDeTrame cdt = new CreateurDeTrame("1RJ",false,null,true);
		this.getOut().println(cdt.getTrame());
		this.getOut().flush();

	}

	private void activeJoueur(JSONObject message) throws JSONException 
	{
		String pseudoUTF8 = mettrePseudoEnUTF8(message);
		Joueur joueur =new Joueur(pseudoUTF8,this,message.get("idJoueur").toString());
		
		if(Partie.getInstance().getListeJoueur().size()>=1)
		{
			joueur = verifieQueJoueurNExistePas(joueur);
		}
		
		Connecter connecte = new Connecter("Connecter");
		connecte.setExiste(existe);
		joueur.setAction(connecte);
		new GererActionJoueur(joueur);
		
		PlateauDeJeu.getInstance().affiche();
		new ActionEnvoyerValeurJetonEtArgentAuJoueur(joueur,existe);
	}

	private String mettrePseudoEnUTF8(JSONObject message) throws JSONException {
		String pseudoUTF8 = null;
		try {
			pseudoUTF8 = new String(message.get("pseudo").toString().getBytes(), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return pseudoUTF8;
	}

	private Joueur verifieQueJoueurNExistePas(Joueur joueur) {

		String identifiant = joueur.getIdentifiant();

		for(Joueur j:Partie.getInstance().getListeJoueur())
		{
			if(j.getIdentifiant().equals(identifiant))
			{
				return joueurExiste(joueur, j);
			}
		}
		existe =false;

		return joueur;
	}

	private Joueur joueurExiste(Joueur joueur, Joueur j) {
		int index = Partie.getInstance().getListeJoueur().indexOf(j);

		reinitailiserJoueurAvecValeurExistante(joueur, j, index);
		existe =true;
		if(Partie.getInstance().getListeJoueur().size()<2)
		{
			ActionCliquerChargement.cpt = 1;
		}
		reinitailiseZone(j);
		return joueur;
	}

	private void reinitailiseZone(Joueur j) {
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).reinitialise();
			}
		});
	}

	private void reinitailiserJoueurAvecValeurExistante(Joueur joueur,
			Joueur j, int index) {
		joueur.setListeJeton(j.getListeJeton());
		joueur.setEmplacement(j.getEmplacement());
		Partie.getInstance().getListeJoueur().remove(j);
		Partie.getInstance().getListeJoueur().add(index, joueur);
	}

	public void fermer() {
		try {
			if(!socketClient.isClosed())
			{
				socketClient.close();
				in.close();
				out.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public BufferedReader getIn() {
		return in;
	}

	public void setIn(BufferedReader in) {
		this.in = in;
	}

	public PrintWriter getOut() {
		return out;
	}

	public void setOut(PrintWriter out) {
		this.out = out;
	}

	public Socket getSocketClient() {
		return socketClient;
	}

	public void setSocketClient(Socket socketClient) {
		this.socketClient = socketClient;
	}

	public boolean isThreadFermer() {
		return threadFermer;
	}

	public void setThreadFermer(boolean threadFermer) {
		this.threadFermer = threadFermer;
	}


	public boolean isExiste() {
		return existe;
	}

	public void setExiste(boolean existe) {
		this.existe = existe;
	}
}