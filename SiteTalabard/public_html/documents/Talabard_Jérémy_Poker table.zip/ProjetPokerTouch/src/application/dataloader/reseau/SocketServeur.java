package application.dataloader.reseau;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class SocketServeur {

	public static ServerSocket socketserver;
	public static ArrayList<Socket> listeClients;
	public static Acceptation_T acceptation_T;
	
	public SocketServeur() {
		socketserver = null;
		listeClients  = new ArrayList<Socket>();
	}

	public void ouvrirPort() {

		try {
			socketserver = new ServerSocket(12000);
			acceptation_T = new Acceptation_T(listeClients, socketserver);
			acceptation_T.start();

		}catch (Exception e) {
			fermer();
			if(acceptation_T != null)
			{
				acceptation_T.fermer();
			}

		}
	}

	public static void fermer()
	{
		try {
			if(acceptation_T != null)
			{
				acceptation_T.fermer();
			}
			if(socketserver !=null)
			{
				socketserver.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
