package application.metier;

/**
 * Classe qui d�finit une carte de jeu
 * @author J�r�my
 *
 */
public class Carte implements Comparable<Carte>{

	/**
	 * couleur de la carte
	 */
	private String couleur;
	/**
	 * nom de la carte = couleur-valeur
	 */
	private String nom;
	/**
	 * valeur
	 */
	private int valeur;
	/**
	 * chemin de l'image
	 */
	private String image;
	
	/*____________________________________________________________*/
	/**
	 * constructeur
	 * @param valeur
	 * @param couleur
	 */
	public Carte(int valeur, String couleur){
		this.valeur = valeur;
		this.couleur = couleur;
	}
	/*____________________________________________________________*/
	/**
	 * constructeur
	 * @param couleur
	 * @param nom
	 * @param valeur
	 * @param image
	 */
	public Carte(String couleur,String nom, int valeur, String image){
		this.couleur=couleur;
		this.nom=nom;
		this.valeur=valeur;
		this.image=image;
	}
	/*____________________________________________________________*/
	/**
	 * constructeur par defaut
	 */
	public Carte() {
	}
	/*____________________________________________________________*/
	/**
	 * methode affichant l'objet carte
	 */
	@Override
	public String toString() {
		StringBuilder str=new StringBuilder();
		str.append(this.couleur.toLowerCase()).append("_").append(this.valeur);
		return str.toString();
	}
	/*____________________________________________________________*/
	/**
	 * permet de comparer deux cartes entre elles
	 */
	@Override
	public int compareTo(Carte c) {
		
		if(this.getValeur() > c.getValeur())
		{
			return 1;
		}
		else if(this.getValeur() < c.getValeur())
		{
			return -1;
		}
		else return 0;
	}
	
	/*____________________________________________________________*/
	/**
	 * getter et setters
	 */
	/*____________________________________________________________*/
	
	/**
	 * retourne la couleur de la carte
	 */
	public String getCouleur() {
		return couleur;
	}
	/*____________________________________________________________*/
	/**
	 * retourne le nom de la carte
	 */
	public String getNom(){
		return nom;
	}
	/*____________________________________________________________*/
	/**
	 * retourne la valeur de la carte
	 */
	public int getValeur() {
		return valeur;
	}
	/*____________________________________________________________*/
	/**
	 * retourne le chemin de l'image de la carte
	 */
	public String getImage() {
		return image;
	}
	/*____________________________________________________________*/
	/**
	 * modifie la couleur de la carte
	 */
	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}
	/*____________________________________________________________*/
	/**
	 * modifie le nom de la carte
	 */
	public void setNom(String nom){
		this.nom=nom;
	}
	/*____________________________________________________________*/
	/**
	 * modifie la valeur de la carte
	 */
	public void setValeur(int valeur) {
		this.valeur = valeur;
	}
	/*____________________________________________________________*/
	/**
	 * modifie le nom du chemin de l'image de la carte
	 */
	public void setImage(String image) {
		this.image = image;
	}
}
