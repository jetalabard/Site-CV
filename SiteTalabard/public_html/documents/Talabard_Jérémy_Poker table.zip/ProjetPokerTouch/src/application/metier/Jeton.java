package application.metier;

/**
 * Classe qui d�finit un jeton de poker
 * @author J�r�my
 *
 */
public class Jeton {

	/**
	 * valeur jeton
	 */
	private int valeur;
	/**
	 * quantit�
	 */
	private int quantite;
	/*____________________________________________________________*/
	/**
	 * constructeur de jeton
	 * @param valeur
	 * @param quantite
	 */
	public Jeton(int valeur, int quantite) {
		this.valeur= valeur;
		this.quantite = quantite;
	}
	/*____________________________________________________________*/
						/* getter and setter*/
	/*____________________________________________________________*/
	
	/**
	 * retourne la valeur d'un jeton
	 * @return valeur
	 */
	public int getValeur() {
		return valeur;
	}
	/**
	 * modifie la valeur d'un jeton
	 * @param valeur
	 */
	public void setValeur(int valeur) {
		this.valeur= valeur;
	}
	/**
	 * retourne la quantit� de ce jeton
	 * @return quantite
	 */
	public int getQuantite() {
		return quantite;
	}
	/**
	 * modifie la quantite de jeton
	 * @param quantite
	 */
	public void setQuantite(int quantite) {
		this.quantite =quantite;
	}
}
