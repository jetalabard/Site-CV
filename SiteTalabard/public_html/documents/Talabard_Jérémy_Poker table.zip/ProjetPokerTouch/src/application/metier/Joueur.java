package application.metier;

import ihm.controleur.actionjoueur.Action;
import application.dataloader.reseau.Reception_T;
import application.modele.ListeJeton;

/**
 * Classe qui d�finit un joueur de poker touch
 * @author J�r�my
 *
 */
public class Joueur {

	/**
	 * pseudo du joueur
	 */
	private  String pseudo;
	/**
	 * identifiant du joueur
	 */
	private String identifiant;
	/**
	 * permet de faire la relation entre le joueur du t�l�phone et le joueur du plateau
	 */
	private Reception_T communication;
	/**
	 * valeur du jeu du joueur
	 */
	private Valeur valeur;
	/**
	 * emplacement du joueur sur la table
	 */
	private int emplacement;
	/**
	 * argent mis� par le joueur au dernier coup
	 */
	private ListeJeton listeJetonMise;
	/**
	 * la main du joueur = 2 cartes
	 */
	private MainJoueur mainJoueur;
	/**
	 * liste des jeton du joueur
	 */
	private ListeJeton listeJeton;
	/**
	 * action du joueur
	 */
	private Action action;
	/**
	 * determine si le joueur a pay� la petite blind
	 */
	private boolean petiteBlind;
	/**
	 * permet de savoir si le joueur a d�voil� ces cartes
	 */
	private boolean devoile;
	/**
	 * permet de savoir combien le joueur a fait de relance
	 */
	private int nbRelanceAuTour=0;
	/**
	 * repr�sente les jetons d�j� mis� pour qu'en cas de tapis on puisse les r�cup�rer
	 */
	private ListeJeton jetonsDejaMise;

	/*_____________________________________________________________*/
	/**
	 * constructeur
	 * @param pseudo
	 */
	public Joueur(String pseudo) {
		nbRelanceAuTour = 0;
		this.pseudo = pseudo;
		mainJoueur = new MainJoueur();
		initialiseLesListeDeJetonDuJoueur();
		
	}
	/**
	 * initialise les listes de jetons des joueurs
	 */
	private void initialiseLesListeDeJetonDuJoueur() {
		
		listeJeton = new ListeJeton();
		listeJeton.initialiseListeJeton();
		
		listeJetonMise = new ListeJeton();
		listeJetonMise.initialiseListeJeton();
		
		setJetonsDejaMise(new ListeJeton());
		jetonsDejaMise.initialiseListeJeton();
		
	}
	/*_____________________________________________________________*/
	/**
	 * constructeur
	 * @param pseudo
	 * @param socket
	 * @param in
	 * @param out
	 */
	public Joueur(String pseudo,Reception_T communique,String id) {
		this.pseudo =  pseudo;
		this.communication = communique;
		this.identifiant = id;
		mainJoueur = new MainJoueur();
		listeJeton = new ListeJeton();
		initialiseLesListeDeJetonDuJoueur();
	}
	/*_____________________________________________________________*/
	/**
	 * retourne la plus grande carte des 7 cartes ( 5 de la table et 2 de sa main)
	 * @return
	 */
	public Carte retournePlusGrandeCarteDeSaValeur()
	{
		Carte carte =this.getValeur().getListeCarte().get(0);
		
		for(Carte c : this.getValeur().getListeCarte())
		{
			if(carte.getValeur()<c.getValeur())
			{
				carte = c;
			}
		}
		return carte;
	}
	/*_____________________________________________________________*/
	/**
	 * getters et setters
	 */
	/*_____________________________________________________________*/
	/**
	 * retourne la main du joueur
	 * @return
	 */
	public MainJoueur getMainJoueur() {
		return mainJoueur;
	}
	/*_____________________________________________________________*/
	/**
	 * retourne le pseudo du joueur
	 * @return
	 */
	public String getPseudo() {
		return pseudo;
	}
	/*_____________________________________________________________*/
	/**
	 * modifie le pseudo du joueur
	 * @param pseudo
	 */
	public void setPseudo(String pseudo) {
		this.pseudo = pseudo;
	}
	/*_____________________________________________________________*/
	/**
	 * modifie l'emplacement du joueur
	 * @param numeroZone
	 */
	public void setEmplacement(int numeroZone) {
		this.emplacement = numeroZone;

	}
	/*_____________________________________________________________*/
	/**
	 * retourne l'emplacement du joueur
	 * @return
	 */
	public int getEmplacement() {
		return emplacement;
	}
	/*_____________________________________________________________*/
	/**
	 * modifie l'action du joueur, notifie le thread AttendreQueActionFaiteEtDemandeAuJoueurSuivantDeJouer
	 * @param action
	 */
	public void setAction(Action action) {
		this.action = action;
		synchronized (this) {
			this.notify();
		}
	}
	
	/*_____________________________________________________________*/
	/**
	 * retourne l'argent mis�
	 * @return
	 */
	public ListeJeton getListeJetonMise() {
		return listeJetonMise;
	}
	/*_____________________________________________________________*/
	/**
	 * modifie l'argent mis�
	 * @param argentMise
	 */
	public void setListeJetonMise(ListeJeton argentMise) {
		this.listeJetonMise = argentMise;
	}
	/*_____________________________________________________________*/
	/**
	 * modifie la main du joueur
	 * @param carte
	 * @param carte2
	 */
	public void setMainJoueur(Carte carte, Carte carte2) {
		mainJoueur = new MainJoueur();
		mainJoueur.remplirMain(carte, carte2);
	}
	
	/*_____________________________________________________________*/
	/**
	 * retourne la valeur du jeu du joueur
	 * @return
	 */
	public Valeur getValeur() {
		return valeur;
	}
	/*_____________________________________________________________*/
	/**
	 * modifie la valeur du jeu du joueur
	 * @param valeur
	 */
	public void setValeur(Valeur valeur) {
		this.valeur = valeur;
	}
	/*_____________________________________________________________*/
	/**
	 * 
	 * @return
	 */
	public ListeJeton getListeJeton() {
		return listeJeton;
	}
	/*_____________________________________________________________*/
	/**
	 * 
	 * @param listeJeton
	 */
	public void setListeJeton(ListeJeton listeJeton) {
		this.listeJeton = listeJeton;
	}
	/*_____________________________________________________________*/
	/**
	 * retourne l'action du joueur
	 * @return
	 */
	public Action getAction() {
		return action;
	}
	/*_____________________________________________________________*/
	/**
	 * retourne le thread de communication
	 * @return
	 */
	public Reception_T getCommunication() {
		return communication;
	}
	/*_____________________________________________________________*/
	/**
	 * retourne true si le joueur a d�voil� ces cartes sinon false
	 * @return
	 */
	public boolean isPetiteBlind() {
		return petiteBlind;
	}
	/*_____________________________________________________________*/
	/**
	 * modifie la valeur du boolean estPetiteBlind
	 * @param petiteBlind
	 */
	public void setPetiteBlind(boolean petiteBlind) {
		this.petiteBlind = petiteBlind;
	}
	/*_____________________________________________________________*/
	/**
	 * retourne le nombre de relance du joueur
	 * @return
	 */
	public int getNbRelanceAuTour() {
		return nbRelanceAuTour;
	}
	/*_____________________________________________________________*/
	/**
	 * modifie le nombre de relance du joueur
	 * @param nbRelanceAuTour
	 */
	public void setNbRelanceAuTour(int nbRelanceAuTour) {
		this.nbRelanceAuTour = nbRelanceAuTour;
	}
	/*_____________________________________________________________*/
	/**
	 * retourne true si le joueur a d�voil� sinon false
	 * @return
	 */
	public boolean isDevoile() {
		return devoile;
	}
	/*_____________________________________________________________*/
	/**
	 * modifie la valeur du boolean a devoil�
	 * @param devoile
	 */
	public void setDevoile(boolean devoile) {
		this.devoile = devoile;
	}
	/*_____________________________________________________________*/
	/**
	 * retourne l'indentifiant unique du joueur
	 * @return
	 */
	public String getIdentifiant() {
		return identifiant;
	}
	/**
	 * retourne la liste des jetons d�j� mis� par le joueur
	 * @return
	 */
	public ListeJeton getJetonsDejaMise() {
		return jetonsDejaMise;
	}
	/**
	 *  modifie la liste des jetons d�j� mis� par le joueur
	 * @param jetonsDejaMise
	 */
	public void setJetonsDejaMise(ListeJeton jetonsDejaMise) {
		this.jetonsDejaMise = jetonsDejaMise;
	}
}
