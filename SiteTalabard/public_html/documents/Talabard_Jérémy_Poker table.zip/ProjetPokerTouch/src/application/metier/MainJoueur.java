package application.metier;

import java.util.ArrayList;

/**
 * classe qui d�finit ce qu'est la main d'un joueur
 * @author J�r�my
 *
 */
public class MainJoueur 
{
	/**
	 * la liste des cartes
	 */
	private ArrayList<Carte> listeCarte;
	/*__________________________________________________________*/
	/**
	 * constructeur
	 */
	public MainJoueur() {
		listeCarte = new ArrayList<Carte>();
	}
	/*__________________________________________________________*/
	/**
	 * remplit la main du joueur
	 * @param carte1
	 * @param carte2
	 */
	public void remplirMain(Carte carte1,Carte carte2)
	{
		listeCarte.add(carte1);
		listeCarte.add(carte2);
	}
	/*__________________________________________________________*/
	/**
	 * efface la main du joueur
	 */
	public void reinitialiserMain()
	{
		listeCarte = new ArrayList<Carte>();
	}
	/*__________________________________________________________*/
	/**
	 * retourne la premiere carte
	 * @return
	 */
	public Carte donnePremiereCarte()
	{
		return listeCarte.get(1);
	}
	/*__________________________________________________________*/
	/**
	 * retourne la deuxieme carte
	 * @return
	 */
	public Carte donneDeuxiemeCarte()
	{
		return listeCarte.get(0);
	}
	/*__________________________________________________________*/
	/**
	 * retourne la liste de carte de la main
	 * @return
	 */
	public ArrayList<Carte> getListeCarte() {
		return listeCarte;
	}
	/*__________________________________________________________*/
	/**
	 * modifie la liste de carte de la main
	 * @param listeCarte
	 */
	public void setListeCarte(ArrayList<Carte> listeCarte) {
		this.listeCarte = listeCarte;
	}

	/*_____________________________________________________________*/
	/**
	 * recupere la plus grande carte de la main du joueur
	 * @return
	 */
	public Carte recupererPlusGrandeCarte() {

		if(this.donnePremiereCarte().getValeur() > this.donneDeuxiemeCarte().getValeur())
		{
			return this.donnePremiereCarte();
		}
		else if(this.donnePremiereCarte().getValeur() < this.donneDeuxiemeCarte().getValeur())
		{
			return this.donneDeuxiemeCarte();
		}
		else{
			return this.donneDeuxiemeCarte();
		}

	}
	/*_____________________________________________________________*/
	/**
	 * recupere plus petite carte de la main du joueur
	 * @return
	 */
	public Carte recupererPlusPetiteCarte() {

		if(this.donnePremiereCarte().getValeur() > this.donneDeuxiemeCarte().getValeur())
		{
			return this.donneDeuxiemeCarte();
		}
		else if(this.donnePremiereCarte().getValeur() < this.donneDeuxiemeCarte().getValeur())
		{
			return this.donnePremiereCarte();
		}
		else{
			return this.donnePremiereCarte();
		}
	}
}
