package application.metier;

import java.util.ArrayList;

import application.modele.ListeJeton;

/**
 * classe qui d�finit le pot 
 * @author J�r�my
 *
 */
public class Pot {
	
	/**
	 * montant total du pot
	 */
	private ListeJeton montant;
	/**
	 * liste de joueur qui convoite ce pot
	 */
	private ArrayList<Joueur> listeJoueur;
	/*_____________________________________________________________*/
	/**
	 * constructeur
	 */
	public Pot() {
		this.montant = new ListeJeton();
		montant.initialiseListeJeton();	
		listeJoueur = new ArrayList<Joueur>();
	}
	/*__________________________________________________________*/
	/**
	 * reinitialise le pot � 0
	 */
	public void reinitialisePot()
	{
		this.montant = new ListeJeton();
		montant.initialiseListeJeton();
		listeJoueur = new ArrayList<Joueur>();
	}
	/*__________________________________________________________*/
	/**
	 * getter et setter
	 */
	/*__________________________________________________________*/
	/**
	 * retourne le montant du pot
	 * @return
	 */
	public ListeJeton getMontant() {
		return montant;
	}
	/*__________________________________________________________*/
	/**
	 * modifie le montant du pot
	 * @param montant
	 */
	public void setMontant(ListeJeton jeton) {
		this.montant =  jeton;
	}
	/*_____________________________________________________________*/
	/**
	 * retourne la liste des joueurs
	 * @return
	 */
	public ArrayList<Joueur> getListeJoueur() {
		return listeJoueur;
	}
	/*_____________________________________________________________*/
	/**
	 * modifie la liste des joueurs
	 * @param listeJoueur
	 */
	public void setListeJoueur(ArrayList<Joueur> listeJoueur) {
		for(Joueur j:listeJoueur)
		{
			if(!this.listeJoueur.contains(j))
			{
				listeJoueur.add(j);
			}
		}
	}
}
