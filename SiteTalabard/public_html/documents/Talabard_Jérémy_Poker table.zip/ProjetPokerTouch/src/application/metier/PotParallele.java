package application.metier;

import java.util.ArrayList;

import application.modele.ListeJeton;
/**
 * classe qui d�finit un pot parall�le
 * @author J�r�my
 *
 */
public class PotParallele extends Pot{
	
	/**
	 * liste de jeton correspondant au tapis de base du joueur
	 * @return
	 */
	private ListeJeton tapisDeBase;
	/**
	 * joueur qui a fait le tapis donnant lieu au pot parallele
	 */
	private Joueur initiateurDuPot;
	/**
	 * constructeur par d�faut
	 */
	public PotParallele() {
	}
	/*__________________________________________________________*/
	/**
	 * constructeur
	 * @param j
	 * @param nomTour 
	 * @param montantPotParallele 
	 */
	public PotParallele(Joueur j, ListeJeton montantPotParallele) {
		tapisDeBase = new ListeJeton();
		tapisDeBase.initialiseListeJeton();
		tapisDeBase.incrementeListeJetonAvecAutreListe(montantPotParallele);
		setInitiateurDuPot(j);
		super.getListeJoueur().add(j);
		super.setMontant(montantPotParallele);
	}
	
	/*__________________________________________________________*/
	/**
	 * getter and setter
	 */
	/*__________________________________________________________*/
	
	/**
	 * retourne la liste de jeton correspondant au tapis de base du joueur
	 * @return
	 */
	public ListeJeton getTapisDeBase() {
		return tapisDeBase;
	}
	/**
	 * modifie le tapis de base
	 * @param liste
	 */
	public void setTapisDeBase(ListeJeton liste)
	{
		this.tapisDeBase = liste;
	}

	
	/*__________________________________________________________*/
	/**
	 * modifie la liste des joueurs pouvant gagner le pot
	 * @param liste
	 */
	public void setListeJoueurPouvantGagnerLePot(ArrayList<Joueur> liste) {
		super.setListeJoueur(liste);
	}
	/**
	 * retourne l'initiateur du pot 
	 * @return
	 */
	public Joueur getInitiateurDuPot() {
		return initiateurDuPot;
	}
	/**
	 * modifie l'initiateur du pot
	 * @param initiateurDuPot
	 */
	public void setInitiateurDuPot(Joueur initiateurDuPot) {
		this.initiateurDuPot = initiateurDuPot;
	}
}
