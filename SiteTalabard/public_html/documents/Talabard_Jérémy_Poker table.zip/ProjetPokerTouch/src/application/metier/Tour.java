package application.metier;

import java.util.ArrayList;

import ihm.controleur.AttendreQueActionFaiteEtDemandeJoueurSuivantDeJouer;
import ihm.controleur.AttenteCommunicationAvecJoueur;
import ihm.controleur.ObserveActionJoueur;
import ihm.controleur.action_table.envoietelephone.ActionDemandeAuJoueurDeJouer;
import application.modele.Jeu;
import application.modele.ListeJeton;
import application.modele.Partie;

/**
 * classe abstraite qui d�finit un tour de jeu
 * @author J�r�my
 *
 */
public abstract class Tour {
	
	/**
	 * valeur de la plus grande mise sur le tapis
	 */
	private ListeJeton plusGrandeMise ;
	/**
	 * permet de savoir quand on change de joueur dans un tour
	 */
	private boolean changeJoueurOk = true;
	/**
	 * permet de savoir si les joeuurs peuvent checker
	 */
	private boolean peutChecker=false;
	/**
	 * liste de pot parallele 
	 */
	private ArrayList<PotParallele> listePotParellele;
	/*__________________________________________________________*/
	/**
	 * Constructeur
	 * @param jeu
	 */
	public Tour() {
		initialiseLaPlusGrandeMise();
		listePotParellele = new ArrayList<PotParallele>();
	}
	/*_____________________________________________________________*/
	/**
	 * remet la plus grande mise � z�ro
	 */
	private void initialiseLaPlusGrandeMise() {
		plusGrandeMise = new ListeJeton();
		plusGrandeMise.initialiseListeJeton();
	}

	/*__________________________________________________________*/
	/**
	 * methode abstraite jouer
	 */
	public abstract void jouer();

	/*__________________________________________________________*/
	/**
	 * permet de jouer un tour
	 * chaque joueur fait une action
	 */
	public void faireTour(Joueur j)
	{
		if(changeJoueurOk)
		{
			new ActionDemandeAuJoueurDeJouer(j);
			AttenteCommunicationAvecJoueur attend = new AttenteCommunicationAvecJoueur(j);
			attend.start();

			ObserveActionJoueur obs = null;
			obs = new ObserveActionJoueur(j);
			obs.start();

			AttendreQueActionFaiteEtDemandeJoueurSuivantDeJouer at = new AttendreQueActionFaiteEtDemandeJoueurSuivantDeJouer(obs,this,j);
			at.start();
		}
	}
	/*_____________________________________________________________*/
	/**
	 * retourne le premier joueur qui joue
	 * @return
	 */
	public Joueur retourneJoueurQuiEstLePremierAJouer()
	{
		Jeu jeu =Partie.getInstance().getJeuEncours();
		int index = 0;
		index =jeu.getListeJoueurEnJeu().indexOf(Partie.getInstance().getDernierJoueurPayePetiteBlind())+2;

		if(index >= jeu.getListeJoueurEnJeu().size())
		{
			index = index - jeu.getListeJoueurEnJeu().size();
		}
		Joueur j = jeu.getListeJoueurEnJeu().get(index);
		return j;
	}
	
	/*________________________________________________________________________*/
	/**
	 * remet la liste des jetons des mises � 0
	 */
	public void reinitialiseMiseJoueur() {
		for(Joueur j:Partie.getInstance().getListeJoueur())
		{
			j.getListeJetonMise().initialiseListeJeton();
		}
	}
	/**
	 * retourne le plus grand pot parall�le parmi la liste de pot parallele
	 * @return
	 */
	public PotParallele retourneLePlusGrandPotParallele()
	{
		int index = 0;
		if(listePotParellele.size() == 0)
		{
			return null;
		}
		for(PotParallele pot :listePotParellele)
		{
			if(pot.getTapisDeBase().retourneMontant()> listePotParellele.get(index).getTapisDeBase().retourneMontant())
			{
				index = listePotParellele.indexOf(pot);
			}
		}
		return listePotParellele.get(index);
	}

	/*__________________________________________________________*/
	/**
	 * getter et setter
	 * @return
	 */
	/*__________________________________________________________*/

	/**
	 * retourne la liste de jeton de la plsu grande mise
	 * @return
	 */
	public ListeJeton getPlusGrandeMise() {
		return plusGrandeMise;
	}
	/**
	 * modifie la plus grande mise
	 * @param miseJoueur
	 */
	public void setPlusGrandeMise(ListeJeton miseJoueur) {
		this.plusGrandeMise = new ListeJeton();
		this.plusGrandeMise.initialiseListeJeton();
		this.plusGrandeMise = miseJoueur;
	}
	/**
	 * retourne true si l'on peut demander au joueur suivant de jouer sinon false
	 * @return
	 */
	public boolean isChangeJoueurOk() {
		return changeJoueurOk;
	}
	/**
	 * modifie le boolean changeJoueurOk
	 * @param changeJoueurOk
	 */
	public void setChangeJoueurOk(boolean changeJoueurOk) {
		this.changeJoueurOk = changeJoueurOk;
	}
	/**
	 * retourne true si l'on peut checker sinon false
	 * @return
	 */
	public boolean isPeutChecker() {
		return peutChecker;
	}
	/**
	 * modifier le boolean peutChecker
	 * @param peutChecker
	 */
	public void setPeutChecker(boolean peutChecker) {
		this.peutChecker = peutChecker;
	}
	/**
	 * retourne la liste des pots paralleles
	 * @return
	 */
	public ArrayList<PotParallele> getListePotParellele() {
		return listePotParellele;
	}
	/**
	 * modifie la liste des pots paralleles de ce tour
	 * @param listePotParellele
	 */
	public void setListePotParellele(ArrayList<PotParallele> listePotParellele) {
		this.listePotParellele = listePotParellele;
	}


}
