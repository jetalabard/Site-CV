package application.metier;

import application.modele.Dealer;
import application.modele.Partie;

/**
 * classe qui h�rite de Tour et qui d�finit les tour du flop et du turn
 * @author J�r�my
 *
 */
public class TourNormal extends Tour{

	/*____________________________________________________________*/
	/**
	 * constructeur
	 * @param jeu
	 */
	public TourNormal() {
		super();
		setPeutChecker(true);
	}
	/*____________________________________________________________*/
	/**
	 * jouer le tour
	 */
	@Override
	public void jouer() 
	{
		reinitialiseMiseJoueur();
		String nomTour = Partie.getInstance().getJeuEncours().getNomTourActuel();
		
		if(nomTour == "Flop"){
			Dealer.getInstance().mettreCarteFlop(0);
		}else if(nomTour =="Turn"){
			Dealer.getInstance().mettreCarte(0,3);
		}
		faireTour(retourneJoueurQuiEstLePremierAJouer());
	}
}