package application.metier;

import ihm.controleur.action_table.envoietelephone.ActionDemandeArgentBlind;
import ihm.controleur.action_table.envoietelephone.ActionDemandeAuJoueurDeJouer;
import javafx.application.Platform;
import application.modele.Dealer;
import application.modele.Partie;

/**
 * classe qui h�rite de Tour et qui d�finit le pr� flop
 * @author J�r�my
 *
 */
public class TourPreFlop extends Tour{

	/**
	 * si compteur �gale 0 alors on paye blind sinon non
	 */
	public static int compteur;
	/*____________________________________________________________*/
	/**
	 * constructeur
	 * @param jeu
	 */
	public TourPreFlop() {
		super();
		setPeutChecker(false);
		compteur = 0;

	}
	/*____________________________________________________________*/
	/**
	 * jouer le tour
	 */
	@Override
	public void jouer() 
	{
		reinitialiseMiseJoueur();
		ActionDemandeAuJoueurDeJouer.nombreDeFois = 0;
		
		if(Partie.getInstance().getNbJoueur()>=2)
		{
			gererBlind();
			Dealer.getInstance().distribuer();
			if(compteur>0){
				Platform.runLater(new Runnable() {
					public void run() {
						faireTour(retourneJoueurQuiEstLePremierAJouer());
					}
				});
			}
		}
	}
	/*________________________________________________________________________*/
	/**
	 * gere le paiement des blind
	 */
	private void gererBlind() {
		
		Joueur joueurQuiPayeGrosseBlind = null;
		int indexj1 = Partie.getInstance().recupereIndexJoueur(Partie.getInstance().gererJoueurQuiPayeBlind());

		Joueur joueurQuiPayePetiteBlind = Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().get(indexj1);
		if(indexj1+1>= Partie.getInstance().getListeJoueur().size())
		{
			joueurQuiPayeGrosseBlind = Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().get(indexj1+1-Partie.getInstance().getListeJoueur().size());
		}
		else{
			joueurQuiPayeGrosseBlind = Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().get(indexj1+1);

		}
		new ActionDemandeArgentBlind(joueurQuiPayePetiteBlind,joueurQuiPayeGrosseBlind);
	}
}
