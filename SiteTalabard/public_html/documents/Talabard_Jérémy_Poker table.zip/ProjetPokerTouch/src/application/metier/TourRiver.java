package application.metier;

import application.modele.Dealer;

/**
 * classe qui h�rite de Tour et qui d�finit le river
 * @author J�r�my
 *
 */
public class TourRiver extends Tour{
	/*_______________________________________________*/
	/**
	 * constructeur
	 * @param jeu
	 */
	public TourRiver() {
		super();
		setPeutChecker(true);
	}
	/*_______________________________________________*/
	/**
	 * permet de jouer le tour
	 */
	@Override
	public void jouer() {
		reinitialiseMiseJoueur();
		Dealer.getInstance().mettreCarte(0,4);
		faireTour(retourneJoueurQuiEstLePremierAJouer());
	}
}
