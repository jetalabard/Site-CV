package application.metier;

import java.util.ArrayList;

/**
 * donne acc�s � la valeur du jeu du joueur pour savoir s'il a une pair, double pair,brelan etc.
 * @author J�r�my
 */
public class Valeur {
	/**
	 * liste des cartes
	 */
	private ArrayList<Carte> listeCarte;
	/**
	 * valeur que vaut le jeu du joueur de 0 � 9
	 */
	private int valeur;
	/*_______________________________________________*/
	/**
	 * constructeur
	 */
	public Valeur() {
		listeCarte = new ArrayList<Carte>();
	}
	/*_______________________________________________*/
	/**
	 * constructeur
	 * @param valeur
	 */
	public Valeur(int valeur) {
		setValeur(valeur);
		listeCarte = new ArrayList<Carte>();
	}
	/*_______________________________________________*/
	/**
	 * remplace la valeur par une autre et ajoute des cartes en plus � la valeur
	 * @param val
	 * @return 
	 */
	public boolean ajoute(Valeur val) {
		int compteur = 0;
		for(Carte carte :val.getListeCarte())
		{
			if(!listeCarte.contains(carte))
			{
				compteur++;
				this.listeCarte.add(carte);
			}
		}
		this.valeur = val.getValeur();
		if(val.getListeCarte().size() == compteur)
		{
			return true;
		}
		else{
			return false;
		} 
	}
	/*_______________________________________________*/
	/**
	 * retourne le nom qui correspond au chiffre de la valeur
	 * @return
	 */
	public String retourneNomValeur()
	{
		String valRetour = "";
		switch (this.valeur) {
		case 1:
			valRetour = "Pair";
			break;
		case 2:
			valRetour = "Double Pair";
			break;
		case 3:
			valRetour = "Brelan";
			break;
		case 4:
			valRetour = "Suite";
			break;
		case 5:
			valRetour = "Couleur";
			break;
		case 6:
			valRetour = "Full";
			break;
		case 7:
			valRetour = "Carre";
			break;
		case 8:
			valRetour = "Quinte Flush";
			break;
		case 9:
			valRetour = "Quinte Flush Royale";
			break;
		case -1:
			valRetour = "Carte Haute";
			break;
		}
		return valRetour;
	}

	/*_______________________________________________*/
	/**
	 * getter et setter
	 */
	/*_______________________________________________*/

	/*_______________________________________________*/
	/**
	 * retourne la liste des cartes
	 * @return
	 */
	public ArrayList<Carte> getListeCarte() {
		return listeCarte;
	}
	/*_______________________________________________*/
	/**
	 * modifie la liste des cartes
	 * @param carte
	 */
	public void setListeCarte(ArrayList<Carte> cartes) {
		this.listeCarte = cartes;
	}
	/*_______________________________________________*/
	/**
	 * retourne la valeur
	 * @return
	 */
	public int getValeur() {
		return valeur;
	}
	/*_______________________________________________*/
	/**
	 * modifie la valeur
	 * @param valeur
	 */
	public void setValeur(int valeur) {
		this.valeur = valeur;
	}
}
