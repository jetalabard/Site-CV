package application.modele;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import application.metier.Carte;
import application.metier.Joueur;
import application.metier.MainJoueur;
import application.metier.Valeur;

/**
 * Classe qui calcul la valeur pour un joueur
 * @author J�r�my
 *
 */
public class CalculValeur {
	/**
	 * liste de carte du joueur
	 */
	private List<Carte> listeCarte;
	/**
	 * valeur courante du joueur
	 */
	private Valeur valeur;
	/**
	 * permet de savoir quelles combinaisons de carte regarder pour le joueur
	 */
	private int compteur;
	
	/**
	 * constructeur par d�faut
	 */
	public CalculValeur() {
		compteur = 0;
	}
	/**
	 * compare les valeurs entre deux joeuurs, le joueur qui a la plus grande valeur est retourn�
	 * s'ils ont la meme valeur et les memes cartes, on retourne null
	 * @param j1
	 * @param j2
	 * @return
	 */
	public Joueur comparerValeurDeuxJoueur(Joueur j1, Joueur j2)
	{
		if( j1.getValeur().getValeur()<j2.getValeur().getValeur())
		{
			return j2;
		}
		else if( j1.getValeur().getValeur()>j2.getValeur().getValeur())
		{
			return j1;
		}
		else 
		{
			Joueur gagnant = comparerValeurSiEgale(j1,j2);
			if(gagnant == null)
			{
				return null;
			}
			else return gagnant;
		}

	}
	/**
	 * compare la valeur de deux joueurs s'ils ont une valeur �gale
	 * retourne le joueur ayant les plus grande cartes parmi les 7
	 * si exactement les memes cartes alors retourne null
	 * @param j1
	 * @param j2
	 * @return
	 */
	private Joueur comparerValeurSiEgale(Joueur j1, Joueur j2) {

		if(j1.retournePlusGrandeCarteDeSaValeur().getValeur()>j2.retournePlusGrandeCarteDeSaValeur().getValeur())
		{
			return j1;
		}
		else if(j1.retournePlusGrandeCarteDeSaValeur().getValeur()<j2.retournePlusGrandeCarteDeSaValeur().getValeur())
		{
			return j2;
		}
		else{
			return compareSiExactementMemeValeur(j1, j2);
		}
	}
	/**
	 *  on compare les cartes de la main car ils ont la meme valeur
	 * @param j1
	 * @param j2
	 * @return
	 */
	private Joueur compareSiExactementMemeValeur(Joueur j1, Joueur j2) {

		MainJoueur main1 = j1.getMainJoueur();
		MainJoueur main2 = j2.getMainJoueur();

		Carte c = main1.recupererPlusGrandeCarte();
		Carte c2 = main2.recupererPlusGrandeCarte();

		if(c.getValeur()>c2.getValeur())
		{
			return j1;
		}
		else if(c.getValeur()<c2.getValeur())
		{
			return j2;
		}
		else{
			return compareSiExactementMemeCarte(j1, j2, main1, main2);
		}
	}
	/**
	 * compare les mains des joeuurs pour savoir qui a la plus grande
	 * @param j1
	 * @param j2
	 * @param main1
	 * @param main2
	 * @return
	 */
	private Joueur compareSiExactementMemeCarte(Joueur j1, Joueur j2,MainJoueur main1, MainJoueur main2) {
		Carte petiteCarte = main1.recupererPlusPetiteCarte();
		Carte petiteCarte2 = main2.recupererPlusPetiteCarte();

		if(petiteCarte.getValeur()>petiteCarte2.getValeur())
		{
			return j1;
		}
		else if(petiteCarte.getValeur() < petiteCarte2.getValeur())
		{
			return j2;
		}
		else {
			return null;
		}
	}
	/**
	 * regarde la combinaison de cartes associ� aux cartes du joueurs
	 * @param i
	 * @return
	 */
	private Valeur regardeValeur(int i)
	{
		switch (i) {
		case 0:
			return regardeSiRoyalFlush();
		case 1:
			return regardeSiQuinteFlush();
		case 2:
			return regardeSiCarre();
		case 3:
			return regardeSiFull();
		case 4:
			return regardeSiFlush();
		case 5:
			return regardeSiQuinte(valeur);
		case 6:
			return regardeSiBrelan();
		case 7:
			return regardeSiDoublePaire();
		case 8:
			return regardeSiPaire(valeur);
		default:
			return new Valeur(-1);
		}
	}
	
	/**
	 * determine la valeur du joueur et la retourne
	 * @param j
	 * @return
	 */
	public Valeur determineValeurJoueur(Joueur j)
	{
		if(compteur ==0)
		{
			recupereCarte(j);
		}
		
		if(compteur>8)
		{
			valeur = recupereLesCinqsCartePlusForteQuandAucuneValeur();
		}
		else{
			valeur = regardeValeur(compteur);
			if(valeur.getValeur() == -1)
			{
				compteur++;
				valeur= determineValeurJoueur(j);
			}
		}
		return valeur;
	}
	/**
	 * donne les cinqs cartes plus forte sur les 7 si le joueur n'a aucune valeur
	 * @return
	 */
	private Valeur recupereLesCinqsCartePlusForteQuandAucuneValeur() {
		Valeur val = new Valeur(0);
		for(int i =2;i<listeCarte.size();i++)
		{
			val.getListeCarte().add(listeCarte.get(i));
		}
		return val;
	}
	/**
	 * recupere les cartes du joueur et les ajoutent � la liste de carte qui est ensuite tri�
	 * @param j
	 */
	private void recupereCarte(Joueur j) {
		listeCarte = new ArrayList<Carte>(Dealer.getInstance().getListeCarteSurLaTable());

		listeCarte.add(j.getMainJoueur().donnePremiereCarte());
		listeCarte.add(j.getMainJoueur().donneDeuxiemeCarte());

		Collections.sort(listeCarte);
	}
	
	/**
	 * regarde si le joueur a une pair
	 * @param valeur
	 * @return
	 */
	private Valeur regardeSiPaire(Valeur valeur) {

		if(valeur.getValeur() == 3)
		{
			return SiPairAvecDejaBrelan(valeur);
		}
		else{
			return siPairSansBrelan();
		}
	}
	/**
	 * regarde si pair sans brelan
	 * @return
	 */
	private Valeur siPairSansBrelan() {
		for (int i =1 ;i<listeCarte.size();i++)
		{
			if(listeCarte.get(i).getValeur() == listeCarte.get(i-1).getValeur())
			{
				Valeur val = new Valeur(1);
				val.getListeCarte().add(listeCarte.get(i));
				val.getListeCarte().add(listeCarte.get(i-1));
				return val;
			}
		}
		return new Valeur(-1);
	}
	/**
	 * regarde si le joueur a une pair apres avoir un brelan -> correspond au full
	 * @param valeur
	 * @return
	 */
	private Valeur SiPairAvecDejaBrelan(Valeur valeur) {
		ArrayList<Carte> liste = new ArrayList<Carte>(listeCarte);
		liste = regardeSiContientLesMemesCartesSinonSupprime( liste);
		for (int i =liste.size()-1 ;i>= 1;i--)
		{
			if(liste.get(i).getValeur() == liste.get(i-1).getValeur())
			{
				Valeur val = new Valeur(1);
				val.getListeCarte().add(liste.get(i));
				val.getListeCarte().add(liste.get(i-1));
				return val;
			}
		}
		return new Valeur(-1);
	}
	/**
	 * dans le cas ou d�ja une valeur supprime les cartes en double dans la liste des cartes de la valeur du joueur
	 * @param valeur
	 * @param liste
	 * @return
	 */
	private ArrayList<Carte> regardeSiContientLesMemesCartesSinonSupprime(ArrayList<Carte> liste) {
		Carte courante = null;
		Iterator<Carte> iter = liste.iterator();
		courante = iter.next();
		while(iter.hasNext())
		{
			Carte c = iter.next();
			if(courante.getValeur() == c.getValeur())
			{
				iter.remove();
			}
			else{
				courante = c;
			}
		}
		Collections.sort(liste);
		return liste;
	}

	/**
	 * regarde si double pair
	 * @return
	 */
	private Valeur regardeSiDoublePaire() {

		for (int i =listeCarte.size()-1 ;i>=1;i--)
		{
			if(listeCarte.get(i).getValeur() == listeCarte.get(i-1).getValeur())
			{
				for (int j =listeCarte.size()-1 ;j>=1;j--)
				{
					if(listeCarte.get(j).getValeur() == listeCarte.get(j-1).getValeur())
					{
						if(j!=i)
						{
							Valeur val = new Valeur(2);
							val.getListeCarte().add(listeCarte.get(i));
							val.getListeCarte().add(listeCarte.get(i-1));
							val.getListeCarte().add(listeCarte.get(j));
							val.getListeCarte().add(listeCarte.get(j-1));
							return val;
						}
					}
				}
			}

		}
		return new Valeur(-1);
	}
	/**
	 * regarde si le joueur a un brelan
	 * @return la valeur des cartes du joueur
	 */
	private Valeur regardeSiBrelan() {
		for (int i =listeCarte.size()-1 ;i>=2;i--)
		{
			if(listeCarte.get(i).getValeur() == listeCarte.get(i-1).getValeur() 
					&& listeCarte.get(i-1).getValeur() == listeCarte.get(i-2).getValeur() )
			{
				Valeur val = new Valeur(3);
				val.getListeCarte().add(listeCarte.get(i));
				val.getListeCarte().add(listeCarte.get(i-1));
				val.getListeCarte().add(listeCarte.get(i-2));
				return val;
			}

		}
		return new Valeur(-1);
	}
	/**
	 * regarde si le joueur a une quinte
	 * @param valeur
	 * @return
	 */
	private Valeur regardeSiQuinte(Valeur valeur) {
		ArrayList<Carte> liste = new ArrayList<Carte>(listeCarte);
		liste = regardeSiContientLesMemesCartesSinonSupprime(liste);

		if(valeur.getValeur() == 5)
		{
			liste = new ArrayList<Carte>(valeur.getListeCarte());
			Collections.sort(liste);
		}
		if(liste.size()>=5)
		{
			valeur =  testeQuinte(liste);
		}
		return valeur;
	}
	/**
	 * determine s'il y a une quinte
	 * @param liste
	 */
	private Valeur testeQuinte(ArrayList<Carte> liste) {
		for (int i =liste.size()-1 ;i>=4;i--)
		{
			if(liste.get(i).getValeur() == liste.get(i-1).getValeur()+1 
					&& liste.get(i-1).getValeur() == liste.get(i-2).getValeur()+1 
					&& liste.get(i-2).getValeur() == liste.get(i-3).getValeur()+1 
					&& liste.get(i-3).getValeur() == liste.get(i-4).getValeur()+1)
			{
				Valeur val = new Valeur(4);
				val.getListeCarte().add(liste.get(i));
				val.getListeCarte().add(liste.get(i-1));
				val.getListeCarte().add(liste.get(i-2));
				val.getListeCarte().add(liste.get(i-3));
				val.getListeCarte().add(liste.get(i-4));
				return val;
			}
		}
		return new Valeur(-1);
	}

	/**
	 * regarde si flush
	 * @return
	 */
	private Valeur regardeSiFlush() {
		ArrayList<Carte> carteCoeur = new ArrayList<Carte>();
		ArrayList<Carte> carteCarreau = new ArrayList<Carte>();
		ArrayList<Carte> carteTrefle = new ArrayList<Carte>();
		ArrayList<Carte> cartePique = new ArrayList<Carte>();

		for(int i= listeCarte.size()-1;i>=0;i--)
		{
			if(listeCarte.get(i).getCouleur().equals("Pique"))
			{
				cartePique.add(listeCarte.get(i));
				if(cartePique.size() == 5)
				{
					return ajouteListe(cartePique);
				}
			}
			if(listeCarte.get(i).getCouleur().equals("Trefle"))
			{
				carteTrefle.add(listeCarte.get(i));
				if(carteTrefle.size() == 5)
				{
					return ajouteListe(carteTrefle);
				}
			}
			if(listeCarte.get(i).getCouleur().equals("Carreau"))
			{
				carteCarreau.add(listeCarte.get(i));
				if(carteCarreau.size() == 5)
				{
					return ajouteListe(carteCarreau);
				}
			}
			if(listeCarte.get(i).getCouleur().equals("Coeur"))
			{
				carteCoeur.add(listeCarte.get(i));
				if(carteCoeur.size() == 5)
				{
					return ajouteListe(carteCoeur);
				}
			}
		}
		return new Valeur(-1);
	}
	/**
	 * ajoute les cartes � la valeur de la flush
	 * @param liste
	 * @return
	 */
	private Valeur ajouteListe(ArrayList<Carte> liste) {
		Valeur val = new Valeur(5);

		val.getListeCarte().add(liste.get(0));
		val.getListeCarte().add(liste.get(1));
		val.getListeCarte().add(liste.get(2));
		val.getListeCarte().add(liste.get(3));
		val.getListeCarte().add(liste.get(4));
		return val;
	}
	/**
	 * regarde si full
	 * @return
	 */
	private Valeur regardeSiFull() {
		Valeur valeur;
		valeur = regardeSiBrelan();

		if(valeur.getValeur()!=-1)
		{
			boolean valRetour = valeur.ajoute(regardeSiPaire(valeur));
			if(valeur.getValeur()!=-1 && valRetour ==true)
			{
				valeur.setValeur(6);
				return valeur;
			}
			else {
				return new Valeur(-1);
			}
		}
		else {
			return new Valeur(-1);
		}
	}

	/**
	 * regarde si carr�
	 * @return
	 */
	private Valeur regardeSiCarre() {
		for (int i =listeCarte.size()-1 ;i>=3;i--)
		{
			if(listeCarte.get(i).getValeur() == listeCarte.get(i-1).getValeur() 
					&& listeCarte.get(i-1).getValeur() == listeCarte.get(i-2).getValeur()
					&& listeCarte.get(i-2).getValeur() == listeCarte.get(i-3).getValeur())
			{
				Valeur val = new Valeur(7);
				val.getListeCarte().add(listeCarte.get(i));
				val.getListeCarte().add(listeCarte.get(i-1));
				val.getListeCarte().add(listeCarte.get(i-2));
				val.getListeCarte().add(listeCarte.get(i-3));
				return val;
			}

		}
		return new Valeur(-1);
	}
	/**
	 * regarde si quinte flush
	 * @return
	 */
	private Valeur regardeSiQuinteFlush() {
		Valeur valeur ;
		valeur = regardeSiFlush();
		if(valeur.getValeur()!=-1)
		{
			valeur = regardeSiQuinte(valeur);
			if(valeur.getValeur()!=-1)
			{
				valeur.setValeur(8);
				return valeur;
			}
			else {
				return new Valeur(-1);
			}
		}
		else {
			return new Valeur(-1);
		}
	}
	/**
	 * regarde si quinte flush royal
	 * @return
	 */
	private Valeur regardeSiRoyalFlush() {

		for (int i =4 ;i<listeCarte.size();i++)
		{
			if(listeCarte.get(i).getValeur() == 14)
			{
				if(listeCarte.get(i-1).getValeur() == 13)
				{
					if(listeCarte.get(i-2).getValeur() == 12)
					{
						if(listeCarte.get(i-3).getValeur() == 11)
						{
							if(listeCarte.get(i-4).getValeur() == 10)
							{

								if(listeCarte.get(i-4).getCouleur().equals(listeCarte.get(i-3).getCouleur())
										&& listeCarte.get(i-3).getCouleur().equals(listeCarte.get(i-2).getCouleur())
										&& listeCarte.get(i-2).getCouleur().equals(listeCarte.get(i-1).getCouleur())
										&& listeCarte.get(i-1).getCouleur().equals(listeCarte.get(i).getCouleur()))
								{
									return ajouteCarteAQuinteFlushRoyale(i);
								}
							}
						}
					}

				}
			}
		}

		return new Valeur(-1);
	}
	/**
	 * ajoute les cartes � la valeur de la quinte flush royale
	 * @param i
	 * @return
	 */
	private Valeur ajouteCarteAQuinteFlushRoyale(int i) {
		Valeur val = new Valeur();
		val.setValeur(9);
		val.getListeCarte().add(listeCarte.get(i));
		val.getListeCarte().add(listeCarte.get(i-1));
		val.getListeCarte().add(listeCarte.get(i-2));
		val.getListeCarte().add(listeCarte.get(i-3));
		val.getListeCarte().add(listeCarte.get(i-4));
		return val;
	}
	
	/**
	 * retourne la liste des cartes
	 * @return
	 */
	public List<Carte> getListeCarte() {
		return listeCarte;
	}
	/**
	 * modifie la liste des cartes
	 * @param listeCarte
	 */
	public void setListeCarte(List<Carte> listeCarte) {
		this.listeCarte = listeCarte;
	}
	/**
	 * retourne la valeur courante
	 * @return
	 */
	public Valeur getValeur() {
		return valeur;
	}
	/**
	 * modifie la valeur courante
	 * @param valeur
	 */
	public void setValeur(Valeur valeur) {
		this.valeur = valeur;
	}

}
