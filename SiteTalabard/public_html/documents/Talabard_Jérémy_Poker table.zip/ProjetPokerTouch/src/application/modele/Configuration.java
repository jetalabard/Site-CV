package application.modele;

import java.util.HashMap;
import java.util.Map;

/**
 * Classe qui d�finit la configuration de la partie
 * @author J�r�my
 *
 */
public class Configuration {

	/**
	 * instance de la classe
	 */
	private static Configuration instance = null;
	/**
	 * savoir si la configuration est personnalis�e ou non
	 */
	private boolean personnalise;
	/**
	 * argent initiale des joueurs
	 */
	private int argentInitial;
	/**
	 * valeur de la petite blind 
	 */
	private ListeJeton valeurPetiteBlind;
	/**
	 * valeur de la grosse blind 
	 */
	private ListeJeton valeurGrosseBlind;
	/**
	 * nombre de tour o� les blinds vont �tre incr�ment�s
	 */
	private int nbTourChangeBlind;
	/**
	 * liste de jetons pour la configuration
	 */
	private Map<String,Integer> listeConfigJetons;
	/**
	 * retourne l'instance de la classe
	 * @return
	 */
	public static Configuration getInstance()
	{
		if(instance ==null)
		{
			instance = new Configuration();
		}
		return instance;
	}
	/**
	 * constructeur
	 */
	private Configuration() {
		listeConfigJetons = new HashMap<String, Integer>();		
		parDefautNombre();
		parDefautValeur();

	}
	/**
	 * initialise les jetons de blind
	 */
	public void initialiseListeJetonBlind() {

		valeurGrosseBlind = new ListeJeton();
		valeurGrosseBlind.initialiseListeJeton();
		valeurPetiteBlind =  new ListeJeton();
		valeurPetiteBlind.initialiseListeJeton();
	}
	/**
	 * met par defaut la quantit� de jetons
	 */
	public void parDefautNombre()
	{
		this.listeConfigJetons.put("qJ0",15);
		this.listeConfigJetons.put("qJ1",15);
		this.listeConfigJetons.put("qJ2",6);
		this.listeConfigJetons.put("qJ3", 4);
		this.listeConfigJetons.put("qJ4", 2);	
		calculerArgentInitial();
	}
	/**
	 * met par d�faut la valeur des jetons
	 */
	public void parDefautValeur(){
		this.listeConfigJetons.put("vJ0", 1);
		this.listeConfigJetons.put("vJ1", 5);
		this.listeConfigJetons.put("vJ2", 25);
		this.listeConfigJetons.put("vJ3", 100);
		this.listeConfigJetons.put("vJ4", 500);
		calculerArgentInitial();
	}
	/**
	 * met par defaut la valeur des blinds
	 */
	public void parDefautConfig(){

		initialiseListeJetonBlind();
		this.getValeurPetiteBlind().get("0").setQuantite(1);
		this.getValeurGrosseBlind().get("0").setQuantite(2);
		this.nbTourChangeBlind = 5;
	}

	/**
	 * calcule l'argent initiale en fonction des modifications apport�s � la configuration
	 */
	private void calculerArgentInitial() {
		int total=0;
		if(listeConfigJetons.get("vJ0")!=null && listeConfigJetons.get("qJ0")!=null){
			for(int i=0;i<5;i++){
				total+=listeConfigJetons.get("vJ"+i)*listeConfigJetons.get("qJ"+i);
			}
			this.argentInitial=total;
		}
	}

	/**
	 * met toute la conficguration par d�faut
	 */
	public void parDefaut() {

		parDefautValeur();
		parDefautNombre();
		initialiseListeJetonBlind();
		parDefautConfig();

	}
	/**
	 * reinitialise les blinds comme elles �taient au d�buts et les modifies si elles doivent etre incr�ment�
	 */
	public void reinitialiseBlind() 
	{
		if((Partie.getInstance().getListeJeu().size()+1)%Configuration.getInstance().getNbTourChangeBlind() == 0)
		{
			Configuration.getInstance().getValeurPetiteBlind().multipliePar(2);
			Configuration.getInstance().getValeurGrosseBlind().multipliePar(2);
			}
	}
	/**
	 * modifie les liste de configurations des jetons
	 * @param cle
	 * @param valeur
	 */
	public void modifie(String cle,int valeur)
	{
		listeConfigJetons.put(cle,valeur);
	}
	/**
	 * change la valeur d'un jeton en fonction de son index
	 * @param index
	 * @param somme
	 */
	public void changeValeur(String index,int somme){
		listeConfigJetons.put(index, somme);
		calculerArgentInitial();
	}
	/**
	 * change la quantit� de jeton
	 * @param index
	 */
	public void changeQuantiteJeton(int index,String symbole)
	{
		int valeurActuelle = 0;
		switch (symbole) {
		case "+":
			valeurActuelle=listeConfigJetons.get("qJ"+index)+1;
			break;
		case "-":
			valeurActuelle=listeConfigJetons.get("qJ"+index)-1;
			break;
		default:
			break;
		}
		listeConfigJetons.put("qJ"+index, valeurActuelle);
		calculerArgentInitial();
	}


	/**
	 * retourne la liste des jetons configur�
	 * @return
	 */
	public Map<String, Integer> getListeConfigJetons() {
		return listeConfigJetons;
	}
	/**
	 * determine si la partie est personnalis� ou non
	 * @return
	 */
	public boolean estPersonnalise() {
		return personnalise;
	}
	/**
	 * modifie le boolean estPersonnalis�
	 * @param personnalise
	 */
	public void setPersonnalise(boolean personnalise) {
		this.personnalise = personnalise;
	}
	/**
	 * retourne l'argent initiale
	 * @return
	 */
	public int getArgentInitial() {
		return argentInitial;
	}
	/**
	 * modifie l'argent initiale
	 */
	public void setArgentInitial(int argentInitial) {
		this.argentInitial = argentInitial;
	}
	/**
	 * retourne le petite blind 
	 * @return
	 */
	public ListeJeton getValeurPetiteBlind() {
		return valeurPetiteBlind;
	}
	/**
	 * modifie la petite Blind
	 * @param valeurPetiteBlind
	 */
	public void setValeurPetiteBlind(ListeJeton valeurPetiteBlind) {
		this.valeurPetiteBlind = valeurPetiteBlind;
	}
	/**
	 * retourne la grosse blind
	 * @return
	 */
	public ListeJeton getValeurGrosseBlind() {
		return valeurGrosseBlind;
	}
	/**
	 * modifie la grosse blind
	 * @param valeurGrosseBlind
	 */
	public void setValeurGrosseBlind(ListeJeton valeurGrosseBlind) {
		this.valeurGrosseBlind = valeurGrosseBlind;
	}
	/**
	 * retourne le nb de tour ou l'on incremente la blind
	 * @return
	 */
	public int getNbTourChangeBlind() {
		return nbTourChangeBlind;
	}
	/**
	 * modifie le nombre de tour d'incrementation de la blind
	 * @param nbTourChangeBlind
	 */
	public void setNbTourChangeBlind(int nbTourChangeBlind) {
		this.nbTourChangeBlind = nbTourChangeBlind;
	}
}
