package application.modele;

import ihm.controleur.action_table.envoietelephone.ActionDonnerCarte;
import ihm.controleur.action_table.envoietelephone.EnvoyerNouvellesCartes;
import ihm.vue.plateau.Animation;
import ihm.vue.plateau.PlateauDeJeu;
import ihm.vue.plateau.RecupereImageFXML;

import java.util.ArrayList;
import java.util.Random;

import javafx.scene.layout.AnchorPane;
import application.dataloader.ParserCartes;
import application.metier.Carte;
import application.metier.Joueur;

/**
 * correspond au dealer d'une partie de poker
 * @author J�r�my
 *
 */
public class Dealer {

	/**
	 * liste de toutes les cartes
	 */
	private ArrayList<Carte> listeCarte;
	/**
	 * liste des cartes tu�s
	 */
	private ArrayList<Carte> listeCarteTue;
	/**
	 * instance de dealer
	 */
	private static Dealer instance;
	/**
	 * liste des cartes sur la table
	 */
	private ArrayList<Carte> listeCarteSurLaTable;

	/**
	 * g�n�rateur de nombre al�atoire
	 */
	private static Random rd = new Random();

	/**
	 * retourne l'instance de la classe
	 * @return
	 */
	public static Dealer getInstance()
	{
		if(instance == null)
		{
			instance = new Dealer();
		}
		return instance;
	}
	/**
	 * constructeur
	 */
	private Dealer() {
		listeCarteSurLaTable = new ArrayList<Carte>();
		recoitPacquet();
	}
	/**
	 * parse la liste des cartes du fichier xml et met les resultats dans la listeCarte
	 */
	private void recoitPacquet() {
		listeCarte = new ArrayList<Carte>();
		listeCarteTue = new ArrayList<Carte>();

		ParserCartes parser = new ParserCartes();
		parser.charger();

		listeCarte = ListeCartes.getInstance().getListeCarte();
		melange();
	}
	/**
	 * melange les cartes
	 */
	public void melange()
	{
		ArrayList<Carte> temp = new ArrayList<Carte>();
		if(listeCarte.size()<52)
		{
			recoitPacquet();
		}
		for(int i=0; i <52;i++)
		{
			int alea = rd.nextInt(52-i);
			Carte c =new Carte();
			c = listeCarte.get(alea);
			listeCarte.remove(alea);
			temp.add(c);
		}
		listeCarte = temp; 
	}

	/**
	 * distribue les cartes aux joueurs
	 */
	public void distribuer()
	{
		for(Joueur joueur:Partie.getInstance().getListeJoueur())
		{
			joueur.getMainJoueur().reinitialiserMain();
		}
		for(int i =0; i<2;i++)
		{
			for(Joueur j : Partie.getInstance().getJeuEncours().getListeJoueurEnJeu())
			{
				j.getMainJoueur().getListeCarte().add(listeCarte.get(0));
				supprimerPremiereCarteDeLaListe(1);
			}
		}
		envoyerCarteAuJoueur();
		Animation.getInstance().faireAnimationLancerDeCarte();
	}
	/**
	 * envoie les cartes au joueur
	 */
	private void envoyerCarteAuJoueur() {
		for(Joueur j : Partie.getInstance().getJeuEncours().getListeJoueurEnJeu())
		{
			new ActionDonnerCarte(j,j.getMainJoueur().donnePremiereCarte(),j.getMainJoueur().donneDeuxiemeCarte());
		}
	}
	/**
	 * tuer une carte 
	 */
	private void tuer()
	{
		supprimerPremiereCarteDeLaListe(0);
	}
	/**
	 * supprime la premiere carte de la listeCarte
	 */
	private void supprimerPremiereCarteDeLaListe(int mode) {

		if(mode != 1)
		{
			listeCarteTue.add(new Carte(listeCarte.get(0).getCouleur(),listeCarte.get(0).getNom(),listeCarte.get(0).getValeur(),listeCarte.get(0).getImage()));
		}
		listeCarte.remove(0);

		ArrayList<Carte> listeTemp = new ArrayList<Carte>();
		for(Carte c: listeCarte)
		{
			if(c != null)
			{
				listeTemp.add(c);
			}
		}
		listeCarte = listeTemp;
	}
	/**
	 * met les cartes tu�s dans listeCarte
	 */
	public void ramasserCarte()
	{
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		listeCarte.addAll(listeCarteTue);
		listeCarte.addAll(listeCarteSurLaTable);
		
		reinitialiseListeCarteSurTable();
		listeCarteTue = new ArrayList<Carte>();
	}
	/**
	 * mettre les cartes du flop sur le plateau
	 * @param mode
	 */
	public void mettreCarteFlop(int mode)
	{
		tuer();
		for(int i =0; i < 3;i++)
		{
			ajouterCarteMilieu(i);
		}
		if(mode == 0)
		{
			new EnvoyerNouvellesCartes(listeCarteSurLaTable);
		}

	}
	/***
	 * ajoute une carte au milieu
	 * @param i
	 */
	private void ajouterCarteMilieu(int i)
	{
		listeCarteSurLaTable.add(listeCarte.get(0));
		RecupereImageFXML recuperationImage = new RecupereImageFXML();
		AnchorPane carte= recuperationImage.recupereImageFXMLCarte(listeCarte.get(0));

		PlateauDeJeu.getInstance().afficheCarteMilieu(i, carte);

		PlateauDeJeu.getInstance().getpMilieuCarte().getListeZoneCarte().get(i).setVisible(true);
		supprimerPremiereCarteDeLaListe(1);
	}
	/**
	 * met une seule carte sur le plateau
	 * @param mode
	 */
	public void mettreCarte(int mode,int carte)
	{
		tuer();
		ajouterCarteMilieu(carte);
		if(mode == 0)
		{
			new EnvoyerNouvellesCartes(listeCarteSurLaTable);
		}
	}
	/**
	 * reprend les cartes des joueurs
	 */
	public void reprendreCarteJoueur(){
		for(Joueur j:Partie.getInstance().getListeJoueur()){
			if(j.getMainJoueur() != null)
			{
				listeCarteTue.addAll(j.getMainJoueur().getListeCarte());
			}
		}
	}
	/**
	 * reinitialise le dealer 
	 */
	public void reinitialiser() {
		instance = null;
	}
	/**
	 * enleve les cartes de la table
	 */
	public void reinitialiseListeCarteSurTable()
	{
		listeCarteSurLaTable = new ArrayList<Carte>();
	}
	/**
	 * retourne la liste de carte sur la table
	 * @return
	 */
	public ArrayList<Carte> getListeCarteSurLaTable() {
		return listeCarteSurLaTable;
	}

}