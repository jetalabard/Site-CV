package application.modele;

import ihm.controleur.Attendre;
import ihm.controleur.action_table.ActionCliquerChargement;
import ihm.controleur.action_table.ActionDetermineGagnant;
import ihm.controleur.action_table.AttendQueToutLesJoueursAientDevoiles;
import ihm.controleur.action_table.affichage.ActionAfficheGagnantJeu;
import ihm.controleur.action_table.envoietelephone.ActionEnvoyerArgent;
import ihm.controleur.action_table.envoietelephone.ActionEnvoyerChangeTour;
import ihm.controleur.action_table.envoietelephone.ActionEnvoyerTrameDevoilerCarte;
import ihm.controleur.action_table.envoietelephone.EnvoyerNouvellesCartes;
import ihm.vue.plateau.PlateauDeJeu;
import ihm.vue.plateau.ZoneJoueur;

import java.util.ArrayList;

import javafx.application.Platform;
import application.dataloader.ParserJeton;
import application.metier.Joueur;
import application.metier.Pot;
import application.metier.PotParallele;
import application.metier.Tour;
import application.metier.TourNormal;
import application.metier.TourPreFlop;
import application.metier.TourRiver;

/**
 * definit un jeu d'une partie 
 * un jeu se compose de 4 tour
 * @author J�r�my
 *
 */
public class Jeu {

	/**
	 * permet de savoir si la partie est en cours
	 */
	private boolean encours;
	/**
	 * le pot principal
	 */
	private Pot potPrincipal = null;
	/**
	 * represente le pot qui est afficher
	 */
	private ListeJeton potAAfficher = null;
	/**
	 * la liste des joueurs encore en jeu
	 */
	private ArrayList<Joueur> listeJoueurEnJeu = null;
	/**
	 * gagnant du jeu
	 */
	private ArrayList<Joueur> gagnant = null;
	/**
	 * liste des joueurs ayant fait tapis
	 */
	private ArrayList<Joueur> listeJoueurTapis = null;
	/**
	 * liste des tour
	 */
	private ArrayList<Tour> listeTour;
	/**
	 * nom du tour actuel
	 */
	private String nomTourActuel;
	/**
	 * permet de savoir si les joueurs ont devoil�
	 */
	private boolean devoiler;
	/**
	 * permet de savoir si le joueur est en train de jouer
	 */
	private Joueur estEnTrainDeJouer;
	/**
	 * liste des joueurs ayant checker
	 */
	private ArrayList<Joueur> listeJoueurCheck;

	/**
	 * constructeur
	 */
	public Jeu () {
		devoiler = false;
		setListeJoueurCheck(new ArrayList<Joueur>());
		gagnant = new ArrayList<Joueur>();
		potPrincipal = new Pot();
		listeTour = new ArrayList<Tour>();
		listeJoueurTapis = new ArrayList<Joueur>();
		potAAfficher = new ListeJeton();
		potAAfficher.initialiseListeJeton();
	}
	/**
	 * demarre le jeu en commen�ant par le pr� flop
	 */
	public void demarrerJeu()
	{
		setEncours(true);
		TourPreFlop tour = new TourPreFlop();
		listeTour.add(tour);
		nomTourActuel = "PreFlop";
		listeTour.get(listeTour.indexOf(tour)).jouer();
	}
	/**
	 * retourne le tour en cours
	 * @return
	 */
	public Tour retourneTourEnCours()
	{
		if(listeTour.size() == 0)
		{
			return null;
		}
		else {
			return listeTour.get(listeTour.size()-1);
		}
	}


	public PotParallele retournePlusGrandPotParalleleParmiTousLesTours()
	{
		if(Partie.getInstance().getJeuEncours().getListeJoueurTapis().size() >0)
		{
			PotParallele pot = new PotParallele();
			ListeJeton liste = new ListeJeton();
			liste.initialiseListeJeton();
			pot.setTapisDeBase(liste);
			for(Tour t :listeTour)
			{
				if(t.retourneLePlusGrandPotParallele() != null)
				{
					if(pot.getTapisDeBase().retourneMontant()< t.retourneLePlusGrandPotParallele().getTapisDeBase().retourneMontant())
					{
						pot = t.retourneLePlusGrandPotParallele();
					}
				}
			}
			return pot;
		}
		else{
			return null;
		}
	}

	/**
	 * remplir le contenu des pots avec l'argent mis�e des bons joueurs
	 * @param i 
	 */
	public void gerePot()
	{
		for(Joueur j:listeJoueurEnJeu)
		{
			if(j.getListeJetonMise().retourneMontant()>0&& j.getJetonsDejaMise().retourneMontant()<=0)
			{
				j.getJetonsDejaMise().incrementeListeJetonAvecAutreListe(j.getListeJetonMise());
			}
			Tour t = retourneTourEnCours();
			for(PotParallele pot : t.getListePotParellele())
			{
				if(!listeJoueurTapis.contains(j))
				{
					if(j.getListeJetonMise().retourneMontant()>=pot.getTapisDeBase().retourneMontant())
					{
						pot.getMontant().incrementeListeJetonAvecAutreListe(pot.getTapisDeBase());
						pot.getListeJoueur().add(j);
					}
				}
			}
			PotParallele pot = Partie.getInstance().getJeuEncours().retourneTourEnCours().retourneLePlusGrandPotParallele();
			if(pot != null)
			{
				if(!listeJoueurTapis.contains(j))
				{
					j.getListeJetonMise().decrementeListeJetonAvecAutreListe(pot.getTapisDeBase());
				}
			}
			if(j.getAction().getNomAction() != "Tapis" && j.getListeJetonMise().retourneMontant()!=0)
			{
				///ajouter pot principal � pot parallele pour equilibreer
				potPrincipal.getMontant().incrementeListeJetonAvecAutreListe(j.getListeJetonMise());
				potPrincipal.getListeJoueur().add(j);
			}
		}
		Partie.getInstance().getJeuEncours().setPotAAfficher(1);
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				PlateauDeJeu.getInstance().getpMilieuCarte().mettreAJourZonePot(Partie.getInstance().getJeuEncours().getPotAAfficher());
			}
		});

	}

	/**
	 * si tous les joueurs ont fait tapis, on va au dernier tour et on regarde qui a gagn�
	 */
	public void allerAuDernierTour() {

		gerePot();
		reinitialiseListeJetonMiseJoueur();

		listeJoueurCheck=new ArrayList<Joueur>();  

		if(nomTourActuel == "PreFlop")
		{
			nomTourActuel = "River";
			Dealer.getInstance().mettreCarteFlop(1);
			Dealer.getInstance().mettreCarte(1,3);
			Dealer.getInstance().mettreCarte(1,4);

		}
		else if(nomTourActuel == "Flop")
		{
			nomTourActuel = "River";
			Dealer.getInstance().mettreCarte(1,3);
			Dealer.getInstance().mettreCarte(1,4);
		}
		else if(nomTourActuel == "Turn")
		{
			nomTourActuel = "River";
			Dealer.getInstance().mettreCarte(1,4);
		}

	}
	/**
	 * envoit les nouvelles cartes aux t�l�phones et demande de devoiler
	 */
	public void EnvoyerNewCartesEtDevoileCarte() {
		Platform.runLater(new Runnable() {

			@Override
			public void run() {
				new EnvoyerNouvellesCartes(Dealer.getInstance().getListeCarteSurLaTable());
			}
		});
		new ActionEnvoyerTrameDevoilerCarte();
		attendreQueTousLesJoueursDevoile();
		attendre();
		Partie.getInstance().getJeuEncours().faireFinDeJeu(0);
	}

	/**
	 * attend  que tous les joueurs aient d�voil� leurs cartes
	 */
	private void attendreQueTousLesJoueursDevoile() {
		synchronized (AttendQueToutLesJoueursAientDevoiles.getInstance()) {
			try {
				AttendQueToutLesJoueursAientDevoiles.getInstance().wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	/**
	 * attend 4 secondes
	 */
	private void attendre() {
		Attendre attend = new Attendre(4000);
		synchronized (attend) {
			try {
				attend.wait();
			} catch (InterruptedException e) {
			}
		}
	}
	/**
	 * passe au tour suivant
	 */
	public void changeTour() {

		gerePot();
		reinitialiseListeJetonMiseJoueur();

		listeJoueurCheck=new ArrayList<Joueur>();  

		if(nomTourActuel == "PreFlop")
		{
			nomTourActuel = "Flop";
			TourNormal tn = new TourNormal();
			listeTour.add(tn);
			listeTour.get(1).jouer();
		}
		else if(nomTourActuel == "Flop")
		{
			nomTourActuel = "Turn";
			TourNormal tn = new TourNormal();
			listeTour.add(tn);
			listeTour.get(2).jouer();

		}
		else if(nomTourActuel == "Turn")
		{
			nomTourActuel = "River";
			listeTour.add(new TourRiver());
			listeTour.get(3).jouer();
		}
		if(nomTourActuel != "FinJeu")
		{
			new ActionEnvoyerChangeTour();
		}

	}
	/**
	 * reinitialise liste jeton mis� du joueur
	 */
	private void reinitialiseListeJetonMiseJoueur() {
		for(Joueur j: listeJoueurEnJeu)
		{
			j.setListeJetonMise(new ListeJeton());
			j.getListeJetonMise().initialiseListeJeton();
			
			
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					ParserJeton parser =new ParserJeton();
					parser.mettreAJourDocumentMisesJoueur(j);
					PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).getMise().setText("0");
					PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).creerZoneMise(j);
				}
			});
			j.setNbRelanceAuTour(0);
		}
	}
	/**
	 * arrete le jeu
	 */
	public void arreter() {
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				for(ZoneJoueur zj: PlateauDeJeu.getInstance().getListeZoneJoueur())
				{
					zj.effaceWinner();
				}
			}
		});
		Partie.getInstance().setJeuEncours(null);
		ActionCliquerChargement.cpt = 1;
		Partie.getInstance().passerAuJeuSuivant();
	}

	/**
	 * finir le jeu
	 */
	public void finirJeu()
	{
		encours = false;
	}

	/**
	 * quand le jeu est finit, on d�termine le gagnant et on lui envoit les jetons
	 * @param mode
	 */
	public void faireFinDeJeu(int mode) {
		if (mode==0){
			// cas normal
			new ActionDetermineGagnant();
		}else{
			// cas coucher
			Partie.getInstance().getJeuEncours().getGagnant().add(Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().get(0));
			for(Joueur j : Partie.getInstance().getListeJoueur())
			{
				Platform.runLater(new Runnable() {
					@Override
					public void run() {
						PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).mettreAJourJeton(j);
					}
				});
			}
			new ActionEnvoyerArgent(null);
		}
		finirJeu();
		new ActionAfficheGagnantJeu();
	}	

	/**
	 * retourne la liste des joueurs ayant fait tapis
	 * @return
	 */
	public ArrayList<Joueur> getListeJoueurTapis() {
		return listeJoueurTapis;
	}
	/**
	 * modifie la listeJoueurTapis
	 * @param listeJoueurTapis
	 */
	public void setListeJoueurTapis(ArrayList<Joueur> listeJoueurTapis) {
		this.listeJoueurTapis = listeJoueurTapis;
	}
	/**
	 * retourne le nom du tour
	 * @return
	 */
	public String getNomTourActuel() {
		return nomTourActuel;
	}
	/**
	 * modifie le nom du tour
	 * @param nomTourActuel
	 */
	public void setNomTourActuel(String nomTourActuel) {
		this.nomTourActuel = nomTourActuel;
	}
	/**
	 * retourne le boolean pour savoir si le jeu est en cours
	 * @return
	 */
	public boolean isEncours() {
		return encours;
	}
	/**
	 * modifie le boolean enCours
	 * @param encours
	 */
	public void setEncours(boolean encours) {
		this.encours = encours;
	}
	/**
	 * retourne le pot principale
	 * @return
	 */
	public Pot getPotPrincipal() {
		return potPrincipal;
	}
	/**
	 * modifie le pot principale
	 * @param potPrincipal
	 */
	public void setPotPrincipal(Pot potPrincipal) {
		this.potPrincipal = potPrincipal;
	}
	/**
	 * retourne la liste des joueurs en jeu
	 * @return
	 */
	public ArrayList<Joueur> getListeJoueurEnJeu() {
		return listeJoueurEnJeu;
	}
	/**
	 * modifie la liste des joueurs en jeu
	 * @param listeJoueurEnJeu
	 */
	public void setListeJoueurEnJeu(ArrayList<Joueur> listeJoueurEnJeu) {
		this.listeJoueurEnJeu = listeJoueurEnJeu;
	}
	/**
	 * retourne le gagnant du jeu
	 * @return
	 */
	public ArrayList<Joueur> getGagnant() {
		return gagnant;
	}
	/**
	 * modifie le gagnant du jeu
	 * @param gagnant
	 */
	public void setGagnant(ArrayList<Joueur> gagnant) {
		this.gagnant = gagnant;
	}

	/**
	 * retourne la liste des tours
	 * @return
	 */
	public ArrayList<Tour> getListeTour() {
		return listeTour;
	}
	/***
	 * modifie la liste des tours
	 * @param listeTour
	 */
	public void setListeTour(ArrayList<Tour> listeTour) {
		this.listeTour = listeTour;
	}
	/**
	 * retourne le joueur qui est en train de jouer
	 * @return
	 */
	public Joueur getEstEnTrainDeJouer() {
		return estEnTrainDeJouer;
	}
	/**
	 * modifie le joueur qui est en train de jouer
	 * @param estEnTrainDeJouer
	 */
	public void setEstEnTrainDeJouer(Joueur estEnTrainDeJouer) {
		this.estEnTrainDeJouer = estEnTrainDeJouer;
	}
	/**
	 * retourne le boolean pour savoir si les cartes des joeurs ont �t� devoil�es
	 * @return
	 */
	public boolean isDevoiler() {
		return devoiler;
	}
	/**
	 * modifie le boolean estDevoiler
	 * @param devoiler
	 */
	public void setDevoiler(boolean devoiler) {
		this.devoiler = devoiler;
	}
	/**
	 * retourne la liste des joueurs qui ont ch�ck�s
	 * @return
	 */
	public ArrayList<Joueur> getListeJoueurCheck() {
		return listeJoueurCheck;
	}
	/**
	 * modifie la liste des joueurs qui ont ch�ck�s
	 * @param listeJoueurCheck
	 */
	public void setListeJoueurCheck(ArrayList<Joueur> listeJoueurCheck) {
		this.listeJoueurCheck = listeJoueurCheck;
	}
	/**
	 * retourne la liste des jetons du pot d'affichage
	 * @return
	 */
	public ListeJeton getPotAAfficher() {
		return potAAfficher;
	}
	/**
	 * modifie la liste de jeton du pot d'affichage en fonction de tout les pots
	 * @param i 
	 * @param potAAfficher
	 */
	public void setPotAAfficher(int i) {
		if(i == 0)
		{
			potAAfficher =new ListeJeton();
			potAAfficher.initialiseListeJeton();
		}
		else{

			potAAfficher =new ListeJeton();
			potAAfficher.initialiseListeJeton();
			for(Tour t : Partie.getInstance().getJeuEncours().getListeTour())
			{
				for(PotParallele pot :t.getListePotParellele())
				{
					potAAfficher.incrementeListeJetonAvecAutreListe(pot.getTapisDeBase());
				}
			}
			potAAfficher.incrementeListeJetonAvecAutreListe(potPrincipal.getMontant());
			System.out.println("pot affch� : " + potAAfficher.retourneMontant());
		}
	}
	public PotParallele retournePlusGrandPotParalleleParmiTousLesTours(
			PotParallele potParalleleDejaGagne) {
		if(Partie.getInstance().getJeuEncours().getListeJoueurTapis().size() >0)
		{
			PotParallele pot = new PotParallele();
			ListeJeton liste = new ListeJeton();
			liste.initialiseListeJeton();
			pot.setTapisDeBase(liste);
			for(Tour t :listeTour)
			{
				if(t.retourneLePlusGrandPotParallele() != null)
				{
					if(pot.getTapisDeBase().retourneMontant()< t.retourneLePlusGrandPotParallele().getTapisDeBase().retourneMontant())
					{
						if(retournePlusGrandPotParalleleParmiTousLesTours() == potParalleleDejaGagne)
						{
							pot = t.retourneLePlusGrandPotParallele();
						}
					}
				}
			}
			return pot;
		}
		else{
			return null;
		}
	}
}
