package application.modele;

import java.util.ArrayList;

import application.metier.Carte;

/**
 * liste de cartes 
 * @author J�r�my
 *
 */
public class ListeCartes {
	/**
	 * liste de cartes
	 */
	private ArrayList<Carte> listeCarte;
	/**
	 * instance de listeCartes
	 */
	private static ListeCartes instance;
	/**
	 * coinstructeur
	 */
	private ListeCartes() {
		listeCarte = new ArrayList<>();
	}
	/**
	 * retourne l'instance de ListeCartes
	 * @return
	 */
	public static ListeCartes getInstance() {
		if(instance == null)
		{
			instance = new ListeCartes();
		}
		
		return instance;
	}
	/**
	 * retourne la liste des cartes
	 * @return
	 */
	public ArrayList<Carte> getListeCarte() {
		return listeCarte;
	}
}
