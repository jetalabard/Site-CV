package application.modele;

import java.util.HashMap;
import java.util.Set;

import application.metier.Jeton;

/**
 * d�finit une liste de jeton
 * @author J�r�my
 *
 */
@SuppressWarnings("serial")
public class ListeJeton extends HashMap<String, Jeton>{

	/**
	 * constructeur
	 * @param liste
	 */
	public ListeJeton(ListeJeton liste) {
		this.putAll(liste);
	}
	/**
	 * constructeur par d�faut
	 */
	public ListeJeton() {
		
	}

	/**
	 * initialise la liste des jetons en fonction de la configuration
	 */
	public void initialiseListeJetonEnFonctionDeLaConfiguration() {
		Configuration config = Configuration.getInstance();
		this.put("0", new Jeton(config.getListeConfigJetons().get("vJ0"),config.getListeConfigJetons().get("qJ0")));
		this.put("1", new Jeton(config.getListeConfigJetons().get("vJ1"),config.getListeConfigJetons().get("qJ1")));
		this.put("2", new Jeton(config.getListeConfigJetons().get("vJ2"),config.getListeConfigJetons().get("qJ2")));
		this.put("3", new Jeton(config.getListeConfigJetons().get("vJ3"),config.getListeConfigJetons().get("qJ3")));
		this.put("4", new Jeton(config.getListeConfigJetons().get("vJ4"),config.getListeConfigJetons().get("qJ4")));
	}
	/**
	 * remet la liste de jeton � 0
	 */
	public void initialiseListeJeton() {
		Configuration config = Configuration.getInstance();
		this.put("0", new Jeton(config.getListeConfigJetons().get("vJ0"),0));
		this.put("1", new Jeton(config.getListeConfigJetons().get("vJ1"),0));
		this.put("2", new Jeton(config.getListeConfigJetons().get("vJ2"),0));
		this.put("3", new Jeton(config.getListeConfigJetons().get("vJ3"),0));
		this.put("4", new Jeton(config.getListeConfigJetons().get("vJ4"),0));
	}
	/**
	 * retourne le montant de la liste de jeton
	 * @return
	 */
	public int retourneMontant()
	{
		Set<Entry<String, Jeton>> listeBlind = this.entrySet();
		int montant = 0;
		for(Entry<String,Jeton> entry: listeBlind )
		{
			if(entry.getValue().getQuantite()!=0)
			{
				montant+=entry.getValue().getValeur()*entry.getValue().getQuantite();
			}
		}
		return montant;
	}
	/***
	 * soustrait la quantit� de jetons de la liste par rapport � une autre liste de jeton
	 * @param liste
	 */
	public void decrementeListeJetonAvecAutreListe(ListeJeton liste) {

		Set<Entry<String, Jeton>> listeMise = liste.entrySet();
		Set<Entry<String, Jeton>> listeJeton = this.entrySet();
		for(Entry<String,Jeton> entryMise:listeMise )
		{
			for(Entry<String,Jeton> entryJeton:listeJeton )
			{
				if(entryMise.getKey() == entryJeton.getKey())
				{
					entryJeton.getValue().setQuantite(entryJeton.getValue().getQuantite()-entryMise.getValue().getQuantite());
				}
			}
		}
	}
	/***
	 * ajoute la quantit� de jetons de la liste par rapport � une autre liste de jeton
	 * @param liste
	 */
	public  void incrementeListeJetonAvecAutreListe(ListeJeton liste) {

		Set<Entry<String, Jeton>> listeMise = liste.entrySet();
		Set<Entry<String, Jeton>> listeJeton = this.entrySet();
		
		for(Entry<String,Jeton> entryMise:listeMise )
		{
			for(Entry<String,Jeton> entryJeton:listeJeton )
			{
				if(entryMise.getKey() == entryJeton.getKey())
				{
					entryJeton.getValue().setQuantite(new Integer(entryJeton.getValue().getQuantite()+entryMise.getValue().getQuantite()));
				}
			}
		}
	}
	
	/**
	 * multiplie la quantit� de jeton par i
	 * @param i
	 */
	public void multipliePar(int i) {
		for(Entry<String,Jeton> entry : this.entrySet())
		{
			entry.getValue().setQuantite(entry.getValue().getQuantite()*i);
		}
		
	}
	/**
	 * divise une liste de jeton par un nombre de joueurs donn�s
	 * @param size
	 * @return
	 */
	public ListeJeton diviserParNombredeGagnant(int size) {
		ListeJeton listeJeton = new ListeJeton();
		listeJeton.initialiseListeJeton();
		
		for(Entry<String,Jeton> entry : listeJeton.entrySet())
		{
			for(Entry<String,Jeton> entrythis : this.entrySet())
			{
				if(entry.getKey() == entrythis.getKey())
				{
					entry.getValue().setQuantite(entrythis.getValue().getQuantite()/size);
				}
			}
		}
		return listeJeton;
	}
	
}
