package application.modele;

import ihm.controleur.action_table.ActionCliquerChargement;
import ihm.controleur.action_table.ActionDemarrerNouveauJeu;
import ihm.controleur.action_table.ActionRetourMenuPrincipal;
import ihm.controleur.action_table.envoietelephone.ActionEnvoyerNouveauJeu;
import ihm.controleur.actionjoueur.GererActionJoueur;
import ihm.controleur.actionjoueur.Quitter;
import ihm.vue.plateau.PlateauDeJeu;
import ihm.vue.plateau.ZoneJoueur;

import java.util.ArrayList;
import java.util.List;

import javafx.application.Platform;
import javafx.stage.Stage;
import application.metier.Joueur;

/**
 * definit une partie de poker
 * @author J�r�my
 *
 */
public class Partie {
	/**
	 * permet de savoir si la partie est en cours
	 */
	private boolean encours;
	/**
	 * instance de la Partie
	 */
	private static Partie instance;
	/**
	 * nombre de joueur de la partie
	 */
	private int nbJoueur;
	/**
	 * gagnant de la partie
	 */
	private Joueur gagnant;
	/**
	 * liste de joueur
	 */
	private ArrayList<Joueur> listeJoueur;
	/**
	 * liste de tout les jeux
	 */
	private List<Jeu> listeJeu;
	/**
	 * jeu en cours
	 */
	private Jeu jeuEncours;
	/**
	 * joueur qui paye la petite Blind
	 */
	private Joueur joueurPayePetiteBlind;
	/**
	 * stage JavaFX
	 */
	private Stage stage;
	/**
	 * retourne l'instance de la Partie
	 * @return
	 */
	public static Partie getInstance()
	{
		if(instance == null)
		{
			instance = new Partie();
		}
		return instance;
	}
	/**
	 * constructeur
	 */
	private Partie() {
		setListeJoueur(new ArrayList<Joueur>());
		encours = false;
		setNbJoueur(0);
		listeJeu = new ArrayList<Jeu>();
		setGagnant(null);		
		setDernierJoueurPayePetiteBlind(null);
	}

	/**
	 * arrete la partie
	 */
	public void arreter()
	{
		setEncours(false);
		listeJeu = new ArrayList<Jeu>();
		setGagnant(null);		
		ActionCliquerChargement.cpt = 1;
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				for(ZoneJoueur zj: PlateauDeJeu.getInstance().getListeZoneJoueur())
				{
					zj.effaceWinner();
				}
				PlateauDeJeu.getInstance().affiche();
			}
		});
	}

	/***
	 * gere Qui Doit payer la blind
	 * @return
	 */
	public Joueur gererJoueurQuiPayeBlind()
	{
		effaceBlind();

		if(joueurPayePetiteBlind ==null)
		{			
			joueurPayePetiteBlind = Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().get(PlateauDeJeu.getInstance().getListeZoneJoueur().get(0).getNumeroZone());
		}
		else{
			int index = Partie.getInstance().recupereIndexJoueur(joueurPayePetiteBlind) + 1;
			if(index >= Partie.getInstance().getListeJoueur().size())
			{
				joueurPayePetiteBlind = Partie.getInstance().getListeJoueur().get(index-Partie.getInstance().getListeJoueur().size());
			}
			else{
				joueurPayePetiteBlind = Partie.getInstance().getListeJoueur().get(index);
			}
		}

		afficheJetonBlind();
		return joueurPayePetiteBlind;

	}
	/**
	 * efface les jetons de blinds des joueurs
	 */
	public void effaceBlind() {
		if(listeJeu.size() > 1)
		{
			//efface les jetons de blinds de l'ancien jeu
			for(ZoneJoueur zj : PlateauDeJeu.getInstance().getListeZoneJoueur())
			{
				if(!zj.isEstvide())
				{
					if(zj.getImageGrosseBlind().isVisible())
					{
						zj.getImageGrosseBlind().setVisible(false);
					}
					if(zj.getImagePetiteBlind().isVisible())
					{
						zj.getImagePetiteBlind().setVisible(false);
					}
				}
			}
		}
	}
	/**
	 * affiche les jetons des blinds
	 */
	public void afficheJetonBlind()
	{		
		PlateauDeJeu.getInstance().changerBlinds(Partie.getInstance().recupereIndexJoueur(joueurPayePetiteBlind));
	}
	/**
	 * demarre la partie
	 */
	public void demarrer()
	{
		setEncours(true);
		jeuEncours.demarrerJeu();
	}

	/**
	 * change de jeu
	 */
	public void changerJeu()
	{
		Dealer.getInstance().reinitialiseListeCarteSurTable();
		new ActionEnvoyerNouveauJeu();
	
		Jeu nouveauJeu = new ActionDemarrerNouveauJeu().demarrerJeu();
		nouveauJeu.setListeJoueurEnJeu(new ArrayList<Joueur>(listeJoueur));
		listeJeu.add(nouveauJeu);
		jeuEncours = listeJeu.get(listeJeu.indexOf(nouveauJeu));
		
	}
	/**
	 * met � jour le stage
	 * @param stage
	 */
	public void setStage(Stage stage)
	{
		this.stage = stage;
	}
	/**
	 * quitte la partie -> retour au menu principal
	 */
	public void quitter()
	{
		encours = false;
		new ActionRetourMenuPrincipal(stage);
	}
	/**
	 * on passe au jeu suivant
	 */
	public void passerAuJeuSuivant() {
		Dealer.getInstance().reprendreCarteJoueur();
		Dealer.getInstance().ramasserCarte();
		Dealer.getInstance().melange();
		regardeSiJoueurOntAssezDArgent();

	}
	/**
	 * regarde si les joueurs ont assez d'argent pour continuer
	 */
	private void regardeSiJoueurOntAssezDArgent() {

		siPlusAssezArgentQuitte();
		regardeSiGagnantPartie();
	}
	/***
	 * regarde si il reste plus qu'un joueur si oui alors c'est le gagnant de la partie
	 */
	private void regardeSiGagnantPartie() {
		if(Partie.getInstance().getListeJoueur().size() == 1)
		{
			try{
				Partie.getInstance().setGagnant(Partie.getInstance().getJeuEncours().getGagnant().get(0));
			}catch(Exception e)
			{
				Partie.getInstance().setGagnant(Partie.getInstance().getGagnant());
			}
		}
	}
	/**
	 * execute action quitter joueur si le joueur n'a plus assez d'argent pour le tour suivant
	 * @param compteur
	 * @return
	 */
	private void siPlusAssezArgentQuitte() {
		ArrayList<Joueur> joueursQuiQuittent= new ArrayList<Joueur>();
		for(Joueur j: listeJoueur)
		{
			if(j.getListeJeton().retourneMontant() <= Configuration.getInstance().getValeurGrosseBlind().retourneMontant())
			{
				Quitter quitte =  new Quitter("Quitter");
				quitte.setMode(1);
				j.setAction(quitte);
				joueursQuiQuittent.add(j);
			}
		}
		for(Joueur joueur:joueursQuiQuittent)
		{
			new GererActionJoueur(joueur);
		}
	}

	/**
	 * recupere index joueur dans la liste
	 * @param j
	 * @return
	 */
	public int recupereIndexJoueur(Joueur j) {
		return Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().indexOf(j);
	}

	/**
	 * reinitialise Partie
	 */
	public void reinitialise() {
		instance = null;
	}
	/**
	 * retourne true si la partie est en cours 
	 * @return
	 */
	public boolean isEncours() {
		return encours;
	}
	/**
	 * modifie le boolean est en cours
	 * @param encours
	 */
	public void setEncours(boolean encours) {
		this.encours = encours;
	}
	/**
	 * retourne le nombre de joueur de la partie
	 * @return
	 */
	public int getNbJoueur() {
		return nbJoueur;
	}
	/**
	 * modifie le nombre de joueur de la partie
	 * @param i
	 */
	public void setNbJoueur(int i) {
		nbJoueur = i;
	}
	/**
	 * retourne le gagnant 
	 * @return
	 */
	public Joueur getGagnant() {
		return gagnant;
	}
	/**
	 * modifie le gagnant
	 * @param gagnant
	 */
	public void setGagnant(Joueur gagnant) {
		this.gagnant = gagnant;
	}
	/**
	 * retourne la liste des jeux
	 * @return
	 */
	public List<Jeu> getListeJeu() {
		return listeJeu;
	}
	/**
	 * modifie la liste des jeux
	 * @param listeJeu
	 */
	public void setListeJeu(List<Jeu> listeJeu) {
		this.listeJeu = listeJeu;
	}
	/**
	 * retourne le jeu en cours
	 * @return
	 */
	synchronized public Jeu getJeuEncours() {
		return jeuEncours;
	}
	/**
	 * modifie le jeu en cours
	 * @param jeuEncours
	 */
	public void setJeuEncours(Jeu jeuEncours) {
		this.jeuEncours = jeuEncours;
	}
	/**
	 * retourne le dernier joueur a avoir pay� la blind
	 * @return
	 */
	public Joueur getDernierJoueurPayePetiteBlind() {
		return joueurPayePetiteBlind;
	}
	/**
	 * modifie le dernier joueur qui a pay� la blind
	 * @param dernierJoueurPayePetiteBlind
	 */
	public void setDernierJoueurPayePetiteBlind(Joueur dernierJoueurPayePetiteBlind) {
		this.joueurPayePetiteBlind = dernierJoueurPayePetiteBlind;
	}
	/**
	 * retourne la liste des joueurs de la partie
	 * @return
	 */
	public ArrayList<Joueur> getListeJoueur() {
		return listeJoueur;
	}
	/**
	 * modifie la liste des joueurs de la partie
	 * @param listeJoueur
	 */
	public void setListeJoueur(ArrayList<Joueur> listeJoueur) {
		this.listeJoueur = listeJoueur;
	}
	/**
	 * retourne l'instance de la classe partie
	 * @return
	 */
	public static Partie get()
	{
		return instance;
	}

}
