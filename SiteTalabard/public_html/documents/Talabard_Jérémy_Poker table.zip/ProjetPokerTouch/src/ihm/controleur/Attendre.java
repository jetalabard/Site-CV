package ihm.controleur;

public class Attendre  extends Thread
{
	
	private int temps;
	
	public Attendre(int t) {
		temps = t;
		start();
	}
	
	@Override
	public void run() {
		try {
			Thread.sleep(temps);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		synchronized (this) {
			this.notifyAll();
		}
	}

}
