package ihm.controleur;

import ihm.controleur.action_table.AttendQueToutLesJoueursAientDevoiles;
import ihm.controleur.action_table.envoietelephone.ActionEnvoyerTrameDevoilerCarte;
import ihm.vue.plateau.PlateauDeJeu;
import javafx.application.Platform;
import application.dataloader.ParserJeton;
import application.metier.Joueur;
import application.metier.Tour;
import application.modele.Jeu;
import application.modele.Partie;

public class AttendreQueActionFaiteEtDemandeJoueurSuivantDeJouer extends Thread{

	private ObserveActionJoueur observeur;

	private boolean estFermer;

	private Tour t;

	private Joueur j;

	public AttendreQueActionFaiteEtDemandeJoueurSuivantDeJouer(ObserveActionJoueur obs, Tour tour, Joueur j) {
		observeur = obs;
		estFermer = false;
		t= tour;
		this.j = j;
	}

	@Override
	public void run() {
		Jeu jeu = Partie.getInstance().getJeuEncours();
		waitSurObserveur();
		t.setChangeJoueurOk(true);
		if(jeu.getListeJoueurEnJeu().size()>=2)
		{
			vaAuTourSuivantOuChangeTour(jeu);
		}

	}

	private void waitSurObserveur() {
		synchronized (observeur) {
			try {
				observeur.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private void vaAuTourSuivantOuChangeTour(Jeu jeu) {

		int index = recupertBonIndexDuJoueurSuivant(jeu);

		if(j.getAction().getNomAction().equals("SeCoucher"))
		{
			if(Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().size()==2){

				for(Joueur j1:Partie.getInstance().getJeuEncours().getListeJoueurEnJeu()){
					Partie.getInstance().getJeuEncours().getPotPrincipal().getMontant().incrementeListeJetonAvecAutreListe(j1.getListeJetonMise());
					j1.getListeJetonMise().initialiseListeJeton();
					reinitialiseZoneJoueur(j1);
				}	
				Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().remove(j);
				Partie.getInstance().getJeuEncours().faireFinDeJeu(1);
			}
			else if(Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().size()-1 == Partie.getInstance().getJeuEncours().getListeJoueurTapis().size())
			{
			}
			else{
				Partie.getInstance().getJeuEncours().getPotPrincipal().getMontant().incrementeListeJetonAvecAutreListe(j.getListeJetonMise());
				j.getListeJetonMise().initialiseListeJeton();
				reinitialiseZoneJoueurEnLaissantCarte(j);
				if(regardeSiJoueursOntMemeMise() ==  true )
				{
					Partie.getInstance().getJeuEncours().changeTour();
				}
				else {
					t.faireTour(jeu.getListeJoueurEnJeu().get(index));
				}
				Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().remove(j);
			}
		}
		else if(j.getAction().getNomAction().equals("Tapis"))
		{
			Partie.getInstance().getJeuEncours().getListeJoueurTapis().add(j);
			
			if(Partie.getInstance().getJeuEncours().getListeJoueurTapis().size()!=Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().size()){
				t.faireTour(jeu.getListeJoueurEnJeu().get(index));
			}
			else if(Partie.getInstance().getJeuEncours().getListeJoueurTapis().size() ==Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().size()){

				Partie.getInstance().getJeuEncours().allerAuDernierTour();
				Partie.getInstance().getJeuEncours().EnvoyerNewCartesEtDevoileCarte();
			}
		}
		else if(j.getAction().getNomAction().equals("Checker")){
			if(jeu.getListeJoueurCheck().size()!=Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().size()){
				t.faireTour(jeu.getListeJoueurEnJeu().get(index));
			}
			else if(jeu.getListeJoueurCheck().size() == jeu.getListeJoueurEnJeu().size())
			{
				if(!jeu.getNomTourActuel().equals("River"))
				{
					Partie.getInstance().getJeuEncours().changeTour();
				}
				else{
					new ActionEnvoyerTrameDevoilerCarte();
					attendreQueTousLesJoueursDevoile();
					Partie.getInstance().getJeuEncours().faireFinDeJeu(0);
				}
			}
		}
		else {
			if(regardeSiJoueursOntMemeMise() ==  false && Partie.getInstance().getJeuEncours().isDevoiler() == false)
			{
				t.faireTour(jeu.getListeJoueurEnJeu().get(index));
			}
			else {
				if(jeu.getListeJoueurEnJeu().size()-jeu.getListeJoueurTapis().size()<2)
				{
					Partie.getInstance().getJeuEncours().allerAuDernierTour();
					Partie.getInstance().getJeuEncours().EnvoyerNewCartesEtDevoileCarte();
				}
				else if(Partie.getInstance().getJeuEncours().getNomTourActuel().equals("River"))	{
					Partie.getInstance().getJeuEncours().setNomTourActuel("FinJeu");
					Partie.getInstance().getJeuEncours().changeTour();
					new ActionEnvoyerTrameDevoilerCarte();
					attendreQueTousLesJoueursDevoile();
					Partie.getInstance().getJeuEncours().faireFinDeJeu(0);
				}
				else{
					changerDeTour();
				}
			}
		}
		synchronized (this) {
			this.notify();
		}
	}


	private void attendreQueTousLesJoueursDevoile() {
		synchronized (AttendQueToutLesJoueursAientDevoiles.getInstance()) {
			try {
				AttendQueToutLesJoueursAientDevoiles.getInstance().wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}


	private int recupertBonIndexDuJoueurSuivant(Jeu jeu) {
		int index = jeu.getListeJoueurEnJeu().indexOf(j)+1;
		if(index >= jeu.getListeJoueurEnJeu().size())
		{
			index = index -jeu.getListeJoueurEnJeu().size();
		}
		if(jeu.getListeJoueurTapis().contains(jeu.getListeJoueurEnJeu().get(index)))
		{
			index = index+1;
			if(index >= jeu.getListeJoueurEnJeu().size())
			{
				index = index -jeu.getListeJoueurEnJeu().size();
			}
		}
		return index;
	}

	private boolean regardeSiJoueursOntMemeMise() {
		Jeu jeu = Partie.getInstance().getJeuEncours();
		int compteur = 0;
		int miseMax=0;
		miseMax = calculMiseMax(jeu, miseMax);
		compteur = compteNombreJoueurAyantMemeMise(jeu, compteur, miseMax);
		if(compteur == jeu.getListeJoueurEnJeu().size())
		{
			return true;
		}
		else if(compteur == jeu.getListeJoueurEnJeu().size()-jeu.getListeJoueurTapis().size())
		{
			if(jeu.getListeJoueurEnJeu().size()-jeu.getListeJoueurTapis().size() >= 2)
			{
				return false;
			}
			return true;

		}
		else return false;
	}

	private void changerDeTour(){
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				if(Partie.get() != null)
				{
					Partie.getInstance().getJeuEncours().changeTour();
				}
			}
		});
		t.setChangeJoueurOk(false);
	}

	private int compteNombreJoueurAyantMemeMise(Jeu jeu, int compteur,int miseMax) {
		for (Joueur j:jeu.getListeJoueurEnJeu()){
			if(j.getListeJetonMise().retourneMontant()==miseMax && j.getListeJetonMise().retourneMontant() != 0){
				compteur++;
			}
		}
		return compteur;
	}

	private int calculMiseMax(Jeu jeu, int miseMax) {
		for(int i=0;i<jeu.getListeJoueurEnJeu().size();i++)
		{							
			int montantJoueur = jeu.getListeJoueurEnJeu().get(i).getListeJetonMise().retourneMontant();
			if(miseMax <= montantJoueur){
				miseMax=montantJoueur;
			}
		}
		return miseMax;
	}

	private void reinitialiseZoneJoueur(Joueur j){
		ParserJeton parser=new ParserJeton();
		parser.mettreAJourDocumentMisesJoueur(j);
		Platform.runLater(new Runnable() {

			@Override
			public void run() {
				PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).creerZoneMise(j);
			}
		});
	}

	private void reinitialiseZoneJoueurEnLaissantCarte(Joueur j){
		ParserJeton parser=new ParserJeton();
		parser.mettreAJourDocumentMisesJoueur(j);
		Platform.runLater(new Runnable() {

			@Override
			public void run() {
				PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).creerZoneMise(j);
			}
		});
	}

	public boolean isEstFermer() {
		return estFermer;
	}

	public void setEstFermer(boolean estFermer) {
		this.estFermer = estFermer;
	}

}