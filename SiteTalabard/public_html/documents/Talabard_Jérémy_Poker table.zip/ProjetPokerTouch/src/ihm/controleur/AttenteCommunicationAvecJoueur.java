package ihm.controleur;

import ihm.controleur.actionjoueur.GererActionJoueur;
import application.metier.Joueur;

public class AttenteCommunicationAvecJoueur extends Thread{

	private Joueur j;

	private boolean fin = false;

	private boolean ok = false;

	private void waitSurCommunicationJoueur() {
		synchronized (j.getCommunication()) {
			try {
				j.getCommunication().wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ok = true;
		}
		
	}

	public AttenteCommunicationAvecJoueur(Joueur j) {
		this.j = j;
	}

	@Override
	public void run() {
		while(!fin)
		{
				waitSurCommunicationJoueur();
				fin =true;
		}

		if(isOk())
		{
			new GererActionJoueur(j);
		}
	}

	public boolean isFin() {
		return fin;
	}

	public void setFin(boolean fin) {
		this.fin = fin;
	}

	public boolean isOk() {
		return ok;
	}

	public void setOk(boolean ok) {
		this.ok = ok;
	}
}
