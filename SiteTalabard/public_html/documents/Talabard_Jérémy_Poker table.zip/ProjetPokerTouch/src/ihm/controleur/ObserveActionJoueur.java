package ihm.controleur;

import ihm.vue.plateau.PlateauDeJeu;
import javafx.application.Platform;
import application.metier.Joueur;

public class ObserveActionJoueur extends Thread{
	
	private Joueur joueur;
	private boolean fin;
	private boolean ok;
	
	private void waitJoueur() {
		synchronized (joueur) {
			try {
				joueur.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			setOk(true);
		}
	}
	private void enleveCadreZoneJoueur() {
		synchronized (this) {
			this.notify();
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					int indexJoueur = joueur.getEmplacement();
					PlateauDeJeu.getInstance().getListeZoneJoueur().get(indexJoueur).getStyleClass().clear();
				}
			});
		}
	}
	public ObserveActionJoueur(Joueur j) {
		this.joueur = j;
	}
	@Override
	public void run() {
		while(!fin)
		{
				waitJoueur();
				enleveCadreZoneJoueur();
				fin = true;
		}
	}
	public boolean isOk() {
		return ok;
	}
	
	public boolean isFin() {
		return fin;
	}
	public boolean setOk(boolean ok) {
		this.ok = ok;
		return ok;
	}
}
