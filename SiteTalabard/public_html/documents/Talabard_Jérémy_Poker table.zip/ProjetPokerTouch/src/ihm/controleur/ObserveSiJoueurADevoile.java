package ihm.controleur;

import application.metier.Joueur;
import application.modele.Partie;

public class ObserveSiJoueurADevoile extends Thread{
	
	private Joueur joueur;
	private boolean fin;
	
	private void waitJoueur() {
		synchronized (joueur) {
			try {
				joueur.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	private void faireFinJeu() {
		Attendre attendre = new Attendre(4000);
		synchronized (attendre) {
			try {
				attendre.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		Partie.getInstance().getJeuEncours().faireFinDeJeu(0);
	}
	public ObserveSiJoueurADevoile(Joueur j) {
		this.joueur = j;
	}
	@Override
	public void run() {
		while(!fin)
		{
				waitJoueur();
				faireFinJeu();
				fin = true;
		}
		this.interrupt();
	}
	
	public boolean isFin() {
		return fin;
	}
}
