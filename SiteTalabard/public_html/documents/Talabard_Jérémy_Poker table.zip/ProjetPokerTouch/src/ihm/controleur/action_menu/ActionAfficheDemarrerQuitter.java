package ihm.controleur.action_menu;

import ihm.vue.menu.FenetreDemarrage;
import javafx.event.Event;
import javafx.event.EventHandler;

public class ActionAfficheDemarrerQuitter implements EventHandler<Event>{
	
	private FenetreDemarrage instanceDeLaFenetre;

	public ActionAfficheDemarrerQuitter(FenetreDemarrage fen){
		this.instanceDeLaFenetre=fen;
	}
	@Override
	public void handle(Event arg0) {
		instanceDeLaFenetre.afficherDemarrerPartie();
	}
	
}