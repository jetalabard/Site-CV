package ihm.controleur.action_menu;

import ihm.vue.menu.VueChoixNombreJetons;
import ihm.vue.menu.VueChoixValeursJetons;
import ihm.vue.menu.VueConfiguration;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import application.modele.Configuration;
import application.modele.ListeJeton;

public class ActionCliquerMoins implements  EventHandler<ActionEvent>{

	private Node instance=null;
	private VueChoixValeursJetons instanceDeLaFenetre=null;
	private VueConfiguration instanceConfig=null;
	private VueChoixNombreJetons instanceNombre=null;

	private int valeurPremierJeton = 1;

	private int id;

	public ActionCliquerMoins(Node vue, int id) {
		instance=vue;
		this.id=id;
	}

	private ListeJeton changerBlind(ListeJeton liste,String blind)
	{
		liste = new ListeJeton();
		liste.initialiseListeJeton();
		if(blind.equals("petite"))
		{
			int valeur=Integer.parseInt(instanceConfig.getValeurPetite().getText());
			liste = calculEtAjouteJeton(valeur,liste);
		}
		else{
			int valeur=Integer.parseInt(instanceConfig.getValeurGrosse().getText());
			liste = calculEtAjouteJeton(valeur,liste);
		}

		return liste;
	}

	private ListeJeton calculEtAjouteJeton(int valeur, ListeJeton liste)
	{
		for(int i =4;i>-1;i--)
		{
			if(valeur%Configuration.getInstance().getListeConfigJetons().get("vJ"+i) != valeur && valeur/Configuration.getInstance().getListeConfigJetons().get("vJ"+i) >=1)
			{
				liste = ajoute(i+"", valeur/Configuration.getInstance().getListeConfigJetons().get("vJ"+i), liste);
				valeur = valeur - (valeur/Configuration.getInstance().getListeConfigJetons().get("vJ"+i)*Configuration.getInstance().getListeConfigJetons().get("vJ"+i));
			}
		}
		return liste;
	}


	private ListeJeton ajoute(String id, int quantite,ListeJeton liste)
	{
		liste.get(id).setQuantite(liste.get(id).getQuantite()+quantite);
		return liste;
	}


	@Override
	public void handle(ActionEvent a) {
		if(instance.toString().contains("Valeurs")){
			instanceDeLaFenetre=(VueChoixValeursJetons) instance;
			diminuer(id);
		}else if (instance.toString().contains("VueConfiguration")){
			instanceConfig=(VueConfiguration)instance;
			diminuerConfig(id);
		}else if(instance.toString().contains("Nombre")){
			instanceNombre=(VueChoixNombreJetons)instance;
			diminuerNombre(id);
		}

	}

	private void diminuerNombre(int index) {
		int valeur=Integer.valueOf(instanceNombre.getListeLabelNombre().get(index).getText());
		if(valeur>1){
			Configuration.getInstance().changeQuantiteJeton(index,"-");
			instanceNombre.getListeLabelNombre().get(index).setText(String.valueOf(valeur-1));
			instanceNombre.getLbtotal().setText(String.valueOf(Configuration.getInstance().getArgentInitial()));
		}
	}

	private void diminuerConfig(int index) {
		if(index==1){
			moinsIndex1();
		}
		if(index==2){
			moinsIndex2();
		}
		if(index==3){
			int valeur=Integer.valueOf(instanceConfig.getValeurTour().getText());
			if (valeur>1){
				instanceConfig.getValeurTour().setText(String.valueOf((valeur-1)));
				Configuration.getInstance().setNbTourChangeBlind(valeur+1);
			}
		}
		if(index==4){
			boutonMoinsHeure();
		}

	}

	private void boutonMoinsHeure() {
		String temps[]=new String[2];
		temps=instanceConfig.getValeurTemps().getText().split("H");
		int heure=Integer.parseInt(temps[0]);
		int minutes=Integer.parseInt(temps[1]);
		if(heure>0){
			if(minutes==30){
				instanceConfig.getValeurTemps().setText(String.valueOf(heure)+"H"+"00");
			}else{
				instanceConfig.getValeurTemps().setText(String.valueOf(heure-1)+"H"+"30");
			}
		}else if(minutes==30){
			instanceConfig.getValeurTemps().setText("0H00");
		}
	}

	private void moinsIndex2() {
		int valeur=Integer.valueOf(instanceConfig.getValeurGrosse().getText());
		if(valeur - Configuration.getInstance().getListeConfigJetons().get("vJ0")*2>0)
		{
			if(valeur>2){
				if(valeur%2 != 0)
				{
					siImpair(valeur);
				}
				else{
					siPair(valeur);
				}
				Configuration.getInstance().setValeurPetiteBlind(changerBlind(Configuration.getInstance().getValeurPetiteBlind(),"petite"));
				Configuration.getInstance().setValeurGrosseBlind(changerBlind(Configuration.getInstance().getValeurGrosseBlind(),"grosse"));
			}
		}
	}

	private void siImpair(int valeur) {
		instanceConfig.getValeurGrosse().setText(
				String.valueOf((valeur-(Configuration.getInstance().getListeConfigJetons().get("vJ0")))));

		instanceConfig.getValeurPetite().setText(
				String.valueOf(Integer.parseInt(instanceConfig.getValeurGrosse().getText())/2));
	}

	private void siPair(int valeur) {
		instanceConfig.getValeurGrosse().setText(
				String.valueOf((valeur-(Configuration.getInstance().getListeConfigJetons().get("vJ0")*2))));

		instanceConfig.getValeurPetite().setText(
				String.valueOf(Integer.parseInt(instanceConfig.getValeurGrosse().getText())/2));
	}

	private void moinsIndex1() {
		int valeur=Integer.valueOf(instanceConfig.getValeurPetite().getText());
		if(valeur - Configuration.getInstance().getListeConfigJetons().get("vJ0")>0)
		{

			if (valeur>1){
				instanceConfig.getValeurPetite().setText(
						String.valueOf(valeur-Configuration.getInstance().getListeConfigJetons().get("vJ0")));
				instanceConfig.getValeurGrosse().setText(
						String.valueOf(Integer.parseInt(instanceConfig.getValeurPetite().getText())*2));
				Configuration.getInstance().setValeurPetiteBlind(changerBlind(Configuration.getInstance().getValeurPetiteBlind(),"petite"));
				Configuration.getInstance().setValeurGrosseBlind(changerBlind(Configuration.getInstance().getValeurGrosseBlind(),"grosse"));
			}
		}
	}

	public void diminuer(int index) {
		valeurPremierJeton = Integer.valueOf(instanceDeLaFenetre.getListeLabelJetons().get(0).getText());
		int valeurActuelle=Integer.valueOf(instanceDeLaFenetre.getListeLabelJetons().get(index).getText());
		if(index == 0)
		{
			if(valeurActuelle>1){
				instanceDeLaFenetre.getListeLabelJetons().get(index).setText(String.valueOf(valeurActuelle-1));
				Configuration.getInstance().changeValeur("vJ"+index,valeurActuelle- 1);
				changeAutreValeurs(index);
			}
		}
		else if(valeurActuelle>(index+1)*valeurPremierJeton){
			instanceDeLaFenetre.getListeLabelJetons().get(index).setText(String.valueOf(valeurActuelle-valeurPremierJeton));
			Configuration.getInstance().changeValeur("vJ"+index,valeurActuelle- valeurPremierJeton);
			regardeSiEgaleAUneAutreValeur(index);
		}
	}


	private void changeAutreValeurs(int index) {
		valeurPremierJeton = Integer.valueOf(instanceDeLaFenetre.getListeLabelJetons().get(0).getText());

		boolean tantQue = true;
		int k = 1;

		for(int i = 1; i<instanceDeLaFenetre.getListeLabelJetons().size();i++)
		{
			tantQue = true;
			int valeurActuelle = Integer.valueOf(instanceDeLaFenetre.getListeLabelJetons().get(i).getText());
			if(valeurActuelle%valeurPremierJeton != 0)
			{
				while(tantQue)
				{
					if(valeurPremierJeton * k > valeurActuelle)
					{
						valeurActuelle = valeurPremierJeton * k;
						instanceDeLaFenetre.getListeLabelJetons().get(i).setText(String.valueOf(valeurActuelle));	
						Configuration.getInstance().changeValeur("vJ"+i, valeurActuelle);
						regardeSiEgaleAUneAutreValeur(i);
						tantQue = false;
					}
					k++;
				}
			}
			else {
				if(valeurActuelle - valeurPremierJeton >0)
				{
					valeurActuelle = valeurActuelle- valeurPremierJeton ;
					instanceDeLaFenetre.getListeLabelJetons().get(i).setText(String.valueOf(valeurActuelle));	
					Configuration.getInstance().changeValeur("vJ"+i, valeurActuelle);
					regardeSiEgaleAUneAutreValeur(i);
				}
			}
		}


	}

	private void regardeSiEgaleAUneAutreValeur(int numeroLabel) {
		valeurPremierJeton = Integer.valueOf(instanceDeLaFenetre.getListeLabelJetons().get(0).getText());

		int valeurLabelActuelle=Integer.valueOf(instanceDeLaFenetre.getListeLabelJetons().get(numeroLabel).getText());
		int valeurLabelPrecedente = 0;
		
		if(numeroLabel == instanceDeLaFenetre.getListeLabelJetons().size()-1 ||numeroLabel !=0)
		{
			valeurLabelPrecedente = Integer.valueOf(instanceDeLaFenetre.getListeLabelJetons().get(numeroLabel-1).getText());
			
			if(valeurLabelActuelle == valeurLabelPrecedente)
			{
				valeurLabelActuelle = valeurLabelActuelle + valeurPremierJeton;
			}
			else if(valeurLabelActuelle < valeurLabelPrecedente){
				while(valeurLabelActuelle != valeurLabelPrecedente + valeurPremierJeton )
				{
					valeurLabelActuelle = valeurLabelActuelle + valeurPremierJeton;
				}
			}
			instanceDeLaFenetre.getListeLabelJetons().get(numeroLabel).setText(String.valueOf(valeurLabelActuelle));	
			Configuration.getInstance().changeValeur("vJ"+String.valueOf(numeroLabel), valeurLabelActuelle);
		}
	}

	public int getValeurPremierJeton() {
		return valeurPremierJeton;
	}

	public void setValeurPremierJeton(int valeurPremierJeton) {
		this.valeurPremierJeton = valeurPremierJeton;
	}
}
