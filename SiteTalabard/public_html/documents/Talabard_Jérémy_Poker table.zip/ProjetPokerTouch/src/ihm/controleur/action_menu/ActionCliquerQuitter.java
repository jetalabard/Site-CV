package ihm.controleur.action_menu;

import ihm.vue.menu.FenetreDemarrage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class ActionCliquerQuitter implements EventHandler<ActionEvent> {

	private FenetreDemarrage instanceFenetreDemarrage;

	public ActionCliquerQuitter(FenetreDemarrage fenetre) {
		this.instanceFenetreDemarrage=fenetre;
	}
	@Override
	public void handle(ActionEvent arg0) {
		instanceFenetreDemarrage.fermer();
		
	}
}
