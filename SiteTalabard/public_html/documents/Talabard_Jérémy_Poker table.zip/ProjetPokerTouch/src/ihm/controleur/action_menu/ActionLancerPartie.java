package ihm.controleur.action_menu;

import ihm.controleur.action_table.ActionDemarrerPartie;
import ihm.vue.menu.FenetreDemarrage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import application.modele.Configuration;

public class ActionLancerPartie implements EventHandler<ActionEvent>{

	private FenetreDemarrage instanceFenetreDemarrage;
	private Node instance;
	
	public ActionLancerPartie(FenetreDemarrage parent, Node vue) {
		this.instance=vue;
		this.instanceFenetreDemarrage=parent;
	}

	@Override
	public void handle(ActionEvent arg0) {
		
		if(instance.toString().contains("DemarrerParDefaut")){
			Configuration.getInstance().parDefaut();
			Configuration.getInstance().setPersonnalise(false);
			new ActionDemarrerPartie(instanceFenetreDemarrage.getStage());
		}else {
			Configuration.getInstance().reinitialiseBlind();
			new ActionDemarrerPartie(instanceFenetreDemarrage.getStage());	
		}
		
	}

}
