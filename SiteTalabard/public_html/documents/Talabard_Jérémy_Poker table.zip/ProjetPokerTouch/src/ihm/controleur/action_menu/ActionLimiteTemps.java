package ihm.controleur.action_menu;

import ihm.vue.menu.VueConfiguration;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class ActionLimiteTemps implements  EventHandler<ActionEvent>{

	private VueConfiguration instanceDeLaFenetre=null;

	
	public ActionLimiteTemps(VueConfiguration vue) {
		instanceDeLaFenetre=vue;

	}

	@Override
	public void handle(ActionEvent a) {
		instanceDeLaFenetre.afficherSectionLimite();
	}

}