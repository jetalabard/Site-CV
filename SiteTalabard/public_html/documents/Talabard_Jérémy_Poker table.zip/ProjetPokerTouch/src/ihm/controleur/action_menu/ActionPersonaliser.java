package ihm.controleur.action_menu;

import ihm.vue.menu.VueChoixNombreJetons;
import ihm.vue.menu.VueChoixValeursJetons;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;

public class ActionPersonaliser implements  EventHandler<ActionEvent>{

	private Node instance=null;
	private VueChoixNombreJetons instanceNombre=null;
	private VueChoixValeursJetons instanceValeur=null;
	
	public ActionPersonaliser(Node vue) {
		this.instance=vue;		
	}

	@Override
	public void handle(ActionEvent a) {
		if(instance.toString().contains("Valeurs")){
			instanceValeur=(VueChoixValeursJetons)instance;
			personnaliserValeursJetons();
		}else if(instance.toString().contains("Nombre")){
			instanceNombre=(VueChoixNombreJetons)instance;
			personnaliserNombreJetons();
		}
		
	}
	
	private void personnaliserNombreJetons() {
		for(Button b:instanceNombre.getListeBoutonMoins()){
			b.setVisible(true);
		}
		for(Button b:instanceNombre.getListeBoutonPlus()){
			b.setVisible(true);
		}
		instanceNombre.getPersonalisation().setVisible(false);
		instanceNombre.getPanelBasBouton().getDefaut().setVisible(true);
		
	}

	private void personnaliserValeursJetons(){
		for(Button b:instanceValeur.getListeBoutonMoins()){
			b.setVisible(true);
		}
		for(Button b:instanceValeur.getListeBoutonPlus()){
			b.setVisible(true);
		}
		instanceValeur.getPersonalisation().setVisible(false);
		instanceValeur.getPanelBasBouton().getDefaut().setVisible(true);
	}
	
}
