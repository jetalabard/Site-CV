package ihm.controleur.action_menu;

import ihm.vue.plateau.PlateauDeJeu;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import application.MainApp;

public class ActionRedimensionHeight implements ChangeListener<Number>{
	
	public MainApp instance;

	public ActionRedimensionHeight(MainApp mainApp) {
		this.instance=mainApp;
	}
	
	@Override
	public void changed(ObservableValue<? extends Number> observable,Number oldValue, Number newValue) {
		
		PlateauDeJeu.getInstance().setWindowHeight(newValue.doubleValue(), oldValue.doubleValue());
		
	}

}
