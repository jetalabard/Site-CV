package ihm.controleur.action_menu;

import ihm.vue.plateau.PlateauDeJeu;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import application.MainApp;

public class ActionRedimensionWidth implements ChangeListener<Number>{
	
	public MainApp instance;

	public ActionRedimensionWidth(MainApp mainApp) {
		this.instance=mainApp;
	}
	
	@Override
	public void changed(ObservableValue<? extends Number> observable,
			Number oldValue, Number newValue) {
		PlateauDeJeu.getInstance().setWindowWidth(newValue.doubleValue(),oldValue.doubleValue());
	}

}
