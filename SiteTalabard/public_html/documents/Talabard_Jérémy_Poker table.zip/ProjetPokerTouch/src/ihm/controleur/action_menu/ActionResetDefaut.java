package ihm.controleur.action_menu;

import ihm.vue.menu.VueChoixNombreJetons;
import ihm.vue.menu.VueChoixValeursJetons;
import ihm.vue.menu.VueConfiguration;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import application.modele.Configuration;

public class ActionResetDefaut implements  EventHandler<ActionEvent>{

	private Node instance;
	private VueChoixValeursJetons instanceValeur=null;
	private VueConfiguration instanceConfig=null;
	private VueChoixNombreJetons instanceNombre=null;

	public ActionResetDefaut(Node vue) {
		instance=vue;
	}

	@Override
	public void handle(ActionEvent a) {
		if(instance.toString().contains("Valeurs")){
			instanceValeur=(VueChoixValeursJetons)instance;
			resetDefaut();
		}
		else if(instance.toString().contains("VueConfiguration")){
			instanceConfig=(VueConfiguration)instance;
			resetDefautConfig();
		}else if(instance.toString().contains("Nombre")){
			instanceNombre=(VueChoixNombreJetons)instance;
			resetNombre();
		}
	}

	private void resetNombre() {
		Configuration.getInstance().parDefautNombre();
		for(int i=0;i<5;i++){
			instanceNombre.getListeLabelNombre().get(i).setText(String.valueOf(Configuration.getInstance().getListeConfigJetons().get("qJ"+i)));
		}
		instanceNombre.getLbtotal().setText(String.valueOf(Configuration.getInstance().getArgentInitial()));

	}

	


	private void resetDefautConfig() {
		Configuration.getInstance().parDefautConfig();
		instanceConfig.getValeurPetite().setText(String.valueOf(Configuration.getInstance().getValeurPetiteBlind().retourneMontant()));
		instanceConfig.getValeurGrosse().setText(String.valueOf(Configuration.getInstance().getValeurGrosseBlind().retourneMontant()));
		
		instanceConfig.getValeurTour().setText(String.valueOf(Configuration.getInstance().getNbTourChangeBlind()));

		if(instanceConfig.getLimit().isSelected()){
			instanceConfig.getTemps().setVisible(false);
		}
		instanceConfig.getNoLimit().setSelected(true);		
	}




	public void resetDefaut(){
		Configuration.getInstance().parDefautValeur();
		for (int i=0;i<5;i++){
			instanceValeur.getListeLabelJetons().get(i).setText(String.valueOf(Configuration.getInstance().getListeConfigJetons().get("vJ"+i)));
		}
		effaceBoutonPlusEtMoins();
		instanceValeur.getPersonalisation().setVisible(true);
		instanceValeur.getPanelBasBouton().getDefaut().setVisible(false);
	}

	private void effaceBoutonPlusEtMoins() {
		for(Button b:instanceValeur.getListeBoutonMoins()){
			b.setVisible(false);
		}
		for(Button b:instanceValeur.getListeBoutonPlus()){
			b.setVisible(false);
		}
	}

}
