package ihm.controleur.action_menu;

import ihm.vue.menu.FenetreDemarrage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;

public class ActionRetour implements EventHandler<ActionEvent>{

	private Node instance;
	private FenetreDemarrage instanceFenetreDemarrage;

	public ActionRetour(FenetreDemarrage parent,Node pageEnCours) {
		this.instanceFenetreDemarrage=parent;
		this.instance=pageEnCours;
	}

	@Override
	public void handle(ActionEvent arg0) {
		if(instance.toString().contains("Defaut")){
			instanceFenetreDemarrage.afficherDemarrerPartieR();
		}else if (instance.toString().contains("Configuration")){
			instanceFenetreDemarrage.afficherChoixNombreJetons();
		}else if(instance.toString().contains("Valeurs")){
			instanceFenetreDemarrage.afficherDemarrerDefaut();
		}else if(instance.toString().contains("Nombre")){
			instanceFenetreDemarrage.afficherChoixValeursJetons();
		}


	}

}
