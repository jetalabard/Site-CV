package ihm.controleur.action_menu;

import application.modele.Configuration;
import ihm.vue.menu.FenetreDemarrage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;

public class ActionSuivant implements EventHandler<ActionEvent>{

	private Node instance;
	private FenetreDemarrage instanceFenetreDemarrage;

	public ActionSuivant(FenetreDemarrage parent,Node pageEnCours) {
		this.instanceFenetreDemarrage=parent;
		this.instance=pageEnCours;
	}

	@Override
	public void handle(ActionEvent arg0) {
		if(instance.toString().contains("DemarrerPartie")){
			instanceFenetreDemarrage.afficherDemarrerDefaut();
		}else if(instance.toString().contains("DemarrerParDefaut")){
			instanceFenetreDemarrage.afficherChoixValeursJetons();
			Configuration.getInstance().setPersonnalise(true);
		}else if (instance.toString().contains("Configuration")){
			instanceFenetreDemarrage.afficherDemarrerPartie();
		}else if(instance.toString().contains("Valeurs")){
			instanceFenetreDemarrage.afficherChoixNombreJetons();
		}else if(instance.toString().contains("Nombre")){
			instanceFenetreDemarrage.afficherConfiguration();
		}
	}
}
