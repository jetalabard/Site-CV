package ihm.controleur.action_table;

import ihm.vue.plateau.PlateauDeJeu;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import application.modele.Configuration;
import application.modele.Partie;

public class ActionBoutonLancer implements EventHandler<ActionEvent>{

	@Override
	public void handle(ActionEvent event) {
		Configuration.getInstance().reinitialiseBlind();
		PlateauDeJeu.getInstance().afficherPanelCarte();
		Partie.getInstance().changerJeu();
		Partie.getInstance().demarrer();
		Partie.getInstance().setStage(PlateauDeJeu.getInstance().getStage());
		AttendQueToutLesJoueursAientDevoiles.getInstance().reinitailise();
	}

}
