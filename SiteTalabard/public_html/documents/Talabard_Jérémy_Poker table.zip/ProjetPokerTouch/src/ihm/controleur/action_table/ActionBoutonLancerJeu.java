package ihm.controleur.action_table;

import ihm.vue.plateau.PlateauDeJeu;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import application.modele.Configuration;
import application.modele.Partie;

public class ActionBoutonLancerJeu implements EventHandler<ActionEvent> {

	@Override
	public void handle(ActionEvent arg0) {
		
		if(Partie.getInstance().getJeuEncours().getGagnant().size()>0)
		{
			PlateauDeJeu.getInstance().getListeZoneJoueur().get(Partie.getInstance().getJeuEncours().getGagnant().get(0).getEmplacement()).effaceWinner();
		}
		
		Configuration.getInstance().reinitialiseBlind();

		PlateauDeJeu.getInstance().creerPanelCentre();
		PlateauDeJeu.getInstance().afficherPanelCarte();
		Partie.getInstance().changerJeu();
		Partie.getInstance().getJeuEncours().demarrerJeu();
		AttendQueToutLesJoueursAientDevoiles.getInstance().reinitailise();
	}
	
	
	
}
