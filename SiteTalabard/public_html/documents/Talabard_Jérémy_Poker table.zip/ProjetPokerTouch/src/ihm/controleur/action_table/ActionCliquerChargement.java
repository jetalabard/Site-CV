package ihm.controleur.action_table;

import javafx.application.Platform;
import ihm.vue.plateau.PlateauDeJeu;
import application.modele.Partie;

public class ActionCliquerChargement{

	public static int cpt=1;
	
	public ActionCliquerChargement(int mode) {
		affiche(mode);
	}

	private void affiche(int mode) {
		if (cpt==1) {
			if(Partie.getInstance().getNbJoueur()>=2)
			{
				Platform.runLater(new Runnable() {
					@Override
					public void run() {
						PlateauDeJeu.getInstance().afficherPanelBoutonLancer(mode);
					}
				});
			}
			cpt--;
		}
	}
}
