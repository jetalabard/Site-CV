package ihm.controleur.action_table;

import ihm.vue.plateau.PlateauDeJeu;
import ihm.vue.plateau.ZoneMilieu;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class ActionContinuer implements EventHandler<ActionEvent> {

	private ZoneMilieu instance;
	private int mode;
	
	public ActionContinuer(ZoneMilieu zone,int mode) {
		this.instance=zone;
		this.mode = mode;
	}
	
	@Override
	public void handle(ActionEvent arg0) {
		if(mode == 0)
		{
			PlateauDeJeu.getInstance().setCenter(instance);
		}
		else{
			PlateauDeJeu.getInstance().setCenter(PlateauDeJeu.getInstance().getpMilieuChargement());
		}

	}

}
