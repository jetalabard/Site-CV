package ihm.controleur.action_table;

import ihm.vue.plateau.PlateauDeJeu;
import application.modele.Jeu;
import application.modele.Partie;

public class ActionDemarrerNouveauJeu {
	
	public Jeu demarrerJeu()
	{
		Jeu j = null;
		if(PlateauDeJeu.getInstance()!=null || Partie.getInstance().isEncours() == false || Partie.getInstance().getGagnant()!= null||Partie.getInstance().getListeJoueur().size() <0)
		{
			j = new Jeu();
		}
		return j;
	}
}
