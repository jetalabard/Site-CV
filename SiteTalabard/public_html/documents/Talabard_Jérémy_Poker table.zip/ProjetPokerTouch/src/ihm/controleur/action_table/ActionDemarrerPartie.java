package ihm.controleur.action_table;

import ihm.vue.plateau.PlateauDeJeu;
import javafx.stage.Stage;

public class ActionDemarrerPartie{

	private Stage stage;

	public ActionDemarrerPartie(Stage stage) {

		this.stage = stage;
		new ActionDemarrerServeur();
		demarrePlateau();
		
	}

	public void demarrePlateau()
	{
		stage.getScene().setRoot(PlateauDeJeu.getInstance());
		stage.setScene(stage.getScene());
		PlateauDeJeu.getInstance().setStage(stage);
		PlateauDeJeu.getInstance().affiche();
	}
}
