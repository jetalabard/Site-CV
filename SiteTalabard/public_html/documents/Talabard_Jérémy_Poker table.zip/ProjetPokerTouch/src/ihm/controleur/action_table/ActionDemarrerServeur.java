package ihm.controleur.action_table;

import application.dataloader.reseau.SocketServeur;

public class ActionDemarrerServeur {
	
	public ActionDemarrerServeur() {
		SocketServeur socketServeur = new SocketServeur();
		socketServeur.ouvrirPort();
	}
}
