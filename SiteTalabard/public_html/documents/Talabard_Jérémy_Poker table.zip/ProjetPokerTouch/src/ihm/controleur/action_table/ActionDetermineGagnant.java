package ihm.controleur.action_table;

import ihm.controleur.action_table.envoietelephone.ActionEnvoyerArgent;
import ihm.controleur.action_table.envoietelephone.ActionEnvoyerPerdu;
import ihm.vue.plateau.PlateauDeJeu;

import java.util.ArrayList;
import java.util.List;

import javafx.application.Platform;
import application.dataloader.ParserJeton;
import application.metier.Joueur;
import application.metier.Valeur;
import application.modele.CalculValeur;
import application.modele.Partie;

public class ActionDetermineGagnant {

	private List<Joueur> listeJoueurEnJeu;
	private List<Joueur> listeJoueurGagnant;
	private ArrayList<Joueur> listeMemeMain;

	public ActionDetermineGagnant() {

		CalculValeur v = new CalculValeur();
		this.listeJoueurEnJeu = Partie.getInstance().getJeuEncours().getListeJoueurEnJeu();
		setListeJoueurGagnant(new ArrayList<Joueur>());
		if(listeJoueurEnJeu.size()>=2)
		{
			donneValeurMainAuJoueur();
			determineGagnant(v);
			mettreAJourZoneDeTousLesJoueurs();
			new ActionEnvoyerArgent(this);
		}
		else{
			Partie.getInstance().getJeuEncours().getGagnant().add(Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().get(0));
			mettreAJourZoneJoueursEtIncrementePot();
			new ActionEnvoyerArgent(this);
		}
		envoyerJoueursPerdus();
	}

	private void envoyerJoueursPerdus() {
		for(Joueur j : listeJoueurEnJeu)
		{
			if(!Partie.getInstance().getJeuEncours().getGagnant().contains(j))
			{
				new ActionEnvoyerPerdu(j, false);
			}
		}
	}

	private void mettreAJourZoneJoueursEtIncrementePot() {
		for(Joueur joueur :Partie.getInstance().getListeJoueur())
		{
			Partie.getInstance().getJeuEncours().getPotPrincipal().getMontant().incrementeListeJetonAvecAutreListe(joueur.getListeJetonMise());
			Platform.runLater(new Runnable() {

				@Override
				public void run() {
					ParserJeton parser =new ParserJeton();
					parser.mettreAJourDocumentMisesJoueur(joueur);
					PlateauDeJeu.getInstance().getListeZoneJoueur().get(joueur.getEmplacement()).creerZoneMise(joueur);
					PlateauDeJeu.getInstance().getListeZoneJoueur().get(joueur.getEmplacement()).mettreAJourJeton(joueur);
				}
			});
		}
	}

	private void mettreAJourZoneDeTousLesJoueurs() {
		for(Joueur joueur :Partie.getInstance().getListeJoueur())
		{
			// ajoute les mises des autres joueurs au pot
			Partie.getInstance().getJeuEncours().getPotPrincipal().getMontant().incrementeListeJetonAvecAutreListe(joueur.getListeJetonMise());
			Platform.runLater(new Runnable() {

				@Override
				public void run() {
					ParserJeton parser =new ParserJeton();
					parser.mettreAJourDocumentMisesJoueur(joueur);
					PlateauDeJeu.getInstance().getListeZoneJoueur().get(joueur.getEmplacement()).creerZoneMise(joueur);
					PlateauDeJeu.getInstance().getListeZoneJoueur().get(joueur.getEmplacement()).mettreAJourJeton(joueur);
				}
			});
		}
	}
	/**
	 * retourne le deuxieme gagnant
	 * @param gagnant
	 * @param autreJoueur
	 * @return
	 */
	public ArrayList<Joueur> retourneAutreGagnant(Joueur gagnant)
	{
		ArrayList<Joueur> listeJoueur = new ArrayList<Joueur>( Partie.getInstance().getJeuEncours().getListeJoueurEnJeu());
		if(listeJoueur.contains(gagnant))
		{
			listeJoueur.remove(gagnant);
		}
		return retourneJoueurAyantValeurPlusProcheDuGagnant(gagnant,listeJoueur);
	}

	private ArrayList<Joueur> retourneJoueurAyantValeurPlusProcheDuGagnant(Joueur gagnant,ArrayList<Joueur> listeJoueurQuiNOntPasFaitTapis) {
		Joueur deuxiemeGagnant = listeJoueurQuiNOntPasFaitTapis.get(0);
		for(Joueur j:listeJoueurQuiNOntPasFaitTapis)
		{
			if(deuxiemeGagnant.getValeur().getValeur() <j.getValeur().getValeur())
			{
				deuxiemeGagnant = j;
			}
		}
		if(listeMemeMain.contains(deuxiemeGagnant))
		{
			return listeMemeMain;
		}
		ArrayList<Joueur> liste = new ArrayList<Joueur>();
		liste.add(deuxiemeGagnant);
		return liste;
	}

	private void determineGagnant(CalculValeur v) {

		Joueur gagnantTemp = null;
		listeMemeMain = new ArrayList<Joueur>();
		gagnantTemp = listeJoueurEnJeu.get(0);

		for(int i = 1;i<listeJoueurEnJeu.size();i++)
		{
			gagnantTemp = v.comparerValeurDeuxJoueur(gagnantTemp, listeJoueurEnJeu.get(i));
			if(gagnantTemp == null)
			{
				gagnantTemp = listeJoueurEnJeu.get(i);
				if(!listeMemeMain.contains(listeJoueurEnJeu.get(i-1)))
				{
					listeMemeMain.add(listeJoueurEnJeu.get(i-1));
				}
				if(!listeMemeMain.contains(listeJoueurEnJeu.get(i)))
				{
					listeMemeMain.add(listeJoueurEnJeu.get(i));
				}
			}
		}
		if(listeMemeMain.contains(gagnantTemp))
		{
			for(Joueur j:listeMemeMain)
			{
				if(!Partie.getInstance().getJeuEncours().getListeJoueurTapis().contains(j))
				{
					Partie.getInstance().getJeuEncours().getPotPrincipal().getListeJoueur().add(j);
				}
				Partie.getInstance().getJeuEncours().getGagnant().add(j);
			}
		}
		else{
			if(!Partie.getInstance().getJeuEncours().getListeJoueurTapis().contains(gagnantTemp))
			{
				Partie.getInstance().getJeuEncours().getPotPrincipal().getListeJoueur().add(gagnantTemp);
			}
			Partie.getInstance().getJeuEncours().getGagnant().add(gagnantTemp);
		}
	}


	private void donneValeurMainAuJoueur() {
		for(Joueur j :listeJoueurEnJeu)
		{
			CalculValeur v = new CalculValeur();
			Valeur valeurJ1 = v.determineValeurJoueur(j);
			j.setValeur(valeurJ1);
		}

	}

	public List<Joueur> getListeJoueurGagnant() {
		return listeJoueurGagnant;
	}

	public void setListeJoueurGagnant(List<Joueur> listeJoueurGagnant) {
		this.listeJoueurGagnant = listeJoueurGagnant;
	}

}
