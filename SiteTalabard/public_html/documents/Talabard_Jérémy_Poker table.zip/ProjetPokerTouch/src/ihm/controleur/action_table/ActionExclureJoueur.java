package ihm.controleur.action_table;

import ihm.vue.plateau.PlateauDeJeu;

import java.net.Socket;

import javafx.application.Platform;
import application.metier.Joueur;
import application.modele.Partie;

public class ActionExclureJoueur {


	public Joueur regardeLeBonJoueurAExclure(Socket id) {
		for(Joueur j : Partie.getInstance().getListeJoueur())
		{
			if(j.getCommunication().getSocketClient() == id)
			{
				return j;
			}
		}
		return null;
	}

	public void exclureJoueur(Joueur j){
		if(j!= null)
		{
			int emplacement = j.getEmplacement();
			
			Partie.getInstance().setNbJoueur(Partie.getInstance().getNbJoueur()-1);
			
			if(Partie.getInstance().getJeuEncours() != null)
			{
				if(Partie.getInstance().getListeJoueur().contains(j))
				{
					if(Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().contains(j))
					{
						Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().remove(j);
					}
					Partie.getInstance().getListeJoueur().remove(j);
				}
			}
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					PlateauDeJeu.getInstance().getListeZoneJoueur().get(emplacement).reinitialise();
				}
			});
		}
		
	}
}
