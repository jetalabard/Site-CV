package ihm.controleur.action_table;

import application.dataloader.reseau.Reception_T;
import application.dataloader.reseau.SocketServeur;

public class ActionFermerServeur {

	public ActionFermerServeur() {
		
		if(SocketServeur.acceptation_T != null && SocketServeur.acceptation_T.getListeReception_T()!=null && SocketServeur.acceptation_T.getListeReception_T().size()!=0 ||  SocketServeur.acceptation_T.getListeReception_T() !=null)
		{
			for(Reception_T r : SocketServeur.acceptation_T.getListeReception_T())
			{
				r.fermer();
			}
		}
		if(SocketServeur.acceptation_T != null)
		{
			SocketServeur.acceptation_T.fermer();
		}
		if(SocketServeur.socketserver ==null)
		{
			SocketServeur.fermer();
		}
		
	}
}
