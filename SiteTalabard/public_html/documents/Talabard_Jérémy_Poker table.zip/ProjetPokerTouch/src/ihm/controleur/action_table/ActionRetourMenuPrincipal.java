package ihm.controleur.action_table;

import ihm.controleur.actionjoueur.GererActionJoueur;
import ihm.controleur.actionjoueur.Quitter;
import ihm.vue.menu.FenetreDemarrage;

import java.util.ArrayList;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import application.metier.Joueur;
import application.modele.Dealer;
import application.modele.Partie;

public class ActionRetourMenuPrincipal implements EventHandler<Event> {
	
	private Stage stage;
	
	public ActionRetourMenuPrincipal(Stage stage) {
		this.stage = stage;
	}

	@Override
	public void handle(Event arg0) {
		ArrayList<Joueur> joueursQuiQuittent = new ArrayList<Joueur>();
		for(Joueur j:Partie.getInstance().getListeJoueur())
		{
			Quitter quitte =  new Quitter("Quitter");
			quitte.setMode(2);
			j.setAction(quitte);
			joueursQuiQuittent.add(j);
		}
		for(Joueur joueur:joueursQuiQuittent)
		{
			new GererActionJoueur(joueur);
		}
		
		FenetreDemarrage root = new FenetreDemarrage(stage);
		
		root.afficherDemarrerPartieR();
		stage.getScene().setRoot(root);
		
		Partie.getInstance().reinitialise();
		Dealer.getInstance().reinitialiser();
		
		new ActionFermerServeur();
	}
}
