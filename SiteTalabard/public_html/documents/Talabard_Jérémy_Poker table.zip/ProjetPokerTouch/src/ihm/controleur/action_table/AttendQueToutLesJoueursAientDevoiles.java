package ihm.controleur.action_table;

import java.util.ArrayList;

import application.metier.Joueur;
import application.modele.Partie;

public class AttendQueToutLesJoueursAientDevoiles {
	
	private boolean devoile;
	
	private ArrayList<Joueur> listeJoueurAyantDevoile;
	
	private static AttendQueToutLesJoueursAientDevoiles instance;
	
	private AttendQueToutLesJoueursAientDevoiles() {
		setDevoile(false);
		setListeJoueurAyantDevoile(new ArrayList<Joueur>());
	}
	
	public static AttendQueToutLesJoueursAientDevoiles getInstance ()
	{
		if(instance == null)
		{
			instance = new AttendQueToutLesJoueursAientDevoiles();
		}
		return instance;
	}
	
	public void reinitailise()
	{
		devoile = false;
		listeJoueurAyantDevoile = new ArrayList<Joueur>();
	}
	
	
	public void ajouteJoueurQuiADevoile(Joueur j)
	{
		listeJoueurAyantDevoile.add(j);
		if(listeJoueurAyantDevoile.size() == Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().size())
		{
			setDevoile(true);
			synchronized (this) {
				this.notify();
			}
		}
	}
	


	public boolean isDevoile() {
		return devoile;
	}


	public void setDevoile(boolean devoile) {
		this.devoile = devoile;
	}


	public ArrayList<Joueur> getListeJoueurAyantDevoile() {
		return listeJoueurAyantDevoile;
	}


	public void setListeJoueurAyantDevoile(ArrayList<Joueur> listeJoueurAyantDevoile) {
		this.listeJoueurAyantDevoile = listeJoueurAyantDevoile;
	}
}
