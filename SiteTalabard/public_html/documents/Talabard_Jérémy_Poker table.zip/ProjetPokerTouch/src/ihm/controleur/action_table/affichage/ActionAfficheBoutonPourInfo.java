package ihm.controleur.action_table.affichage;

import ihm.vue.plateau.PlateauDeJeu;
import javafx.event.Event;
import javafx.event.EventHandler;

public class ActionAfficheBoutonPourInfo implements EventHandler<Event>{

	private int mode;
	public ActionAfficheBoutonPourInfo(int mode) {
		this.mode = mode;
	}
	
	@Override
	public void handle(Event arg0) {
		if(mode == 0)
		{
			PlateauDeJeu.getInstance().getpMilieuCarte().afficheMenu();
		}
		else if(PlateauDeJeu.getInstance().getpMilieuChargement() != null){
			PlateauDeJeu.getInstance().getpMilieuChargement().affiche();
		}
	}
}
