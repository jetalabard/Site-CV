package ihm.controleur.action_table.affichage;

import javafx.application.Platform;
import ihm.controleur.Attendre;
import ihm.controleur.action_table.ActionCliquerChargement;
import ihm.vue.plateau.PlateauDeJeu;
import application.metier.Joueur;
import application.modele.Partie;

public class ActionAfficheGagnantJeu {

	public ActionAfficheGagnantJeu() {

		if(Partie.getInstance().getJeuEncours() != null)
		{
			for(Joueur j :Partie.getInstance().getJeuEncours().getGagnant())
			{
				Platform.runLater(new Runnable() {
					
					@Override
					public void run() {
						PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).afficherWinner();
					}
				});
			}
		}

		Attendre attendre = new Attendre(6000);
		synchronized (attendre) {
			try {
				attendre.wait();
			} catch (InterruptedException e) {
			}
		}

		if(Partie.getInstance().getListeJoueur().size()>=2)
		{
			ActionCliquerChargement.cpt = 1;
			Partie.getInstance().getJeuEncours().setEncours(false);
			Partie.getInstance().passerAuJeuSuivant();
			PlateauDeJeu.getInstance().affiche();
		}
		else {
			PlateauDeJeu.getInstance().affiche();
		}

	}
}
