package ihm.controleur.action_table.affichage;

import ihm.vue.plateau.PlateauDeJeu;
import javafx.application.Platform;
import application.dataloader.reseau.CreateurDeTrame;
import application.metier.Joueur;
public class ActionAfficherGagnantPartie {

	
	public ActionAfficherGagnantPartie(Joueur joueur) {
		
		envoyerTramePourLeGagnant(joueur);
		
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				PlateauDeJeu.getInstance().afficherGagnant(joueur);
			}
		});
	}
	public void envoyerTramePourLeGagnant(Joueur j)
	{
		CreateurDeTrame cdt = new CreateurDeTrame("3GA",true);
		j.getCommunication().getOut().println(cdt.getTrame());
		j.getCommunication().getOut().flush();
	}

}
