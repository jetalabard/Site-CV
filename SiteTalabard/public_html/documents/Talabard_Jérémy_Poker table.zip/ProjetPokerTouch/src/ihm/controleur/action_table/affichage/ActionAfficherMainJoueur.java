package ihm.controleur.action_table.affichage;

import ihm.controleur.action_table.AttendQueToutLesJoueursAientDevoiles;
import ihm.vue.plateau.PlateauDeJeu;

import java.net.Socket;

import javafx.application.Platform;
import application.metier.Joueur;
import application.modele.Partie;

public class ActionAfficherMainJoueur {

	private Joueur j;
	
	public ActionAfficherMainJoueur(Socket socketClient) {

		for(Joueur j : Partie.getInstance().getListeJoueur())
		{
			if(j.getCommunication().getSocketClient() == socketClient)
			{
				this.j = j;
				Platform.runLater(new Runnable() {
					@Override
					public void run() {
						PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).afficherMainJoueur(j);
					}
				});
				this.j.setDevoile(true);
			}
		}

		AttendQueToutLesJoueursAientDevoiles.getInstance().ajouteJoueurQuiADevoile(this.j);
	}

}
