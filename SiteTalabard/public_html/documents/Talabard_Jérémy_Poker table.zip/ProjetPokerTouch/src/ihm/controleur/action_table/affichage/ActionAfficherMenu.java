package ihm.controleur.action_table.affichage;

import ihm.vue.plateau.PlateauDeJeu;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class ActionAfficherMenu implements EventHandler<ActionEvent> {

	private int mode;
	
	public ActionAfficherMenu(int mode) {
		this.mode = mode;
	}
	
	@Override
	public void handle(ActionEvent event) {
		PlateauDeJeu.getInstance().afficherMenu(mode);

	}

}
