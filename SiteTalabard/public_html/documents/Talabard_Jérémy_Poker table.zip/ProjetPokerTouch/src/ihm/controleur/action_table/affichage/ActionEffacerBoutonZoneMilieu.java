package ihm.controleur.action_table.affichage;


import ihm.vue.plateau.PlateauDeJeu;
import javafx.event.Event;
import javafx.event.EventHandler;

public class ActionEffacerBoutonZoneMilieu implements EventHandler<Event> {
	
	private int mode;
	
	public ActionEffacerBoutonZoneMilieu(int mode) {
		this.mode = mode;
	}
	
	@Override
	public void handle(Event arg0) {
		if(mode == 0)
		{
			if(PlateauDeJeu.getInstance().getpMilieuCarte()!=null)
			{
				PlateauDeJeu.getInstance().getpMilieuCarte().getMenu().setVisible(false);
			}
		}
		else if(PlateauDeJeu.getInstance().getpMilieuChargement() != null){
			PlateauDeJeu.getInstance().getpMilieuChargement().efface();
		}
		
	}

}
