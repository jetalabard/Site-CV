package ihm.controleur.action_table.envoietelephone;
import application.dataloader.reseau.CreateurDeTrame;
import application.metier.Joueur;
import application.modele.Configuration;
import application.modele.Partie;

public class ActionDemandeArgentBlind {

	private Configuration config;

	public ActionDemandeArgentBlind(Joueur joueurQuiPayePetiteBlind, Joueur joueurQuiPayeGrosseBlind) {
		setConfig(Configuration.getInstance());
		gereBlind(joueurQuiPayePetiteBlind, joueurQuiPayeGrosseBlind);
	}

	private void gereBlind(Joueur joueurQuiPayePetiteBlind,Joueur joueurQuiPayeGrosseBlind) {

		for(Joueur j :Partie.getInstance().getListeJoueur())
		{
			j.setPetiteBlind(false);
		}
		gerePetite(joueurQuiPayePetiteBlind);
		gereGrosse(joueurQuiPayeGrosseBlind);
	}


	private void gereGrosse(Joueur joueurQuiPayeGrosseBlind) {
//		if(regardeSiJoueurPeutJouer(config.getValeurGrosseBlind(),joueurQuiPayeGrosseBlind)==true)
//		{
			joueurQuiPayeGrosseBlind.setPetiteBlind(false);
			CreateurDeTrame cdt;
			cdt = new CreateurDeTrame("3GB",config.getValeurGrosseBlind().retourneMontant());

			joueurQuiPayeGrosseBlind.getCommunication().getOut().println(cdt.getTrame());
			joueurQuiPayeGrosseBlind.getCommunication().getOut().flush();
//		}
//		else{
//			mettreJetonsPlusPetitALaPlaceDesGros(config.getValeurGrosseBlind(), joueurQuiPayeGrosseBlind);
//		}
	}

	private void gerePetite(Joueur joueurQuiPayePetiteBlind) {
//		if(regardeSiJoueurPeutJouer(config.getValeurGrosseBlind(),joueurQuiPayePetiteBlind)==true)
//		{
			joueurQuiPayePetiteBlind.setPetiteBlind(true);
			CreateurDeTrame cdt = new CreateurDeTrame("3PB",config.getValeurPetiteBlind().retourneMontant()) ;

			joueurQuiPayePetiteBlind.getCommunication().getOut().println(cdt.getTrame());
			joueurQuiPayePetiteBlind.getCommunication().getOut().flush();
//		}
//		else{
//			mettreJetonsPlusPetitALaPlaceDesGros(config.getValeurPetiteBlind(), joueurQuiPayePetiteBlind);
//		}
	}

//
//	private ListeJeton calculEtAjouteJeton(Jeton jeton, ListeJeton liste)
//	{
//		int index=0;
//		for(Entry<String,Jeton> entry:liste.entrySet())
//		{
//			if(entry.getValue().getValeur() == jeton.getValeur())
//			{
//				index = Integer.parseInt(entry.getKey())-1;
//			}
//		}
//		int valeur = jeton.getValeur();
//		for(int i =index;i>-1;i--)
//		{
//			if(valeur%Configuration.getInstance().getListeConfigJetons().get("vJ"+i) != valeur && valeur/Configuration.getInstance().getListeConfigJetons().get("vJ"+i) >=1)
//			{
//				liste = ajoute(i+"", valeur/Configuration.getInstance().getListeConfigJetons().get("vJ"+i), liste);
//				valeur = valeur - (valeur/Configuration.getInstance().getListeConfigJetons().get("vJ"+i)*Configuration.getInstance().getListeConfigJetons().get("vJ"+i));
//			}
//		}
//		return liste;
//	}

//	private ListeJeton ajoute(String id, int quantite,ListeJeton liste)
//	{
//		liste.get(id).setQuantite(liste.get(id).getQuantite()+quantite);
//		return liste;
//	}
//
//	private void mettreJetonsPlusPetitALaPlaceDesGros(ListeJeton valeurBlind, Joueur j) {
//		Jeton jeton = recuperePlusGrandJeton(j);
//		
//		ArrayList<Jeton> listeJetonQuiManque = savoirJetonQuiManque(valeurBlind,j);
//		
//		j.setListeJeton(enleveJetonEtRemplace(listeJetonQuiManque,j.getListeJeton()));
//		j.setListeJeton(calculEtAjouteJeton(jeton, j.getListeJeton()));
//		
//		if(regardeSiJoueurPeutJouer(valeurBlind, j) == false)
//		{
//			mettreJetonsPlusPetitALaPlaceDesGros(valeurBlind, j);
//		}
//		else{
//			envoieNouveauJeton(j);
//		}
//	}
//	
//	private ListeJeton enleveJetonEtRemplace(ArrayList<Jeton> listeJetonQuiManque,ListeJeton listeJeton) {
//		int montant = retourneMontant(listeJetonQuiManque);
//		listeJeton = ajouteJetonQuiManque(listeJetonQuiManque,listeJeton);
//		listeJeton = enleveJeton(montant,listeJeton);
//		
//		return listeJeton;
//	}
//
//	private ListeJeton enleveJeton(int montant, ListeJeton listeJeton) {
//		// si montant == une valeur d'un jeton
//		for(Entry<String,Jeton> entry : listeJeton.entrySet())
//		{
//			if(entry.getValue().getValeur() == montant && entry.getValue().getQuantite() !=0)
//			{
//				entry.getValue().setQuantite(entry.getValue().getQuantite()-1);
//			}
//		}
//		//si montant plus grand qu'une valeur de jeton
//		for(Entry<String,Jeton> entry : listeJeton.entrySet())
//		{
//			if(entry.getValue().getValeur() < montant && entry.getValue().getQuantite() !=0)
//			{
//				entry.getValue().setQuantite(entry.getValue().getQuantite()-1);
//			}
//		}
//		// si montant est plus petit qu'une valeur de jeton
//		
//		return listeJeton;
//	}
	
//	
//	private int determineValeurPlusGrandeParRapportAuMontant(int montant,ListeJeton liste)
//	{
//		int valeur = 0;
//		int tempo = 0;
//		
//		for(Entry<String,Jeton> entry : liste.entrySet())
//		{
//			tempo = montant - entry.getValue().getValeur();
//			if(tempo>valeur)
//			{
//				valeur = tempo;
//			}
//		}
//		return valeur;
//	}

//	private ListeJeton ajouteJetonQuiManque(ArrayList<Jeton> listeJetonQuiManque, ListeJeton listeJeton) {
//		for(Jeton jeton  : listeJetonQuiManque)
//		{
//			for(Entry<String,Jeton> entry : listeJeton.entrySet())
//			{
//				if(jeton.getValeur() == entry.getValue().getValeur())
//				{
//					entry.getValue().setQuantite(entry.getValue().getQuantite()+jeton.getQuantite());
//				}
//			}
//		}
//		return listeJeton;
//	}
//
//	private int retourneMontant(ArrayList<Jeton> liste)
//	{
//		int montant = 0;
//		for(Jeton jet:liste)
//		{
//			montant+=jet.getQuantite()*jet.getValeur();
//		}
//		return montant;
//	}
//
//
//	private void envoieNouveauJeton(Joueur j) {
//		ArrayList<Jeton> jetons = new ArrayList<Jeton>();
//		int montant = 0;
//		for(Entry<String,Jeton> entry : j.getListeJeton().entrySet())
//		{
//			jetons.add(entry.getValue());
//		}
//		montant = j.getListeJeton().retourneMontant();
//		
//		CreateurDeTrame cdt = new CreateurDeTrame("1RJ",true,montant,false,
//				jetons.get(0),jetons.get(1),jetons.get(2),jetons.get(3),jetons.get(4));
//		
//		j.getCommunication().getOut().println(cdt.getTrame());
//		j.getCommunication().getOut().flush();
//		
//		if(j.isPetiteBlind())
//		{
//			gerePetite(j);
//		}
//		else{
//			gereGrosse(j);
//		}
//		
//	}
//
//	private ArrayList<Jeton> savoirJetonQuiManque(ListeJeton valeurBlind,Joueur j) {
//		ArrayList<Jeton> jetons = new ArrayList<Jeton>();
//		for(Entry<String,Jeton> jeton : valeurBlind.entrySet())
//		{
//			if(jeton.getValue().getQuantite()>0)
//			{
//				jetons.add(jeton.getValue());
//			}
//		}
//		return jetons;
//	}
//
//	private Jeton recuperePlusGrandJeton(Joueur j) {
//		if(j.getListeJeton().get("4").getQuantite()>0)
//		{
//			enleveJeton("4",j);
//			return j.getListeJeton().get("4");
//		}
//		else if(j.getListeJeton().get("3").getQuantite()>0)
//		{
//			enleveJeton("3",j);
//			return j.getListeJeton().get("3");
//		}
//		else if(j.getListeJeton().get("2").getQuantite()>0)
//		{
//			enleveJeton("2",j);
//			return j.getListeJeton().get("2");
//		}
//		else if(j.getListeJeton().get("1").getQuantite()>0)
//		{
//			enleveJeton("1",j);
//			return j.getListeJeton().get("1");
//		}
//		else if(j.getListeJeton().get("0").getQuantite()>0)
//		{
//			enleveJeton("0",j);
//			return j.getListeJeton().get("0");
//		}
//		else{
//			return null;
//		}
//	}
//
//	private void enleveJeton(String indexJeton, Joueur j) {
//		j.getListeJeton().get(indexJeton).setQuantite(j.getListeJeton().get(indexJeton).getQuantite()-1);
//	}
//
//	private boolean regardeSiJoueurPeutJouer(ListeJeton valeurBlind, Joueur j) {
//		int compteur = 0;
//		for(Entry<String,Jeton> entry : valeurBlind.entrySet())
//		{
//			for(Entry<String,Jeton> entry2 : j.getListeJeton().entrySet())
//			{
//				if(entry.getKey() == entry2.getKey())
//				{
//					if(entry.getValue().getQuantite() <= entry2.getValue().getQuantite())
//					{
//						compteur++;
//					}
//				}
//			}
//		}
//		if(compteur >=5)
//		{
//			return true;
//		}
//		else{
//			return false;
//		}
//	}
//


	public Configuration getConfig() {
		return config;
	}

	public void setConfig(Configuration config) {
		this.config = config;
	}
}
