package ihm.controleur.action_table.envoietelephone;

import ihm.controleur.Attendre;
import ihm.vue.plateau.PlateauDeJeu;
import javafx.application.Platform;
import application.dataloader.reseau.CreateurDeTrame;
import application.metier.Joueur;
import application.modele.Configuration;
import application.modele.ListeJeton;
import application.modele.Partie;

public class ActionDemandeAuJoueurDeJouer {

	public static int nombreDeFois=0;

	public ActionDemandeAuJoueurDeJouer(Joueur j) {
		if(Partie.get() != null)
		{
			afficheContourZoneJoueur(j);
			sleep(j);
			premierTourPlusGrandMiseInitialiseAGrosseBlind();
			Partie.getInstance().getJeuEncours().setEstEnTrainDeJouer(j);
			envoieTrame(j);
		}
	}

	private void envoieTrame(Joueur j) {
		regarderSiCheck(j);
		CreateurDeTrame cdt = new CreateurDeTrame("3JO",Partie.getInstance().getJeuEncours().retourneTourEnCours().getPlusGrandeMise().retourneMontant(),Partie.getInstance().getJeuEncours().retourneTourEnCours().isPeutChecker());
		j.getCommunication().getOut().println(cdt.getTrame());
		j.getCommunication().getOut().flush();
	}

	private void premierTourPlusGrandMiseInitialiseAGrosseBlind() {
		if(nombreDeFois == 0)
		{
			int indexDernierTour = Partie.getInstance().getJeuEncours().getListeTour().size()-1;
			Partie.getInstance().getJeuEncours().getListeTour().get(indexDernierTour).setPlusGrandeMise(new ListeJeton(Configuration.getInstance().getValeurGrosseBlind()));
			nombreDeFois++;
		}
	}

	private void sleep(Joueur j) {

		Attendre attend = new Attendre(150);
		synchronized (attend) {
			try {
				attend.wait();
			} catch (InterruptedException e) {
				//				e.printStackTrace();
			}
		}
	}

	private void regarderSiCheck(Joueur j){
		int posJoueur=Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().indexOf(j);

		if(j.getAction()!=null ){
			if(posJoueur==0){
				posJoueur=Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().size()-1;
			}		
			if(Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().get(posJoueur).getAction()==null 
					|| Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().get(posJoueur).getAction().equals("Checker")){
				Partie.getInstance().getJeuEncours().retourneTourEnCours().setPeutChecker(true);
			}
		}
	}

	private void afficheContourZoneJoueur(Joueur j) {
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).getStyleClass().clear();
				PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).getStyleClass().add("zoneJoueur");
			}
		});
	}
}
