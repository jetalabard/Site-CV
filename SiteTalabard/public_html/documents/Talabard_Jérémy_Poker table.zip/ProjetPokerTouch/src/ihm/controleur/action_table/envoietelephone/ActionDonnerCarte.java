package ihm.controleur.action_table.envoietelephone;

import application.dataloader.reseau.CreateurDeTrame;
import application.metier.Carte;
import application.metier.Joueur;

public class ActionDonnerCarte {

	public ActionDonnerCarte(Joueur j, Carte carte, Carte carte2) {
		
		j.setMainJoueur(carte,carte2);
		
		recupereCarte(j, carte, carte2);
	}

	private void recupereCarte(Joueur j, Carte carte, Carte carte2) {
		String carteString = ConvertirCarteEnString(carte);
		String carte2String = ConvertirCarteEnString(carte2);
		
		envoieTrame(j, carteString, carte2String);
	}

	private void envoieTrame(Joueur j, String carteString, String carte2String) {
		CreateurDeTrame cdt = new CreateurDeTrame("3DO", carteString,carte2String);
		j.getCommunication().getOut().println(cdt.getTrame());
		j.getCommunication().getOut().flush();
	}

	private String ConvertirCarteEnString(Carte carte2) {
		
		return carte2.toString();
	}
	

}
