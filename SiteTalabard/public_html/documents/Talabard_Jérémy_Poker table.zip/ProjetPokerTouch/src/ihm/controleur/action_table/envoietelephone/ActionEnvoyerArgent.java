package ihm.controleur.action_table.envoietelephone;

import ihm.controleur.action_table.ActionDetermineGagnant;
import ihm.vue.plateau.PlateauDeJeu;

import java.util.ArrayList;
import java.util.Map.Entry;

import javafx.application.Platform;
import application.dataloader.reseau.CreateurDeTrame;
import application.metier.Jeton;
import application.metier.Joueur;
import application.metier.PotParallele;
import application.metier.Tour;
import application.modele.ListeJeton;
import application.modele.Partie;

public class ActionEnvoyerArgent {

	private PotParallele potParalleleDejaGagne;

	private ActionDetermineGagnant determineGagnant;

	public ActionEnvoyerArgent(ActionDetermineGagnant determineGagnant) {
		this.determineGagnant =determineGagnant;

		Partie.getInstance().getJeuEncours().setPotAAfficher(0);
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				PlateauDeJeu.getInstance().getpMilieuCarte().mettreAJourZonePot(Partie.getInstance().getJeuEncours().getPotAAfficher());
			}
		});

		Joueur j = Partie.getInstance().getJeuEncours().getGagnant().get(0);

		int nbTapis = 0;
		nbTapis = recupereNombreTapisParmiLesGagnants(nbTapis);
		if(nbTapis ==1)
		{
			casSimpleTapis(determineGagnant, j);
		}
		else if(nbTapis >1)
		{
			casPlusieursTapis(determineGagnant, j);
		}
		else if(nbTapis == 0){
			casSansTapis(j);
		}
	}

	private int recupereNombreTapisParmiLesGagnants(int nbTapis) {
		for(Joueur joueur : Partie.getInstance().getJeuEncours().getGagnant())
		{
			if(Partie.getInstance().getJeuEncours().getListeJoueurTapis().contains(joueur))
			{
				nbTapis++;
			}
		}
		return nbTapis;
	}

	private void casSansTapis(Joueur j) {
		//		ajoute au pot parallele la somme des mises divis� par le nombre de joueur
		if(Partie.getInstance().getJeuEncours().getGagnant().size() <=1)
		{
			ListeJeton liste = new ListeJeton();
			liste.initialiseListeJeton();

			if(Partie.getInstance().getJeuEncours().getListeJoueurTapis().size() >0)
			{
				for(Joueur joueur : Partie.getInstance().getJeuEncours().getListeJoueurTapis())
				{
					liste.incrementeListeJetonAvecAutreListe(recupererPotParalleleDuJoueur(joueur).getTapisDeBase());
					j.getListeJeton().incrementeListeJetonAvecAutreListe(recupererPotParalleleDuJoueur(joueur).getTapisDeBase());
				}
			}
			liste.incrementeListeJetonAvecAutreListe(Partie.getInstance().getJeuEncours().getPotPrincipal().getMontant());
			j.getListeJeton().incrementeListeJetonAvecAutreListe(Partie.getInstance().getJeuEncours().getPotPrincipal().getMontant());
			envoitArgentAuJoueur(j,liste);
		}
		else{
			ListeJeton liste = new ListeJeton();
			liste.initialiseListeJeton();
			int compteur = 0;
			if(Partie.getInstance().getJeuEncours().getListeJoueurTapis().size() >0)
			{

				for(Joueur joueur : Partie.getInstance().getJeuEncours().getListeJoueurTapis())
				{
					liste.incrementeListeJetonAvecAutreListe(recupererPotParalleleDuJoueur(joueur).getTapisDeBase());
				}

				for(Joueur joueur : Partie.getInstance().getJeuEncours().getGagnant())
				{
					joueur.getListeJeton().incrementeListeJetonAvecAutreListe(liste.diviserParNombredeGagnant(Partie.getInstance().getJeuEncours().getGagnant().size()));
					if(compteur ==0)
					{
						liste.incrementeListeJetonAvecAutreListe(liste.diviserParNombredeGagnant(Partie.getInstance().getJeuEncours().getGagnant().size()));
						compteur++;
					}
				}
			}
			compteur =0;
			for(Joueur joueur : Partie.getInstance().getJeuEncours().getGagnant())
			{
				joueur.getListeJeton().incrementeListeJetonAvecAutreListe(Partie.getInstance().getJeuEncours().getPotPrincipal().getMontant().diviserParNombredeGagnant(Partie.getInstance().getJeuEncours().getGagnant().size()));
				if(compteur ==0)
				{
					liste.incrementeListeJetonAvecAutreListe(Partie.getInstance().getJeuEncours().getPotPrincipal().getMontant().diviserParNombredeGagnant(Partie.getInstance().getJeuEncours().getGagnant().size()));
					compteur++;
				}
				envoitArgentAuJoueur(joueur,liste);
			}
		}
	}

	private void envoitArgentAuJoueur(Joueur j, ListeJeton liste) {

		ArrayList<Jeton> jetons = new ArrayList<Jeton>();
		for(Entry<String,Jeton> entry: liste.entrySet())
		{
			jetons.add(entry.getValue());
		}
		CreateurDeTrame cdt =  new CreateurDeTrame("3GA",false,jetons.get(0),jetons.get(1),jetons.get(2),jetons.get(3),jetons.get(4),liste.retourneMontant());
		j.getCommunication().getOut().println(cdt.getTrame());
		j.getCommunication().getOut().flush();
		// actualise la zone du gagnant
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).mettreAJourJeton(j);
			}
		});
	}

	private void casPlusieursTapis(ActionDetermineGagnant determineGagnant,
			Joueur j) {
		PotParallele pot = null;
		// recupere le plus petit pot parallele entre les x joueurs gagnant ayant fait tapis
		for(Joueur joue : Partie.getInstance().getJeuEncours().getGagnant())
		{
			for(Joueur jo : Partie.getInstance().getJeuEncours().getListeJoueurTapis())
			{
				if(jo == joue)
				{
					if(pot == null)
					{
						pot = recupererPotParalleleDuJoueur(jo);
					}
					else if(pot.getMontant().retourneMontant() > recupererPotParalleleDuJoueur(jo).getMontant().retourneMontant())
					{
						pot = recupererPotParalleleDuJoueur(jo);
					}
				}
			}
		}
		potParalleleDejaGagne = pot;
		for(Joueur joue : Partie.getInstance().getJeuEncours().getGagnant())
		{
			for(Joueur jo : Partie.getInstance().getJeuEncours().getListeJoueurTapis())
			{
				if(joue == jo)
				{
					if(recupererPotParalleleDuJoueur(jo) != potParalleleDejaGagne)
					{
						soustraitPotParalleleDejaGagneDeSonPotParallele(recupererPotParalleleDuJoueur(jo));
					}
				}
			}
		}

		for(Joueur joue : Partie.getInstance().getJeuEncours().getGagnant())
		{
			for(Joueur jo : Partie.getInstance().getJeuEncours().getListeJoueurTapis())
			{
				if(joue == jo)
				{
					joueurGagneSonPotParallele(jo);
					envoitArgentAuJoueur(j, recupererPotParalleleDuJoueur(j).getMontant());
				}
			}
		}
		if(Partie.getInstance().getJeuEncours().getPotPrincipal().getMontant().retourneMontant()>0)
		{
			ArrayList<Joueur> liste =  donneArgentAuDeuxiemeGagnantSiTapis(determineGagnant.retourneAutreGagnant(j));
			while(liste != null)
			{
				liste = donneArgentAuDeuxiemeGagnantSiTapis(determineGagnant.retourneAutreGagnant(j));
			}
		}
	}

	private void casSimpleTapis(ActionDetermineGagnant determineGagnant,
			Joueur j) {
		joueurGagneSonPotParallele(j);
		envoitArgentAuJoueur(j, recupererPotParalleleDuJoueur(j).getMontant());

		if(Partie.getInstance().getJeuEncours().getPotPrincipal().getMontant().retourneMontant()>0)
		{
			ArrayList<Joueur> liste =  donneArgentAuDeuxiemeGagnantSiTapis(determineGagnant.retourneAutreGagnant(j));
			while(liste != null)
			{
				liste = donneArgentAuDeuxiemeGagnantSiTapis(determineGagnant.retourneAutreGagnant(j));
			}
		}
	}

	private void joueurGagneSonPotParallele(Joueur j) {
		for(Tour t: Partie.getInstance().getJeuEncours().getListeTour())
		{
			for(PotParallele pot :t.getListePotParellele())
			{
				if(pot.getInitiateurDuPot() == j)
				{
					j.getListeJeton().incrementeListeJetonAvecAutreListe(pot.getMontant());
					potParalleleDejaGagne = pot;
				}
			}
		}
	}

	private ArrayList<Joueur> donneArgentAuDeuxiemeGagnantSiTapis(ArrayList<Joueur> arrayList) {
		ListeJeton liste = new ListeJeton();
		liste.initialiseListeJeton();

		for(Joueur j :arrayList)
		{
			if(j.getAction().getNomAction() == "Tapis")
			{
				return determineGagnant.retourneAutreGagnant(j);
			}
			else{
				PotParallele pot = Partie.getInstance().getJeuEncours().retournePlusGrandPotParalleleParmiTousLesTours(potParalleleDejaGagne);
				liste.incrementeListeJetonAvecAutreListe(donnerPotParalleleAJoueurNormal(pot,j).getMontant());
				joueurGagnePotPrincipalEtPotParallele(j,liste);
				Partie.getInstance().getJeuEncours().getGagnant().add(j);
			}
		}
		return null;
	}

	private void joueurGagnePotPrincipalEtPotParallele(Joueur j, ListeJeton potQuiVaAuGagnant) {

		j.getListeJeton().incrementeListeJetonAvecAutreListe(Partie.getInstance().getJeuEncours().getPotPrincipal().getMontant().diviserParNombredeGagnant(Partie.getInstance().getJeuEncours().getPotPrincipal().getListeJoueur().size()));
		j.getListeJeton().incrementeListeJetonAvecAutreListe(potQuiVaAuGagnant);

		ListeJeton jetonsQuiVontAuGagnant = new ListeJeton();
		jetonsQuiVontAuGagnant.initialiseListeJeton();
		jetonsQuiVontAuGagnant.incrementeListeJetonAvecAutreListe(potQuiVaAuGagnant);
		jetonsQuiVontAuGagnant.incrementeListeJetonAvecAutreListe(Partie.getInstance().getJeuEncours().getPotPrincipal().getMontant());

		envoitArgentAuJoueur(j, jetonsQuiVontAuGagnant);
	}

	private PotParallele donnerPotParalleleAJoueurNormal(PotParallele pot,Joueur j) {
		if(potParalleleDejaGagne.getListeJoueur().contains(j))
		{
			pot.getMontant().decrementeListeJetonAvecAutreListe(potParalleleDejaGagne.getMontant());
		}
		return pot;
	}



	private void soustraitPotParalleleDejaGagneDeSonPotParallele(PotParallele pot) {
		//		revoir cette methode
		//		revoir gain si plusieurs tapis
		for(Joueur joueur : pot.getListeJoueur())
		{
			if(joueur != pot.getInitiateurDuPot())
			{
				if(potParalleleDejaGagne.getListeJoueur().contains(joueur))
				{
					pot.getMontant().decrementeListeJetonAvecAutreListe(potParalleleDejaGagne.getMontant());
				}
			}
		}
	}

	private PotParallele recupererPotParalleleDuJoueur(Joueur j) {
		for(Tour t : Partie.getInstance().getJeuEncours().getListeTour())
		{
			for(PotParallele pot:t.getListePotParellele())
			{
				if(pot.getInitiateurDuPot() == j)
				{
					return pot;
				}
			}
		}

		for(Tour t : Partie.getInstance().getJeuEncours().getListeTour())
		{
			if(t.retourneLePlusGrandPotParallele().getListeJoueur().contains(j))
			{
				return t.retourneLePlusGrandPotParallele();
			}
		}

		return Partie.getInstance().getJeuEncours().retournePlusGrandPotParalleleParmiTousLesTours();
	}
}
