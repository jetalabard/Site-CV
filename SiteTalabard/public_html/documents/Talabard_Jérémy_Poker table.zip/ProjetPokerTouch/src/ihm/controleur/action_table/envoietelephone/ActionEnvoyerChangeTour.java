package ihm.controleur.action_table.envoietelephone;

import application.dataloader.reseau.CreateurDeTrame;
import application.metier.Joueur;
import application.modele.Partie;

public class ActionEnvoyerChangeTour {
	public ActionEnvoyerChangeTour() {
		
		CreateurDeTrame cdt = new CreateurDeTrame("3NT");
		for(Joueur j : Partie.getInstance().getJeuEncours().getListeJoueurEnJeu())
		{
			j.getCommunication().getOut().println(cdt.getTrame());
			j.getCommunication().getOut().flush();
		}
	}
}
