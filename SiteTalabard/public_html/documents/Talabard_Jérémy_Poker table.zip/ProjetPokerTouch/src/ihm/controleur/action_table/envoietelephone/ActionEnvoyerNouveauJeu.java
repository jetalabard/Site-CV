package ihm.controleur.action_table.envoietelephone;

import application.dataloader.reseau.CreateurDeTrame;
import application.metier.Joueur;
import application.modele.Partie;

public class ActionEnvoyerNouveauJeu {

	
	public ActionEnvoyerNouveauJeu() {
		
		for(Joueur j: Partie.getInstance().getListeJoueur())
		{
			CreateurDeTrame cdt = new CreateurDeTrame("3NJ");
			j.getCommunication().getOut().println(cdt.getTrame());
			j.getCommunication().getOut().flush();
		}
	}
	
}
