package ihm.controleur.action_table.envoietelephone;

import application.dataloader.reseau.CreateurDeTrame;
import application.metier.Joueur;

public class ActionEnvoyerPerdu {

	public ActionEnvoyerPerdu(Joueur joueur,boolean partie) {
		
		CreateurDeTrame cdt = new CreateurDeTrame("3PE",partie);
		joueur.getCommunication().getOut().println(cdt.getTrame());
		joueur.getCommunication().getOut().flush();
	}
}
