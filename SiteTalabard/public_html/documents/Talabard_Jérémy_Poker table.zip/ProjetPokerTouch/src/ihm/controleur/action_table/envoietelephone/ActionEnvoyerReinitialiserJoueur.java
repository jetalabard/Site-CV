package ihm.controleur.action_table.envoietelephone;

import ihm.vue.plateau.PlateauDeJeu;
import javafx.application.Platform;
import application.dataloader.ParserJeton;
import application.dataloader.reseau.CreateurDeTrame;
import application.metier.Joueur;

public class ActionEnvoyerReinitialiserJoueur {
	
	public ActionEnvoyerReinitialiserJoueur(Joueur j) {
		
		CreateurDeTrame cdt = new CreateurDeTrame("3KO");
		j.getCommunication().getOut().println(cdt.getTrame());
		j.getCommunication().getOut().flush();
		
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).getImageGrosseBlind().setVisible(false);
				PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).getImagePetiteBlind().setVisible(false);
			}
		});
		
		j.getListeJeton().initialiseListeJetonEnFonctionDeLaConfiguration();
		j.getListeJetonMise().initialiseListeJeton();
		
		Platform.runLater(new Runnable() {
			
			@Override
			public void run() {
				ParserJeton parser =new ParserJeton();
				parser.mettreAJourDocumentMisesJoueur(j);
				PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).creerZoneMise(j);
				PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).mettreAJourJeton(j);
			}
		});
		
	}
}
