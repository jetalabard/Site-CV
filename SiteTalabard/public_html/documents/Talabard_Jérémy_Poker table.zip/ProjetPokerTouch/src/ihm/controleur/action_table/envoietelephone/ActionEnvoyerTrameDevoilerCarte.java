package ihm.controleur.action_table.envoietelephone;

import ihm.vue.plateau.PlateauDeJeu;
import javafx.application.Platform;
import application.dataloader.ParserJeton;
import application.dataloader.reseau.CreateurDeTrame;
import application.metier.Joueur;
import application.modele.Partie;

public class ActionEnvoyerTrameDevoilerCarte {

	public ActionEnvoyerTrameDevoilerCarte() {

		Partie.getInstance().getJeuEncours().setDevoiler(true);
		CreateurDeTrame cdt = new CreateurDeTrame("3DV");
		for(Joueur j : Partie.getInstance().getJeuEncours().getListeJoueurEnJeu())
		{
			Platform.runLater(new Runnable() 
			{
				@Override
				public void run()
				{
					PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).getStyleClass().clear();
					Partie.getInstance().getJeuEncours().getPotPrincipal().getMontant().incrementeListeJetonAvecAutreListe(j.getListeJetonMise());
					j.getListeJetonMise().initialiseListeJeton();
					ParserJeton parser =new ParserJeton();
					parser.mettreAJourDocumentMisesJoueur(j);
					PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).creerZoneMise(j);
				}
			});
			j.getCommunication().getOut().println(cdt.getTrame());
			j.getCommunication().getOut().flush();
			
			
		}

		
	}
}
