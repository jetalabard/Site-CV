package ihm.controleur.action_table.envoietelephone;

import java.util.ArrayList;
import java.util.Map.Entry;

import application.dataloader.reseau.CreateurDeTrame;
import application.metier.Jeton;
import application.metier.Joueur;
import application.modele.Configuration;
import application.modele.ListeJeton;

public class ActionEnvoyerValeurJetonEtArgentAuJoueur {

	public ActionEnvoyerValeurJetonEtArgentAuJoueur(Joueur j,boolean existe) {
		envoyerJeton(j,existe);
	}

	private void envoyerJeton(Joueur j, boolean existe) {

		CreateurDeTrame cdt ;
		if(Configuration.getInstance().estPersonnalise() || existe == true)
		{
			cdt = envoyerJetonPartieConfigure(j,existe);
		}
		else {
			cdt = new CreateurDeTrame("1RJ",false,Configuration.getInstance().getArgentInitial(),false);
		}
		j.getCommunication().getOut().println(cdt.getTrame());
		j.getCommunication().getOut().flush();
	}

	private CreateurDeTrame envoyerJetonPartieConfigure(Joueur j , boolean existe) {
		CreateurDeTrame cdt;
		ArrayList<Jeton> jetons = new ArrayList<Jeton>();
		int montant = 0;
		if(existe == true)
		{
			for(Entry<String,Jeton> entry : j.getListeJeton().entrySet())
			{
				jetons.add(entry.getValue());
			}
			montant = j.getListeJeton().retourneMontant();
		}
		else{
			for(Entry<String,Jeton> entry : listeJetonsPourEnvoyer().entrySet())
			{
				jetons.add(entry.getValue());
			}
			montant = listeJetonsPourEnvoyer().retourneMontant();
		}

		cdt = new CreateurDeTrame("1RJ",true,montant,false,
				jetons.get(0),jetons.get(1),jetons.get(2),jetons.get(3),jetons.get(4));

		return cdt;
	}

	private ListeJeton listeJetonsPourEnvoyer()
	{
		ListeJeton jetons = new ListeJeton();
		jetons.initialiseListeJetonEnFonctionDeLaConfiguration();
		return jetons;
	}

}
