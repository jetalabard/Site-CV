package ihm.controleur.action_table.envoietelephone;

import java.util.ArrayList;

import application.dataloader.reseau.CreateurDeTrame;
import application.metier.Carte;
import application.metier.Joueur;
import application.modele.Partie;

public class EnvoyerNouvellesCartes {

	public EnvoyerNouvellesCartes(ArrayList<Carte> listeCarteSurLaTable) {
		envoyerNouvellesCartes(listeCarteSurLaTable);
	}

	private void envoyerNouvellesCartes(ArrayList<Carte> listeCarteSurLaTable) {
		CreateurDeTrame cdt = null;
		cdt = new CreateurDeTrame("3CA",listeCarteSurLaTable);
		envoyerATousLesJoueurs(cdt);
	}

	private void envoyerATousLesJoueurs(CreateurDeTrame cdt) {
		for(Joueur j :Partie.getInstance().getJeuEncours().getListeJoueurEnJeu())
		{
			j.getCommunication().getOut().println(cdt.getTrame());
			j.getCommunication().getOut().flush();
		}
	}
}
