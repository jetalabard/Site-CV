package ihm.controleur.actionjoueur;

import application.metier.Joueur;

/**
 * action faite par le joueur
 * @author J�r�my
 *
 */
public abstract class Action {
	
	/**
	 * nom de l'action
	 */
	private String nomAction;
	/**
	 * constructeur
	 * @param nom
	 */
	public Action(String nom) {
		
		this.nomAction = nom;
	}
	/**
	 * faire l'action
	 * @param j
	 */
	public abstract void faire(Joueur j);
	
	/**
	 * retourne le nom de l'action
	 * @return
	 */
	public String getNomAction() {
		return nomAction;
	}
	/**
	 * modifie le nom de l'action
	 * @param nomAction
	 */
	public void setNomAction(String nomAction) {
		this.nomAction = nomAction;
	}

}
