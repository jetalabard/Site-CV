package ihm.controleur.actionjoueur;

import application.metier.Joueur;
/**
 * quand le joueur Check
 * @author J�r�my
 *
 */
public class Checker extends Action{

	/**
	 * Constructeur
	 * @param nom
	 */
	public Checker(String nom) {
		super(nom);
	}
	/**
	 * regarde si tous les joueurs ont check� si oui change de tour
	 */
	@Override
	public void faire(Joueur j) {
	} 
	

			
}
