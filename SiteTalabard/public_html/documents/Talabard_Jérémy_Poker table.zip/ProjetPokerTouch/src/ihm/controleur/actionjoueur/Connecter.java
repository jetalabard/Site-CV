package ihm.controleur.actionjoueur;

import ihm.vue.plateau.PlateauDeJeu;
import javafx.application.Platform;
import application.metier.Joueur;
import application.modele.Partie;

/**
 * connecte le joueur
 * @author J�r�my
 *
 */
public class Connecter extends Action{
	
	/**
	 * permet de savoir si le joueur existe d�j�
	 */
	private boolean existe;
	/**
	 * constructeur
	 * @param nom
	 */
	public Connecter(String nom) {
		super(nom);
	}
	/**
	 * informe le plateau qu'un joueur s'est connect�
	 * @param j
	 */
	public void informerPlateauQuUnJoueurSEstConnecte(Joueur j)
	{
		if(Partie.getInstance().getNbJoueur() < 10)
		{
			if(existe == false)
			{
				Partie.getInstance().getListeJoueur().add(j);
				j.getListeJeton().initialiseListeJetonEnFonctionDeLaConfiguration();
				Partie.getInstance().setNbJoueur(Partie.getInstance().getNbJoueur()+1);
			}
			Platform.runLater(new Runnable() {
				@Override
				public void run() 
				{
					if(existe == false)
					{
						int emplacement = PlateauDeJeu.getInstance().verifieSiJoueurDansZone();
						j.setEmplacement(emplacement);
					}
					j.getListeJetonMise().initialiseListeJeton();
					PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).mettreAjourZone(j);
					PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).animerZone();
				}
			});
		}
	}
	/**
	 * faire l'action se connecter
	 */
	@Override
	public void faire(Joueur j) {
		informerPlateauQuUnJoueurSEstConnecte(j);
		
	}
	/**
	 * retourne si le joueur existe d�j�
	 * @return
	 */
	public boolean isExiste() {
		return existe;
	}
	/**
	 * modifie la valeur du boolean existe
	 * @param newExiste
	 */
	public void setExiste(boolean newExiste) {
		existe = newExiste;
	}
	
}
