package ihm.controleur.actionjoueur;

import application.metier.Joueur;
import application.modele.ListeJeton;
import application.modele.Partie;
/**
 * gere les actions du joueur
 * @author J�r�my
 *
 */
public class GererActionJoueur {
	
	/**
	 * joueur qui vient de jouer
	 */
	private Joueur j;

	/**
	 * Constructeur
	 * @param j
	 */
	public GererActionJoueur(Joueur j) {
		this.j = j;		
		gerer();
	}
	/**
	 * fait l'action suivant celle du joueur en cours
	 */
	private void gerer() {
		if(j== null || j.getAction() == null || j.getAction().getNomAction() == null)
		{
			return;
		}
		switch (j.getAction().getNomAction()) {
		case "SeCoucher":
			parDefaut();
			break;
		case  "Relance":
			relance();
			break;
		case "Tapis":
			tapis();
			break;
		case "Checker":
			checker();
			break;
		case "Quitter":
			parDefaut();
			break;
		case "Connecter":
			parDefaut();
			break;
		case "PayerBlind":
			parDefaut();
			break;
		default:
			break;
		}
	}
	/**
	 * par d�faut fait l'action
	 */
	private void parDefaut() {
		j.getAction().faire(j);
	}
	/**
	 * check
	 */
	private void checker() {
		if(j.getNbRelanceAuTour()<1)
		{
			if(j.getAction().getNomAction().equals("Checker") && Partie.getInstance().getJeuEncours().getNomTourActuel() !="PreFlop")
			{
				Partie.getInstance().getJeuEncours().getListeJoueurCheck().add(j);
				j.getAction().faire(j);
			}
		}
	}
	/**
	 * faire tapis
	 */
	private void tapis() {
		if(j.getNbRelanceAuTour()<=2)
		{
			if(j.getAction().getNomAction().equals("Tapis"))
			{
				Partie.getInstance().getJeuEncours().retourneTourEnCours().setPeutChecker(false);
				j.getListeJetonMise().incrementeListeJetonAvecAutreListe(j.getListeJeton());
				j.getListeJeton().initialiseListeJeton();
				if(Partie.getInstance().getJeuEncours().retourneTourEnCours().getPlusGrandeMise().retourneMontant() < j.getListeJetonMise().retourneMontant())
				{
					Partie.getInstance().getJeuEncours().retourneTourEnCours().setPlusGrandeMise(new ListeJeton(j.getListeJetonMise()));
				}
				j.getAction().faire(j);
			}
		}
	}
	/**
	 * faire relance
	 */
	private void relance() {
		if(j.getNbRelanceAuTour()<=2)
		{
			if(j.getAction().getNomAction().equals("Relance"))
			{
				Partie.getInstance().getJeuEncours().retourneTourEnCours().setPeutChecker(false);
				Partie.getInstance().getJeuEncours().retourneTourEnCours().setPlusGrandeMise(new ListeJeton(j.getListeJetonMise()));
				j.getAction().faire(j);
				j.setNbRelanceAuTour(j.getNbRelanceAuTour()+1);
			}
		}
	}
}
