package ihm.controleur.actionjoueur;

import java.util.Map.Entry;

import ihm.vue.plateau.PlateauDeJeu;
import javafx.application.Platform;
import application.dataloader.ParserJeton;
import application.metier.Jeton;
import application.metier.Joueur;
import application.metier.TourPreFlop;
import application.modele.Configuration;
import application.modele.ListeJeton;
import application.modele.Partie;

/**
 * le joueur paye la blind
 * @author J�r�my
 *
 */
public class PayerBlind extends Action{

	/**
	 * constructeur
	 * @param nom
	 */
	public PayerBlind(String nom) {
		super(nom);
	}

	/**
	 * la mise du joueur devient la blind
	 * @param j
	 */
	private void modifieListeDesJetonsMiseEnFonctionDeLaBlind(Joueur j) {
		if(j.isPetiteBlind())
		{
			j.setListeJetonMise(new ListeJeton());
			j.getListeJetonMise().initialiseListeJeton();
			for(Entry<String,Jeton> entry: Configuration.getInstance().getValeurPetiteBlind().entrySet())
			{
				j.getListeJetonMise().put(entry.getKey(), new Jeton(new Integer(entry.getValue().getValeur()),new Integer(entry.getValue().getQuantite())));
			}
		}
		else{
			j.setListeJetonMise(new ListeJeton());
			j.getListeJetonMise().initialiseListeJeton();
			for(Entry<String,Jeton> entry: Configuration.getInstance().getValeurGrosseBlind().entrySet())
			{
				j.getListeJetonMise().put(entry.getKey(), new Jeton(new Integer(entry.getValue().getValeur()),new Integer(entry.getValue().getQuantite())));
			}
		}
	}

	/**
	 * une fois que les joueurs ont mis� la blind, le premier joueur peut jouer
	 */
	private void quandBlindPayerPremierJoueurPeutJouer() {

		int indexDernierTour = Partie.getInstance().getJeuEncours().getListeTour().size()-1;
		Joueur j = Partie.getInstance().getJeuEncours().getListeTour().get(indexDernierTour).retourneJoueurQuiEstLePremierAJouer();
		TourPreFlop.compteur = 1;
		Partie.getInstance().getJeuEncours().getListeTour().get(indexDernierTour).faireTour(j);
	}
	/**
	 * affiche ou reaffiche les jetons du joueur
	 * @param j
	 */
	private void mettreAjourJetonJoueur(Joueur j) {
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				ParserJeton parser =new ParserJeton();
				parser.mettreAJourDocumentMisesJoueur(j);

				PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).creerZoneMise(j);
				PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).mettreAJourJeton(j);
			}
		});
	}

	/**
	 * paye la blind
	 */
	@Override
	public void faire(Joueur j) {

		modifieListeDesJetonsMiseEnFonctionDeLaBlind(j);
		j.getListeJeton().decrementeListeJetonAvecAutreListe(j.getListeJetonMise());
		mettreAjourJetonJoueur(j);
		// si c'est la grosse blind
		if(!j.isPetiteBlind())
		{
			Joueur petiteBlind = Partie.getInstance().getDernierJoueurPayePetiteBlind();
			// si petite a deja pay�
			if(petiteBlind.getListeJetonMise().retourneMontant()> 0)
			{
				quandBlindPayerPremierJoueurPeutJouer();
			}
		}
		// si petite blind
		else if(j.isPetiteBlind())
		{
			int indexPetiteBlind = Partie.getInstance().getListeJoueur().indexOf(Partie.getInstance().getDernierJoueurPayePetiteBlind());
			int indexGrosseBlind = indexPetiteBlind +1;
			if(indexGrosseBlind >= Partie.getInstance().getListeJoueur().size())
			{
				indexGrosseBlind = indexGrosseBlind - Partie.getInstance().getListeJoueur().size();
			}
			Joueur grosseBlind = Partie.getInstance().getListeJoueur().get(indexGrosseBlind);
			// si grosse blind a deja pay�
			if(grosseBlind.getListeJetonMise().retourneMontant()> 0)
			{
				quandBlindPayerPremierJoueurPeutJouer();
			}
		}

	}

}
