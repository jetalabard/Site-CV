package ihm.controleur.actionjoueur;

import ihm.controleur.action_table.ActionExclureJoueur;
import ihm.controleur.action_table.envoietelephone.ActionEnvoyerPerdu;
import ihm.controleur.action_table.envoietelephone.ActionEnvoyerReinitialiserJoueur;
import ihm.vue.plateau.PlateauDeJeu;
import ihm.vue.plateau.ZoneJoueur;

import java.io.IOException;

import javafx.application.Platform;
import application.metier.Joueur;
import application.modele.Partie;
/**
 * le joueur quitte l'application
 * @author J�r�my
 *
 */
public class Quitter extends Action {
	/**
	 * mode d'exclusion du joueur
	 */
	private int mode;
	/**
	 * constructeur
	 * @param nom
	 */
	public Quitter(String nom) {
		super(nom);
	}
	/**
	 * exclu le joueur
	 * @param identifiant
	 */
	private void exclure(String identifiant) {
		Joueur joueurQuiQuitte = null;
		for(Joueur j:Partie.getInstance().getListeJoueur())
		{
			if(j.getIdentifiant() == identifiant)
			{
				new ActionEnvoyerPerdu(j,true);
				joueurQuiQuitte = j;
			}
		}
		fermeCommunication(joueurQuiQuitte);
		exclure(joueurQuiQuitte);
	}
	/**
	 * exclu le joueur
	 * @param j
	 */
	private void exclureJoueur(Joueur j) {
		if(Partie.getInstance().isEncours())
		{
			siPartieEnCours(j);
		}
		else{
			siPartiePasEnCours(j);
		}
	}
	/**
	 * exclusion si la partie n'est pas en cours
	 * @param j
	 */
	private void siPartiePasEnCours(Joueur j) {
		fermeCommunication(j);
		exclure(j);
		if(Partie.getInstance().getListeJoueur().size() <2)
		{
			arreterPartie();
		}
	}
	/**
	 * exclusion si la partie est en cours
	 * @param j
	 */
	private void siPartieEnCours(Joueur j) {
		if(Partie.getInstance().getJeuEncours() != null)
		{
			siJeuDifferentDeNull(j);
		}
		else{
			SiJeuNull(j);
		}
	}
	/**
	 * exclusion si le jeu n'existe pas
	 * @param j
	 */
	private void SiJeuNull(Joueur j) {
		fermeCommunication(j);
		exclure(j);

		if(Partie.getInstance().getListeJoueur().size() <2)
		{
			arreterPartie();
		}
	}
	/**
	 * exclusion si le jeu a d�marr�
	 * @param j
	 */
	private void siJeuDifferentDeNull(Joueur j) {

		if(Partie.getInstance().getJeuEncours().isEncours())
		{
			gereSiLeJoueurQuiQuitteDevaitJouer(j);
			gereSiJoueurAUneMise(j);

			
			fermeCommunication(j);
			exclure(j);
			
			enleveSiJetonBlind();

			if(Partie.getInstance().getJeuEncours().getListeJoueurEnJeu().size() < 2)
			{
				if(Partie.getInstance().getListeJoueur().size() < 2)
				{
					arreterPartie();
				}
				else{
					arreterJeu();
				}
			}
			else if(Partie.getInstance().getListeJoueur().size() < 2)
			{
				arreterPartie();
			}
		}
		else {
			SiJeuNull(j);
		}
	}
	/**
	 * enleve les jetons de blind
	 */
	private void enleveSiJetonBlind() {

		for(ZoneJoueur zj : PlateauDeJeu.getInstance().getListeZoneJoueur())
		{
			Platform.runLater(new Runnable() {

				@Override
				public void run() {
					if(zj.getImageGrosseBlind() != null)
					{
						zj.getImageGrosseBlind().setVisible(false);
						
					}
					if(zj.getImagePetiteBlind() != null)
					{
						
						zj.getImagePetiteBlind().setVisible(false); 
					}
				}
			});
		}


	}
	/**
	 * gere si le joueur qui quitte devait jouer
	 * @param j
	 */
	private void gereSiLeJoueurQuiQuitteDevaitJouer(Joueur j) {
		if(Partie.getInstance().getListeJoueur().size() >= 3 )
		{
			if(Partie.getInstance().getJeuEncours().getEstEnTrainDeJouer() ==j)
			{
				int index = Partie.getInstance().getListeJoueur().indexOf(Partie.getInstance().getJeuEncours().getEstEnTrainDeJouer())+1;

				if(index >= Partie.getInstance().getListeJoueur().size())
				{
					index = index -Partie.getInstance().getListeJoueur().size();
				}
				Joueur joueur = Partie.getInstance().getListeJoueur().get(index);
				Partie.getInstance().getJeuEncours().retourneTourEnCours().faireTour(joueur);
			}
		}
	}
	/**
	 * gere si le joueur qui quitte � une mise
	 * @param j
	 */
	private void gereSiJoueurAUneMise(Joueur j) {
		if(Partie.getInstance().getListeJoueur().size() >=3)
		{
			if(j.getListeJetonMise().retourneMontant() > 0)
			{
				Platform.runLater(new Runnable() {
					@Override
					public void run() {
						PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).getStyleClass().clear();
						if(j.getAction().getNomAction() != "Tapis")
						{
							Partie.getInstance().getJeuEncours().getPotPrincipal().getMontant().incrementeListeJetonAvecAutreListe(j.getListeJetonMise());
						}
						Partie.getInstance().getJeuEncours().setPotAAfficher(1);
						PlateauDeJeu.getInstance().getpMilieuCarte().mettreAJourZonePot(Partie.getInstance().getJeuEncours().getPotAAfficher());
					}
				});
			}
		}
	}
	/**
	 * arrete le jeu
	 */
	private void arreterJeu() {
		Partie.getInstance().getJeuEncours().arreter();
	}
	/**
	 * arrete la partie
	 */
	private void arreterPartie() {
		if(Partie.getInstance().getJeuEncours() != null)
		{
			if(Partie.getInstance().getListeJoueur().size() == 1)
			{
				if(Partie.getInstance().getGagnant() == null)
				{
					new ActionEnvoyerReinitialiserJoueur(Partie.getInstance().getListeJoueur().get(0));
				}
			}
		}
		Partie.getInstance().arreter();
	}
	/**
	 * exclure
	 * @param j
	 */
	private void exclure(Joueur j) {
		new ActionExclureJoueur().exclureJoueur(j);
	}
	/**
	 * ferme les communications du joueur
	 * @param j
	 */
	private void fermeCommunication(Joueur j) {
		try {
			if(j != null)
			{
				if(!j.getCommunication().isThreadFermer())
				{
					if(j.getCommunication().getSocketClient()!= null){
						j.getCommunication().getSocketClient().close();
					}
					j.getCommunication().getIn().close();
					j.getCommunication().getOut().close();
					j.getCommunication().setThreadFermer(true);
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * fait l'action quitter
	 */
	@Override
	public void faire(Joueur j) {
		if(mode == 0)
		{
			exclureJoueur(j);
		}
		else if(mode == 1){
			exclure(j.getIdentifiant());
		}
		else{
			fermeCommunication(j);
			exclure(j);
		}
		
	}
	/**
	 * modifie le mode d'exclusion
	 * @param i
	 */
	public void setMode(int i) {
		mode = i;
	}
}
