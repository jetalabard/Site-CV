package ihm.controleur.actionjoueur;

import ihm.vue.plateau.PlateauDeJeu;
import javafx.application.Platform;
import application.dataloader.ParserJeton;
import application.metier.Joueur;
/**
 * action de relance
 * @author J�r�my
 *
 */
public class Relance extends Action{
	/**
	 * constructeur
	 * @param nom
	 */
	public Relance(String nom) {
		super(nom);
	}
	/**
	 * fait l'action relance
	 */
	@Override
	public void faire(Joueur j) {
		j.getJetonsDejaMise().incrementeListeJetonAvecAutreListe(j.getListeJetonMise());
		
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				ParserJeton parser =new ParserJeton();
				parser.mettreAJourDocumentMisesJoueur(j);
				PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).creerZoneMise(j);
				PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).mettreAJourJeton(j);
			}
		});
	}


}

