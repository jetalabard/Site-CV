package ihm.controleur.actionjoueur;

import ihm.vue.plateau.PlateauDeJeu;
import javafx.application.Platform;
import application.metier.Joueur;
/**
 * action se coucher
 * @author J�r�my
 *
 */
public class SeCoucher extends Action{

	/**
	 * constructeur
	 * @param nom
	 */
	public SeCoucher(String nom) {
		super(nom);
	}
	/**
	 * fait l'action se coucher
	 */
	@Override
	public void faire(Joueur j) {
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).afficherCartesDos();
			}
		});
	}


}
