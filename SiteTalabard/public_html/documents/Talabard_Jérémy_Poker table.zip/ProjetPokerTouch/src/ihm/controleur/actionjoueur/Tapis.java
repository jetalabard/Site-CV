package ihm.controleur.actionjoueur;

import java.util.ArrayList;

import ihm.vue.plateau.PlateauDeJeu;
import javafx.application.Platform;
import application.dataloader.ParserJeton;
import application.metier.Joueur;
import application.metier.PotParallele;
import application.modele.ListeJeton;
import application.modele.Partie;
/**
 * action tapis
 * @author J�r�my
 *
 */
public class Tapis extends Action{
	/**
	 * constructeur
	 * @param nom
	 */
	public Tapis(String nom) {
		super(nom);
	}
	/**
	 * fait l'action tapis
	 */
	@Override
	public void faire(Joueur j) {
		ajoutePotParallele(j);
		mettreAJourZoneJoueur(j);
	}
	/**
	 * cr�� un nouveau pot parallele
	 * @param j
	 */
	private void ajoutePotParallele(Joueur j) {
		if(Partie.getInstance().getJeuEncours().retourneTourEnCours().getListePotParellele() == null)
		{
			Partie.getInstance().getJeuEncours().retourneTourEnCours().setListePotParellele(new ArrayList<PotParallele>());
		}
		ListeJeton liste = new ListeJeton();
		liste.initialiseListeJeton();
		liste.incrementeListeJetonAvecAutreListe(j.getListeJetonMise());
		liste.incrementeListeJetonAvecAutreListe(j.getJetonsDejaMise());

		PotParallele pot = new PotParallele(j, liste);

		if(Partie.getInstance().getJeuEncours().retourneTourEnCours().getListePotParellele().size()>=1)
		{
			PotParallele plusGrandPot = Partie.getInstance().getJeuEncours().retourneTourEnCours().retourneLePlusGrandPotParallele();
			if(plusGrandPot.getTapisDeBase().retourneMontant()>= pot.getTapisDeBase().retourneMontant())
			{
				pot.getMontant().incrementeListeJetonAvecAutreListe(pot.getTapisDeBase());
			}
			else {pot.getMontant().incrementeListeJetonAvecAutreListe(plusGrandPot.getTapisDeBase());}

			//ajoute dans les autres pots la valeur de ce pot	

			for(PotParallele potP:Partie.getInstance().getJeuEncours().retourneTourEnCours().getListePotParellele())
			{
				if(pot.getTapisDeBase().retourneMontant()>potP.getTapisDeBase().retourneMontant())
				{
					potP.getMontant().incrementeListeJetonAvecAutreListe(potP.getTapisDeBase());
				}
				else{
					potP.getMontant().incrementeListeJetonAvecAutreListe(pot.getTapisDeBase());
				}
			}

		}
		Partie.getInstance().getJeuEncours().retourneTourEnCours().getListePotParellele().add(pot);
	}
	/**
	 * vide tous les jetons et les mets dans la zone de mise
	 * @param j
	 */
	private void mettreAJourZoneJoueur(Joueur j) {
		ParserJeton parser =new ParserJeton();
		parser.mettreAJourDocumentMisesJoueur(j);

		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).creerZoneMise(j);
				PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).mettreAJourJeton(j);
			}
		});
	}

}
