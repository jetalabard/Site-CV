package ihm.vue.menu;


import ihm.controleur.action_menu.ActionAfficheDemarrerQuitter;
import ihm.vue.plateau.Animation;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * fenetre d'affichage au d�marrage
 * @author J�r�my
 *
 */
public class FenetreDemarrage extends BorderPane{
	/**
	 * stage
	 */
	private Stage stage;
	/**
	 * si cpt egale 1 alors affiche boutons pour demarrer sinon rien
	 */
	private int cpt;
	/**
	 * constructeur
	 * @param stage
	 */
	public FenetreDemarrage(Stage stage){
		super();
		cpt=1;
		this.stage=stage;
		creerLogo();
		initialiserTexte();
		gereActionSurFenetre();
	}
	/**
	 * gere les actions sur la fenetres
	 */
	private void gereActionSurFenetre() {
		this.setOnMouseClicked(new ActionAfficheDemarrerQuitter(this));  
		this.stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {
				fermer();
			}
		});
	}
	/**
	 * initialise les titres
	 */
	private void creerLogo() {
		Image image = new Image("/ressources/jeton/PokerTouch.png");
		ImageView logo = new ImageView(image);
		logo.setFitHeight(300);
		logo.setPreserveRatio(true);
		this.setTop(logo);  
		BorderPane.setAlignment(logo, Pos.TOP_CENTER);

	}
	/**
	 * initialise le texte de d�but
	 */
	private void initialiserTexte(){
		Label touch=new Label("Touchez l'�cran pour d�marrer");
		touch.getStyleClass().add("touch");
		this.setCenter(touch);
	}
	/**
	 * affiche les boutons demarrer partie
	 */
	public void afficherDemarrerPartie(){
		if (cpt!=0){
			VueDemarrerPartie vue=new VueDemarrerPartie(this);
			Animation.getInstance().animeBouton(vue.getDemarrer(), -1080);
			Animation.getInstance().animeBouton(vue.getQuitter(), 1080);
			this.setCenter(vue);
			vue.setAlignment(Pos.CENTER);
			cpt--;
		}
	}
	/**
	 * affiche 
	 */
	public void afficherDemarrerPartieR(){
		VueDemarrerPartie vue=new VueDemarrerPartie(this);
		this.setCenter(null);
		vue.setAlignment(Pos.CENTER);
		this.setCenter(vue);
		
	}
	/**
	 * affiche page configuration valeurs
	 */
	public void afficherChoixValeursJetons(){
		VueChoixValeursJetons vue=new VueChoixValeursJetons(this);
		this.setCenter(vue);
	}
	/**
	 * affiche page configuration quantit�
	 */
	public void afficherChoixNombreJetons(){
		VueChoixNombreJetons vue=new VueChoixNombreJetons(this);
		this.setCenter(vue);
	}
	/**
	 * affiche page configuration blind
	 */
	public void afficherConfiguration(){
		VueConfiguration vue=new VueConfiguration(this);
		this.setCenter(vue);
	}
	/**
	 * affiche page demarrer par defaut
	 */
	public void afficherDemarrerDefaut(){
		VueDemarrerParDefaut vue=new VueDemarrerParDefaut(this);
		Animation.getInstance().animeBouton(vue.getConfig(), -1080);
		Animation.getInstance().animeBouton(vue.getDemarrer(), 1080);
		Animation.getInstance().animeBouton(vue.getRetour(), -1080);
		this.setCenter(vue);
	}
	/**
	 * fermer
	 */
	public void fermer() {
		this.stage.close();
		System.exit(0);
	}
	/**
	 * retourne le stage
	 */
	public Stage getStage() {
		return stage;
	}
	/***
	 * modifie le stage
	 * @param stage
	 */
	public void setStage(Stage stage) {
		this.stage = stage;
	}
}
