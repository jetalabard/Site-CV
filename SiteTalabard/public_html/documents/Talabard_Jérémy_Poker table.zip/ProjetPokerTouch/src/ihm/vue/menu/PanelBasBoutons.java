package ihm.vue.menu;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
/**
 * affiche dans la configuration les bouton retour/suivant /par defaut
 * @author J�r�my
 *
 */
public class PanelBasBoutons extends VBox{
	/**
	 * bouton defaut
	 */
	private Button defaut;
	/**
	 * bouton retour
	 */
	private Button retour;
	/**
	 * bouton suivant
	 */
	private Button suivant;
	/**
	 * label suivant
	 */
	private Label lbsuivant;
	/**
	 * panel bas
	 */
	private FlowPane panelBas;
	
	public PanelBasBoutons() {
		creerBoutonsDefaut();
		creerBoutonRetour();
		creerBoutonSuivant();
		this.getChildren().add(defaut);
		this.getChildren().add(panelBas);
		defaut.setAlignment(Pos.CENTER);
	}
	/**
	 * creer bouton par defaut
	 */
	private void creerBoutonsDefaut(){		
		Label texte=new Label("Par Defaut");
		defaut=new Button(null,texte);
		texte.setScaleY(3);
		texte.setScaleX(3);
		defaut.setPrefSize(300,40);
		defaut.getStyleClass().add("boutonChoix");
	}
	/**
	 * creer bouton retour
	 */
	private void creerBoutonRetour(){
		panelBas=new FlowPane();
		panelBas.setAlignment(Pos.CENTER);	
		
		creerLabelEtBoutonRetour();
		
		panelBas.getChildren().add(retour);
		FlowPane.setMargin(retour,new Insets(20,50,20,50));

	}
	/**
	 * creer bouton et label retour
	 */
	private void creerLabelEtBoutonRetour() {
		
		Label labelretour=new Label("Retour");
		retour=new Button(null, labelretour);
		
		labelretour.setScaleY(3);
		labelretour.setScaleX(3);
		
		retour.setPrefSize(400,40);
		retour.getStyleClass().add("boutonChoix");
		
	}
	/**
	 * creer bouton suivant
	 */
	private void creerBoutonSuivant(){
		lbsuivant=new Label("Suivant");
		suivant=new Button(null,lbsuivant);
		lbsuivant.setScaleY(3);
		lbsuivant.setScaleX(3);
		suivant.setPrefSize(400,40);
		suivant.getStyleClass().add("boutonChoix");
		panelBas.getChildren().add(suivant);

	}
	/**
	 * retourne defaut
	 * @return
	 */
	public Button getDefaut() {
		return defaut;
	}
	/**
	 * retourne retour
	 * @return
	 */
	public Button getRetour() {
		return retour;
	}
	/**
	 * retourne suivant
	 * @return
	 */
	public Button getSuivant() {
		return suivant;
	}
	/**
	 * retourne label suivant
	 * @return
	 */
	public Label getLbsuivant() {
		return lbsuivant;
	}
	
}
