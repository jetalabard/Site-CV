package ihm.vue.menu;

import ihm.controleur.action_menu.ActionCliquerMoins;
import ihm.controleur.action_menu.ActionCliquerPlus;
import ihm.controleur.action_menu.ActionPersonaliser;
import ihm.controleur.action_menu.ActionResetDefaut;
import ihm.controleur.action_menu.ActionRetour;
import ihm.controleur.action_menu.ActionSuivant;

import java.io.IOException;
import java.util.ArrayList;

import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import application.modele.Configuration;


public class VueChoixNombreJetons extends BorderPane{

	private ArrayList<Button> listeBoutonPlus;
	private ArrayList<Button> listeBoutonMoins;
	private ArrayList<Label> listeLabelJetons;	
	private ArrayList<Label> listeLabelNombre;
	private ArrayList<HBox> listePanelCentre;
	private Label lbtotal;
	private FenetreDemarrage parent;
	private VBox panelJeton;
	private PanelBasBoutons panelBasBouton;

	private Button personalisation;


	public VueChoixNombreJetons(FenetreDemarrage fenetreDemarrage) 
	{
		super();
		this.parent=fenetreDemarrage;
		this.getStyleClass().add("choixjetons");
		creerPanelJeton();
		this.setCenter(panelJeton);
		panelJeton.setAlignment(Pos.TOP_CENTER);
		creerPanelBasBouton();
	}

	private void creerPanelJeton()
	{
		panelJeton=new VBox(0);

		creerListeBoutonPlus();
		creerListeBoutonMoins();
		creerListeLabelJetons();
		creerListeLabelNombre();
		creerListePanelCentre();
		creerPanelTotal();
		creerBoutonPerso();

	}

	private void creerPanelTotal() {		
		creerLabelTotal();
		
		FlowPane pane=new FlowPane();
		Label tot=new Label("Somme initale par joueur :");
		tot.getStyleClass().add("labelTotal");
		pane.setAlignment(Pos.CENTER);
		pane.getChildren().add(tot);
		pane.getChildren().add(lbtotal);
		panelJeton.getChildren().add(pane);

	}

	private void creerLabelTotal() {
		lbtotal=new Label(String.valueOf(Configuration.getInstance().getArgentInitial()));
		lbtotal.getStyleClass().add("labelJeton");
		lbtotal.setPrefSize(220, 50);
		lbtotal.setAlignment(Pos.CENTER);
		
	}

	private void creerPanelBasBouton(){
		panelBasBouton=new PanelBasBoutons();
		panelBasBouton.setAlignment(Pos.CENTER);
		this.setBottom(panelBasBouton);
		panelBasBouton.getDefaut().setVisible(false);
		panelBasBouton.getDefaut().setOnAction(new ActionResetDefaut(this));
		panelBasBouton.getRetour().setOnAction(new ActionRetour(this.parent,this));
		panelBasBouton.getSuivant().setOnAction(new ActionSuivant(this.parent, this));
	}

	private void creerListeBoutonPlus()
	{
		listeBoutonPlus=new ArrayList<>();
		for(int i=0;i<5;i++)
		{
			Label plus=new Label("+1");
			listeBoutonPlus.add(creerBoutonPlus(i,plus));			
		}
	}


	private Button creerBoutonPlus(int i, Label plus) {
		Button bouton=new Button(null,plus);
		plus.setScaleY(1.5);
		plus.setScaleX(1.5);
		bouton.setVisible(false);
		bouton.setPrefSize(60,60);
		bouton.setOnAction(new ActionCliquerPlus(this,i));
		bouton.getStyleClass().add("boutonChoix");
		bouton.setAlignment(Pos.CENTER);
		return bouton;
		
	}

	private void creerListeBoutonMoins()
	{
		listeBoutonMoins=new ArrayList<>(); 
		for(int i=0;i<5;i++)
		{
			Label moins=new Label("-1");
			Button bouton = creerBoutonMoins(i, moins);
			listeBoutonMoins.add(bouton);			
		}
	}

	private Button creerBoutonMoins(int i, Label moins) {
		Button bouton=new Button(null,moins);
		bouton.setVisible(false);
		moins.setScaleY(1.5);
		moins.setScaleX(1.5);
		bouton.setPrefSize(60,60);
		bouton.setOnAction(new ActionCliquerMoins(this,i));
		bouton.getStyleClass().add("boutonChoix");
		return bouton;
	}

	private void creerListeLabelJetons()
	{
		listeLabelJetons=new ArrayList<Label>();
		for(int i=0;i<5;i++)
		{
			Label label = new Label();
			label.setText(String.valueOf(Configuration.getInstance().getListeConfigJetons().get("vJ"+i)));
			label.getStyleClass().add("labelJeton");
			label.setAlignment(Pos.CENTER_LEFT);
			label.setPrefSize(220, 40);
			listeLabelJetons.add(label);
		}
	}

	private void creerListeLabelNombre(){
		listeLabelNombre=new ArrayList<>();
		for(int i=0;i<5;i++)
		{
			Label label = new Label();			
			label.setText(String.valueOf(Configuration.getInstance().getListeConfigJetons().get("qJ"+i)));
			label.getStyleClass().add("labelJeton");
			label.setAlignment(Pos.CENTER_LEFT);
			label.setPrefSize(150, 40);
			listeLabelNombre.add(label);
		}
	}


	private void creerListePanelCentre(){
		listePanelCentre=new ArrayList<>();

		for(int i=0;i<5;i++)
		{
			creerEtInitialiseListePanelCentre(i);
			
			AnchorPane image = chargeJeton(i);
			
			listePanelCentre.get(i).getChildren().add(image);
			listePanelCentre.get(i).getChildren().add(listeBoutonMoins.get(i));
			
			Label fois = creerLabelX();
			ajouteElementCreerALaListePanelCentre(i, fois);
			panelJeton.getChildren().add(listePanelCentre.get(i));
		}
	}

	private void creerEtInitialiseListePanelCentre(int i) {
		listePanelCentre.add(new HBox());
		listePanelCentre.get(i).setPrefHeight(100);
		listePanelCentre.get(i).getChildren().add(listeLabelJetons.get(i));
	}

	private void ajouteElementCreerALaListePanelCentre(int i, Label fois) {
		HBox.setMargin(listeBoutonMoins.get(i), new Insets(0,0,0,50));
		listePanelCentre.get(i).getChildren().add(fois);
		listePanelCentre.get(i).getChildren().add(listeLabelNombre.get(i));
		listePanelCentre.get(i).getChildren().add(listeBoutonPlus.get(i));
		listePanelCentre.get(i).setAlignment(Pos.CENTER);
	}

	private Label creerLabelX() {
		Label fois=new Label("X");
		fois.setPrefSize(80, 50);
		fois.getStyleClass().add("labelX");
		fois.setAlignment(Pos.BOTTOM_RIGHT);
		return fois;
	}

	private AnchorPane chargeJeton(int i) {
		String path=new String("/ressources/jeton/jeton_"+i+".fxml");
		FXMLLoader loader=new FXMLLoader();
		loader.setLocation(getClass().getResource(path));
		AnchorPane image=null;;
		try {
			image=(AnchorPane)loader.load();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return image;
	}

	private void creerBoutonPerso(){		

		Label texte = creerLabelPersonnaliser();
		personalisation=new Button(null,texte);
		
		Label vide=new Label(" ");
		
		
		personalisation.setPrefSize(300,50);
		personalisation.getStyleClass().add("boutonChoix");
		panelJeton.getChildren().add(vide);
		panelJeton.getChildren().add(personalisation);
		personalisation.setOnAction(new ActionPersonaliser(this));			
	}

	private Label creerLabelPersonnaliser() {
		Label texte=new Label("Personnaliser");
		texte.setScaleY(2);
		texte.setScaleX(2);
		return texte;
	}


	public PanelBasBoutons getPanelBasBouton() {
		return panelBasBouton;
	}

	public void setPanelBasBouton(PanelBasBoutons panelBasBouton) {
		this.panelBasBouton = panelBasBouton;
	}

	public Button getPersonalisation() {
		return personalisation;
	}

	public void setPersonalisation(Button personalisation) {
		this.personalisation = personalisation;
	}

	public ArrayList<Button> getListeBoutonPlus() {
		return listeBoutonPlus;
	}

	public ArrayList<Button> getListeBoutonMoins() {
		return listeBoutonMoins;
	}

	public void setListeBoutonPlus(ArrayList<Button> listeBoutonPlus) {
		this.listeBoutonPlus = listeBoutonPlus;
	}

	public void setListeBoutonMoins(ArrayList<Button> listeBoutonMoins) {
		this.listeBoutonMoins = listeBoutonMoins;
	}

	public ArrayList<Label> getListeLabelJetons() {
		return listeLabelJetons;
	}

	public void setListeLabelJetons(ArrayList<Label> listeLabelJetons) {
		this.listeLabelJetons = listeLabelJetons;
	}

	public ArrayList<Label> getListeLabelNombre() {
		return listeLabelNombre;
	}

	public Label getLbtotal() {
		return lbtotal;
	}

	public void setListeLabelNombre(ArrayList<Label> listeLabelNombre) {
		this.listeLabelNombre = listeLabelNombre;
	}

	public void setLbtotal(Label lbtotal) {
		this.lbtotal = lbtotal;
	}
}
