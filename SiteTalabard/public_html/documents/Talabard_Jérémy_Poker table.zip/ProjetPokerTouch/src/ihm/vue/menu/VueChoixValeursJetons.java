package ihm.vue.menu;

import ihm.controleur.action_menu.ActionCliquerMoins;
import ihm.controleur.action_menu.ActionCliquerPlus;
import ihm.controleur.action_menu.ActionPersonaliser;
import ihm.controleur.action_menu.ActionResetDefaut;
import ihm.controleur.action_menu.ActionRetour;
import ihm.controleur.action_menu.ActionSuivant;

import java.io.IOException;
import java.util.ArrayList;

import application.modele.Configuration;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class VueChoixValeursJetons extends BorderPane{

	private ArrayList<Button> listeBoutonPlus;
	private ArrayList<Button> listeBoutonMoins;
	private ArrayList<Label> listeLabelJetons;	
	private ArrayList<HBox> listePanelCentre;
	private FenetreDemarrage parent;
	private VBox panelJeton;
	private PanelBasBoutons panelBasBouton;

	private Button personalisation;


	public VueChoixValeursJetons(FenetreDemarrage fenetreDemarrage) 
	{
		super();
		this.parent=fenetreDemarrage;
		this.getStyleClass().add("choixjetons");
		creerPanelJeton();
		this.setCenter(panelJeton);
		panelJeton.setAlignment(Pos.TOP_CENTER);
		creerPanelBasBouton();
	}

	private void creerPanelJeton()
	{
		panelJeton=new VBox(0);
		creerListeBoutonPlus();
		creerListeBoutonMoins();
		creerListeLabelJetons();
		creerListePanelCentre();			
		creerSection();
		creerBoutonPerso();

	}

	private void creerPanelBasBouton(){
		panelBasBouton=new PanelBasBoutons();
		panelBasBouton.setAlignment(Pos.CENTER);
		this.setBottom(panelBasBouton);
		panelBasBouton.getDefaut().setVisible(false);
		
		mettreActionAuxBoutonsPanelBas();
	}

	private void mettreActionAuxBoutonsPanelBas() {
		panelBasBouton.getDefaut().setOnAction(new ActionResetDefaut(this));
		panelBasBouton.getRetour().setOnAction(new ActionRetour(this.parent,this));
		panelBasBouton.getSuivant().setOnAction(new ActionSuivant(this.parent, this));
	}

	private void creerListeBoutonPlus()
	{
		listeBoutonPlus=new ArrayList<>();
		for(int i=0;i<5;i++)
		{
			Label plus=new Label("+");
			
			Button bouton = creerBoutonPlus(i, plus);
			listeBoutonPlus.add(bouton);			
		}
	}

	private Button creerBoutonPlus(int i, Label plus) {
		Button bouton;
		bouton=new Button(null,plus);
		plus.setScaleY(1.5);
		plus.setScaleX(1.5);
		bouton.setVisible(false);
		bouton.setPrefSize(60,60);
		bouton.setOnAction(new ActionCliquerPlus(this,i));
		bouton.getStyleClass().add("boutonChoix");
		bouton.setAlignment(Pos.CENTER);
		return bouton;
	}


	private void creerListeBoutonMoins()
	{
		listeBoutonMoins=new ArrayList<>(); 
		for(int i=0;i<5;i++)
		{
			Label moins=new Label("-");

			Button bouton = creerBoutonMoins(i, moins);
			listeBoutonMoins.add(bouton);			
		}
	}

	private Button creerBoutonMoins(int i, Label moins) {
		Button bouton;
		bouton=new Button(null,moins);
		bouton.setVisible(false);
		moins.setScaleY(1.5);
		moins.setScaleX(1.5);
		bouton.setPrefSize(60,60);
		bouton.setOnAction(new ActionCliquerMoins(this,i));
		bouton.getStyleClass().add("boutonChoix");
		return bouton;
	}

	private void creerListeLabelJetons()
	{
		listeLabelJetons=new ArrayList<Label>();

		for(int i=0;i<5;i++)
		{
			Label label = new Label();
			label.setText(String.valueOf(Configuration.getInstance().getListeConfigJetons().get("vJ"+i)));
			label.getStyleClass().add("labelJeton");
			label.setAlignment(Pos.CENTER_LEFT);
			label.setPrefSize(220, 50);
			listeLabelJetons.add(label);
		}
	}

	private void creerListePanelCentre(){
		listePanelCentre=new ArrayList<>();

		for(int i=0;i<5;i++)
		{
			listePanelCentre.add(new HBox());
			listePanelCentre.get(i).getChildren().add(listeLabelJetons.get(i));

			AnchorPane image = chargeJeton(i);
			listePanelCentre.get(i).getChildren().add(image);
			listePanelCentre.get(i).setAlignment(Pos.CENTER);
		}


	}

	private AnchorPane chargeJeton(int i) {
		String path=new String("/ressources/jeton/jeton_"+i+".fxml");
		FXMLLoader loader=new FXMLLoader();
		loader.setLocation(getClass().getResource(path));
		AnchorPane image=null;;
		try {
			image=(AnchorPane)loader.load();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return image;
	}

	private void creerSection()
	{
		for (int i=0;i<5;i++)
		{
			HBox section=new HBox();
			definirMargin(i);
			section.setAlignment(Pos.CENTER);
			section.getStyleClass().add("section");
			section.setPrefSize(200, 120);
			ajouteChildren(i, section);
			panelJeton.getChildren().add(section);
		}

	}

	private void ajouteChildren(int i, HBox section) {
		section.getChildren().add(listeBoutonMoins.get(i));
		section.getChildren().add(listePanelCentre.get(i));
		section.getChildren().add(listeBoutonPlus.get(i));
	}

	private void definirMargin(int i) {
		HBox.setMargin(listeBoutonMoins.get(i), new Insets(10,50,10,0));
		HBox.setMargin(listeBoutonPlus.get(i), new Insets(10,0,10,50));
	}


	private void creerBoutonPerso(){		

		Label texte=new Label("Personnaliser");
		personalisation=new Button(null,texte);
		Label vide=new Label(" ");
		texte.setScaleY(2);
		texte.setScaleX(2);
		personalisation.setPrefSize(300,50);
		personalisation.getStyleClass().add("boutonChoix");
		panelJeton.getChildren().add(vide);
		panelJeton.getChildren().add(personalisation);
		personalisation.setOnAction(new ActionPersonaliser(this));			
	}


	public PanelBasBoutons getPanelBasBouton() {
		return panelBasBouton;
	}

	public void setPanelBasBouton(PanelBasBoutons panelBasBouton) {
		this.panelBasBouton = panelBasBouton;
	}

	public Button getPersonalisation() {
		return personalisation;
	}

	public void setPersonalisation(Button personalisation) {
		this.personalisation = personalisation;
	}

	public ArrayList<Button> getListeBoutonPlus() {
		return listeBoutonPlus;
	}

	public ArrayList<Button> getListeBoutonMoins() {
		return listeBoutonMoins;
	}

	public void setListeBoutonPlus(ArrayList<Button> listeBoutonPlus) {
		this.listeBoutonPlus = listeBoutonPlus;
	}

	public void setListeBoutonMoins(ArrayList<Button> listeBoutonMoins) {
		this.listeBoutonMoins = listeBoutonMoins;
	}

	public ArrayList<Label> getListeLabelJetons() {
		return listeLabelJetons;
	}

	public void setListeLabelJetons(ArrayList<Label> listeLabelJetons) {
		this.listeLabelJetons = listeLabelJetons;
	}






}
