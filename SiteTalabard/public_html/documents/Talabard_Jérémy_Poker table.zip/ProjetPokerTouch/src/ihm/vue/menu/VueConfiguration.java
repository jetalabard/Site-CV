package ihm.vue.menu;

import ihm.controleur.action_menu.ActionCliquerMoins;
import ihm.controleur.action_menu.ActionCliquerPlus;
import ihm.controleur.action_menu.ActionLancerPartie;
import ihm.controleur.action_menu.ActionLimiteTemps;
import ihm.controleur.action_menu.ActionPasLimiteTemps;
import ihm.controleur.action_menu.ActionResetDefaut;
import ihm.controleur.action_menu.ActionRetour;

import java.util.ArrayList;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import application.modele.Configuration;

public class VueConfiguration extends BorderPane{

	private ArrayList<Button> listeBoutonPlus;
	private ArrayList<Button> listeBoutonMoins;
	private PanelBasBoutons panelBasBouton;
	private HBox panelMilieu;
	private FenetreDemarrage parent;
	private ToggleGroup group;
	private RadioButton noLimit;
	private RadioButton limit;
	private VBox paneldroit;
	private HBox temps; 
	private Label valeurSomme;
	private Label valeurTour;
	private Label valeurPetite;
	private Label valeurGrosse;
	private Label valeurTemps;

	public HBox getTemps() {
		return temps;
	}

	public void setTemps(HBox temps) {
		this.temps = temps;
	}

	public VueConfiguration(FenetreDemarrage parent) {
		this.parent=parent;	
		creerPanelCentre();			
		this.setCenter(panelMilieu);
		panelMilieu.setAlignment(Pos.TOP_CENTER);
		creerPanelBasBouton();
	}

	private void creerPanelBasBouton() {
		panelBasBouton=new PanelBasBoutons();
		panelBasBouton.setAlignment(Pos.CENTER);
		this.setBottom(panelBasBouton);
		panelBasBouton.getDefaut().setOnAction(new ActionResetDefaut(this));
		panelBasBouton.getRetour().setOnAction(new ActionRetour(this.parent,this));
		panelBasBouton.getLbsuivant().setText("Lancer la Partie");
		panelBasBouton.getSuivant().setOnAction(new ActionLancerPartie(this.parent, this));
	}

	private void creerBoxTemps() {
		temps=new HBox();
		temps.setAlignment(Pos.CENTER);
		Label labelsomme = creerLabelHeure();
		temps.getChildren().add(labelsomme);
		temps.getChildren().add(listeBoutonMoins.get(4));
		redefinirMargin();
		creerLabelTemps();
		temps.getChildren().add(valeurTemps);
		temps.getChildren().add(listeBoutonPlus.get(4));
	}

	private Label creerLabelHeure() {
		Label labelsomme=new Label("Nombre d'heures :");
		labelsomme.getStyleClass().add("labelconfigTitre");
		return labelsomme;
	}

	private void redefinirMargin() {
		HBox.setMargin(listeBoutonMoins.get(4), new Insets(10,20,10,30));
		HBox.setMargin(listeBoutonPlus.get(4), new Insets(10,0,10,20));
	}

	private void creerLabelTemps() {
		valeurTemps=new Label("3H00");
		valeurTemps.getStyleClass().add("labelconfig");
		valeurTemps.setPrefSize(80, 50);
		valeurTemps.setAlignment(Pos.CENTER);
	}

	private void creerPanelCentre() {
		panelMilieu=new HBox();		
		creerListeBoutonPlus();
		creerListeBoutonMoins();
		panelMilieu.getChildren().add(creerPanelGauche());
		panelMilieu.getChildren().add(creerPanelDroit());	
	}

	private void creerListeBoutonPlus()
	{
		listeBoutonPlus=new ArrayList<>();
		for(int i=0;i<5;i++)
		{
			Label plus=new Label("+");
			plus.setScaleY(3);
			plus.setScaleX(3);
			Button bouton = creerBoutonPlus(i, plus);
			listeBoutonPlus.add(bouton);			

		}
	}

	private Button creerBoutonPlus(int i, Label plus) {
		Button bouton=new Button(null,plus);
		bouton.setPrefSize(80,80);

		bouton.setOnAction(new ActionCliquerPlus(this,i));
		bouton.getStyleClass().add("boutonChoix");
		return bouton;
	}

	private void creerListeBoutonMoins()
	{
		listeBoutonMoins=new ArrayList<>();
		for(int i=0;i<5;i++)
		{
			Label moins=new Label("-");
			moins.setScaleY(3);
			moins.setScaleX(3);
			Button bouton = creerBoutonMoins(i, moins);
			listeBoutonMoins.add(bouton);			
		}
	}

	private Button creerBoutonMoins(int i, Label moins) {
		Button bouton=new Button(null, moins);
		bouton.setPrefSize(80,80);
		bouton.setAlignment(Pos.CENTER);			
		bouton.setOnAction(new ActionCliquerMoins(this,i));
		bouton.getStyleClass().add("boutonChoix");
		return bouton;
	}

	private VBox creerPanelDroit() {
		creerEtInitialisePanelDroit();
		
		creerBoxTemps();
		temps.setVisible(false);
		paneldroit.getChildren().add(temps);
		return paneldroit;
	}

	private void creerEtInitialisePanelDroit() {
		paneldroit=new VBox(40);
		paneldroit.setPrefWidth(5000);
		paneldroit.setPrefHeight(1000);
		paneldroit.setAlignment(Pos.TOP_CENTER);
		paneldroit.getChildren().add(creerSectionTemps());
		paneldroit.getChildren().add(creerSectionPasLimite());
		paneldroit.getChildren().add(creerSectionLimite());
	}


	private VBox creerPanelGauche() {
		VBox panelgauche=new VBox(40);
		initialisePanelGauche(panelgauche);
		Label info=new Label("* Nombre de tours de jeu avant d'incr�menter les blinds");
		info.getStyleClass().add("labelconfig");
		panelgauche.getChildren().add(info);
		return panelgauche;
	}

	private void initialisePanelGauche(VBox panelgauche) {
		panelgauche.getStyleClass().add("boxconfig");
		panelgauche.setAlignment(Pos.TOP_CENTER);
		panelgauche.setPrefWidth(5000);
		panelgauche.getChildren().add(creerSectionBlinds());
		panelgauche.getChildren().add(creerSectionTour());
	}



	private HBox creerSectionTour() {
		HBox somme=new HBox();
		somme.setAlignment(Pos.CENTER);
		somme = creerLabelSomme(somme);
		somme.getChildren().add(listeBoutonMoins.get(3));
		
		HBox.setMargin(listeBoutonMoins.get(3), new Insets(10,20,10,30));
		HBox.setMargin(listeBoutonPlus.get(3), new Insets(10,0,10,20));
		
		creerValeurTour();
		
		somme.getChildren().add(valeurTour);
		somme.getChildren().add(listeBoutonPlus.get(3));
		return somme;
	}

	private HBox creerLabelSomme(HBox somme) {
		Label labelsomme=new Label("Augmenter Blinds * :");
		labelsomme.getStyleClass().add("labelconfigTitre");		
		somme.getChildren().add(labelsomme);
		return somme;
	}

	private void creerValeurTour() {
		valeurTour=new Label(String.valueOf(Configuration.getInstance().getNbTourChangeBlind()));
		valeurTour.getStyleClass().add("labelconfig");
		valeurTour.setPrefSize(80, 50);
		valeurTour.setAlignment(Pos.CENTER);
	}


	private HBox creerSectionBlinds() {
		HBox blinds=new HBox();
		ajouteMarginAuHBoxDesBlinds();
		blinds.setAlignment(Pos.TOP_CENTER);
		Label labelBlinds = creerLabelBlind();
		blinds.getChildren().add(labelBlinds);
		blinds.getChildren().add(creerPanelBlinds());
		return blinds;
	}

	private Label creerLabelBlind() {
		Label labelBlinds=new Label("Valeurs blinds :");
		labelBlinds.getStyleClass().add("labelconfigTitre");
		return labelBlinds;
	}

	private void ajouteMarginAuHBoxDesBlinds() {
		HBox.setMargin(listeBoutonMoins.get(1), new Insets(10,20,10,10));
		HBox.setMargin(listeBoutonMoins.get(2), new Insets(10,20,10,10));
		HBox.setMargin(listeBoutonPlus.get(1), new Insets(10,0,10,20));
		HBox.setMargin(listeBoutonPlus.get(2), new Insets(10,0,10,20));
	}

	private VBox creerPanelBlinds() {
		VBox blinds=new VBox(30);
		blinds.setAlignment(Pos.TOP_CENTER);
		Configuration.getInstance().parDefautConfig();
		blinds.getChildren().add(creerPetiteBlind());
		blinds.getChildren().add(creerGrosseBlind());
		return blinds;
	}

	private Node creerGrosseBlind() {
		HBox grosse=new HBox();
		grosse.setAlignment(Pos.CENTER);
		Label lbgrosse = creerLabelBlind("Grosse :");
		grosse.getChildren().add(lbgrosse);
		grosse.getChildren().add(listeBoutonMoins.get(2));
		
		creerValeurGrosse();
		grosse.getChildren().add(valeurGrosse);
		grosse.getChildren().add(listeBoutonPlus.get(2));
		return grosse;
	}

	private Label creerLabelBlind(String label) {
		Label lbgrosse= new Label(label);
		lbgrosse.getStyleClass().add("labelconfig");
		return lbgrosse;
	}

	private void creerValeurGrosse() {
		valeurGrosse=new Label(String.valueOf(Configuration.getInstance().getValeurGrosseBlind().retourneMontant()));
		valeurGrosse.getStyleClass().add("labelconfig");
		valeurGrosse.setPrefWidth(80);
		valeurGrosse.setAlignment(Pos.CENTER);
	}

	private HBox creerPetiteBlind() {
		HBox petite=new HBox();
		petite.setAlignment(Pos.CENTER);
		Label lbpetit = creerLabelBlind("Petite : ");
		petite.getChildren().add(lbpetit);
		petite.getChildren().add(listeBoutonMoins.get(1));
		creerValeurPetite();
		petite.getChildren().add(valeurPetite);
		petite.getChildren().add(listeBoutonPlus.get(1));
		return petite;
	}

	private void creerValeurPetite() {
		valeurPetite=new Label(String.valueOf(Configuration.getInstance().getValeurPetiteBlind().retourneMontant()));
		valeurPetite.setPrefWidth(80);
		valeurPetite.setAlignment(Pos.CENTER);
		valeurPetite.getStyleClass().add("labelconfig");
	}

	private Node creerSectionLimite() {
		HBox limite=new HBox();
		limite.setAlignment(Pos.CENTER);
		
		creerRadioButtonLimit();
		
		limite.getChildren().add(limit);
		Label lab=new Label("Avec limite de temps");
		lab.getStyleClass().add("labelconfig");
		limite.getChildren().add(lab);
		return limite;
	}

	private void creerRadioButtonLimit() {
		limit=new RadioButton();
		limit.setToggleGroup(group);	
		limit.setOnAction(new ActionLimiteTemps(this));
	}

	private HBox creerSectionPasLimite() {
		HBox paslimite=new HBox();
		paslimite.setAlignment(Pos.CENTER);
		group=new ToggleGroup();
		
		creerRadioButtonNoLimit();		
		paslimite.getChildren().add(noLimit);
		Label lab=new Label("Sans limite de temps");
		lab.getStyleClass().add("labelconfig");
		paslimite.getChildren().add(lab);
		return paslimite;
	}

	private void creerRadioButtonNoLimit() {
		noLimit=new RadioButton();
		noLimit.setSelected(true);
		noLimit.setOnAction(new ActionPasLimiteTemps(this));
		noLimit.setToggleGroup(group);
	}

	private HBox creerSectionTemps() {
		HBox temps=new HBox();
		temps.setAlignment(Pos.CENTER);
		Label labeltemps=new Label("Temps de la partie :");
		labeltemps.getStyleClass().add("labelconfigTitre");
		temps.getChildren().add(labeltemps);
		return temps;
	}

	public void afficherSectionLimite() {
		temps.setVisible(true);

	}

	public void enleverSectionLimite(){
		temps.setVisible(false);

	}

	public Label getValeurSomme() {
		return valeurSomme;
	}

	public void setValeurSomme(Label valeurSomme) {
		this.valeurSomme = valeurSomme;
	}

	public Label getValeurTour() {
		return valeurTour;
	}

	public Label getValeurPetite() {
		return valeurPetite;
	}

	public Label getValeurGrosse() {
		return valeurGrosse;
	}

	public Label getValeurTemps() {
		return valeurTemps;
	}

	public RadioButton getNoLimit() {
		return noLimit;
	}

	public void setNoLimit(RadioButton noLimit) {
		this.noLimit = noLimit;
	}
	public RadioButton getLimit() {
		return limit;
	}

	public void setLimit(RadioButton limit) {
		this.limit = limit;
	}

	public void setValeurTour(Label valeurTour) {
		this.valeurTour = valeurTour;
	}

	public void setValeurPetite(Label valeurPetite) {
		this.valeurPetite = valeurPetite;
	}

	public void setValeurGrosse(Label valeurGrosse) {
		this.valeurGrosse = valeurGrosse;
	}

	public void setValeurTemps(Label valeurTemps) {
		this.valeurTemps = valeurTemps;
	}
}
