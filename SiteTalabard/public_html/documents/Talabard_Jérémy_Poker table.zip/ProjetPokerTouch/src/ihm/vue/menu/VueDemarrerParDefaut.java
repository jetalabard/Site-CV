package ihm.vue.menu;

import ihm.controleur.action_menu.ActionLancerPartie;
import ihm.controleur.action_menu.ActionRetour;
import ihm.controleur.action_menu.ActionSuivant;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class VueDemarrerParDefaut extends VBox{

	private FenetreDemarrage parent;
	private Button demarrer;
	private Button config;
	private Button retour;
	
	public VueDemarrerParDefaut(FenetreDemarrage fenetreDemarrage){
		this.parent=fenetreDemarrage;
		creerPanelBoutonConfigurer();
		creerPanelBoutonDefaut();		
		creerPanelBoutonRetour();
		mettreMargin();
	}


	private void mettreMargin() {
		VBox.setMargin(demarrer, new Insets(50,0,50,0));
		VBox.setMargin(config, new Insets(50,0,50,0));
		VBox.setMargin(retour, new Insets(50,0,50,0));
	}


	private void creerPanelBoutonRetour() {
		Label lbretour=new Label("Retour");
		retour=new Button(null, lbretour);
		retour.setOnAction(new ActionRetour(this.parent,this));
		
		lbretour.setScaleX(3);
		lbretour.setScaleY(3);
		retour.setPrefSize(1000, 150);
		retour.getStyleClass().add("boutonChoix");
		VBox.setMargin(retour, new Insets(20,200,20,200));
		this.setAlignment(Pos.CENTER);
		this.getChildren().add(retour);
	}


	private void creerPanelBoutonDefaut() {
		Label defaut=new Label("Lancer une partie pr�configur�e");
		demarrer=new Button(null, defaut);
		demarrer.setOnAction(new ActionLancerPartie(this.parent,this));
		defaut.setScaleX(3);
		defaut.setScaleY(3);
		demarrer.setPrefSize(1000, 150);
		demarrer.getStyleClass().add("boutonChoix");
		VBox.setMargin(demarrer, new Insets(20,200,20,200));
		this.setAlignment(Pos.CENTER);
		this.getChildren().add(demarrer);
		
	}
	
	private void creerPanelBoutonConfigurer() {
		Label labelquitter=new Label("Configurer une partie");
		config=new Button(null, labelquitter);
		config.setOnAction(new ActionSuivant(this.parent,this));
		labelquitter.setScaleX(3);
		labelquitter.setScaleY(3);
		config.setPrefSize(800, 150);
		config.getStyleClass().add("boutonChoix");
		this.setAlignment(Pos.CENTER);
		this.getChildren().add(config);
		
	}
	public Button getDemarrer() {
		return demarrer;
	}


	public void setDemarrer(Button demarrer) {
		this.demarrer = demarrer;
	}


	public Button getConfig() {
		return config;
	}


	public void setConfig(Button config) {
		this.config = config;
	}


	public Button getRetour() {
		return retour;
	}


	public void setRetour(Button retour) {
		this.retour = retour;
	}

	
	
}
