package ihm.vue.menu;

import ihm.controleur.action_menu.ActionCliquerQuitter;
import ihm.controleur.action_menu.ActionSuivant;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class VueDemarrerPartie extends VBox{

	private FenetreDemarrage parent;
	private Button demarrer;
	private Button quitter;
	
	
	public VueDemarrerPartie(FenetreDemarrage fenetreDemarrage){
		this.parent=fenetreDemarrage;
		creerPanelBoutonDemarrer();
		creerPanelBoutonQuitter();
		VBox.setMargin(demarrer, new Insets(50,0,50,0));
		VBox.setMargin(quitter, new Insets(50,0,50,0));
	}


	private void creerPanelBoutonDemarrer() {
		Label labeldemarrer=new Label("Demarrer une partie");
		demarrer=new Button(null, labeldemarrer);
		demarrer.setOnAction(new ActionSuivant(this.parent,this));
		labeldemarrer.setScaleX(3);
		labeldemarrer.setScaleY(3);
		demarrer.setPrefSize(1000, 150);
		demarrer.getStyleClass().add("boutonChoix");
		VBox.setMargin(demarrer, new Insets(20,200,20,200));
		this.setAlignment(Pos.CENTER);
		this.getChildren().add(demarrer);
		
	}
	
	private void creerPanelBoutonQuitter() {
		Label labelquitter=new Label("Quitter");
		quitter=new Button(null, labelquitter);
		quitter.setOnAction(new ActionCliquerQuitter(this.parent));
		labelquitter.setScaleX(3);
		labelquitter.setScaleY(3);
		quitter.setPrefSize(800, 150);
		quitter.getStyleClass().add("boutonChoix");
		this.setAlignment(Pos.CENTER);
		this.getChildren().add(quitter);
		
	}


	public Button getDemarrer() {
		return demarrer;
	}


	public void setDemarrer(Button demarrer) {
		this.demarrer = demarrer;
	}


	public Button getQuitter() {
		return quitter;
	}


	public void setQuitter(Button quitter) {
		this.quitter = quitter;
	}


	
	
}
