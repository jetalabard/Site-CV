package ihm.vue.plateau;

import java.util.ArrayList;

import javafx.animation.RotateTransition;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.scene.Node;
import javafx.util.Duration;
import application.metier.Joueur;
import application.modele.Partie;

/**
 * gere les animations du plateau
 * @author J�r�my
 *
 */
public class Animation {

	/**
	 * instance de la classe animation
	 */
	private static Animation instance;
	/**
	 * constructeur
	 */
	private Animation() {

	}
	/**
	 * retourne l'instance de la classe 
	 * @return
	 */
	public static Animation getInstance() {
		if(instance == null)
		{
			instance = new Animation();
		}
		return instance;
	}
	/**
	 * quand le dealer distribue faire animation
	 */
	public void faireAnimationLancerDeCarte() {
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				distribuerCarte(Partie.getInstance().getJeuEncours().getListeJoueurEnJeu());	

			}
		});
	}
	/**
	 * distribue les cartes une par une
	 * @param listeJoueur
	 */
	public void distribuerCarte(ArrayList<Joueur> listeJoueur) {
		for(Joueur j:listeJoueur){

			int pos=j.getEmplacement();
			PlateauDeJeu.getInstance().getpMilieuCarte().initialiseCarteDos();
			TranslateTransition tr=new TranslateTransition();
			RotateTransition ro=new RotateTransition(Duration.millis(1400), PlateauDeJeu.getInstance().getpMilieuCarte().getCarteDos());
			ro.setByAngle(360);
			gerePositionEtFaitAnimation(PlateauDeJeu.getInstance().getTailleHeight(), PlateauDeJeu.getInstance().getTailleWidth(), pos, tr, ro);
		}
	}


	/**
	 * fait l'animation de distribution
	 * @param tailleHeight
	 * @param tailleWidth
	 * @param pos
	 * @param tr
	 * @param ro
	 */
	private void gerePositionEtFaitAnimation(double tailleHeight,double tailleWidth, int pos, TranslateTransition tr,RotateTransition ro) {
		double posX = 0;
		double posY = 0;
		if(pos<4){
			posY=tailleHeight-(tailleHeight/3);
			posX=tailleWidth-(tailleWidth*0.50)-475*(pos+1);
		}
		else if (pos==4) {
			posY=0;
			posX=-(tailleWidth-(tailleWidth/4));
		}
		else if(pos==9){
			posY=0;
			posX=(tailleWidth-(tailleWidth/3));
		}
		else{
			posY=-(tailleHeight-(tailleHeight/3));
			int distance=-(-9+pos);
			posX=tailleWidth-(tailleWidth*0.50)-475*(pos+distance);
		}		
		faireAnimationDistribution(posX, posY, tr, ro);
	}

	/**
	 * modifie le TranslateTransition
	 * @param posX
	 * @param posY
	 * @param tr
	 * @param ro
	 */
	private void faireAnimationDistribution(double posX, double posY,
			TranslateTransition tr, RotateTransition ro) {
		tr.setToX(0);
		tr.setToX(posX);
		tr.setToY(0);
		tr.setToY(posY);
		tr.setDuration(Duration.millis(700));
		tr.setNode(PlateauDeJeu.getInstance().getpMilieuCarte().getCarteDos());
		tr.setCycleCount(2);
		tr.play();		
		ro.play();
	}
	/**
	 * anime bouton
	 * @param bouton
	 * @param from
	 */
	public void animeBouton(Node bouton,int from)
	{
		TranslateTransition boutonAnime=new TranslateTransition(Duration.millis(800),bouton);
		boutonAnime.setFromX(from);
		boutonAnime.setToX(0);
		boutonAnime.play();
	}

}