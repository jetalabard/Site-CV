package ihm.vue.plateau;

import javafx.scene.Group;
import javafx.scene.control.Control;
import javafx.scene.layout.AnchorPane;

public class Dimension {

	/**
	 * instance de dimension
	 */
	private static Dimension instance;
	/**
	 * largeur fenetre
	 */
	private double widthFenetre;
	/**
	 * hauteur fenetre
	 */
	private double heightFenetre;
	/**
	 * scale carte
	 */
	private double scaleCartes;
	/**
	 * scale jeton
	 */
	private double scaleJetons;
	/**
	 * largeur entre jeton
	 */
	private double largeurEntreJetons;
	/**
	 * largeur entre carte
	 */
	private double largeurEntreCartes;
	/**
	 * translation carte1 en X
	 */
	private double TranslateXMainCarte1;
	/**
	 * translation carte2 en X
	 */
	private double TranslateXMainCarte2;
	/**
	 * translation carte en Y
	 */
	private double TranslateYMainCarte;	
	/**
	 * scale parser
	 */
	private double parserScale;
	/**
	 * distance gauche pour parser
	 */
	private double parserDistanceTop;
	/**
	 * distance droite pour parser
	 */
	private double parserDistanceRight;
	/**
	 * taille de la pile pour le parser
	 */
	private int parserTailleDePile;	
	/**
	 * distance entre animation cartes
	 */
	private double distanceAnimationCartes;

	/**
	 * constructeur
	 */
	private Dimension(){
		initialiseTaille();
	}
	/**
	 * initialise les dimensions
	 */
	private void initialiseTaille() {
		scaleCartes=0.3;
		scaleJetons=0.2;
		largeurEntreJetons=60;
		largeurEntreCartes=-85;
		TranslateXMainCarte1=-10;
		TranslateXMainCarte2=80;
		TranslateYMainCarte=-300;
		parserScale=0;
		parserDistanceTop=0;
		parserDistanceRight=0;
		parserTailleDePile=0;	
		distanceAnimationCartes=-150;
	}
	/**
	 * retourne l'instance de dimension
	 * @return
	 */
	public static Dimension getInstance(){
		if(instance==null){
			instance=new Dimension();
		}
		return instance;
	}
	/**
	 * met � jour les dimensions
	 */
	public void update() {

		if(widthFenetre<1690){
			largeurInferieurA1690();

		}else{
			largeurSuperieurA1690();
		}
	}
	/**
	 * met � jour dimension si largeur superieur a 1690
	 */
	private void largeurSuperieurA1690() {
		scaleCartes=0.3;
		scaleJetons=0.2;
		largeurEntreJetons=60;
		largeurEntreCartes = -85;
		TranslateYMainCarte=-300;
		TranslateXMainCarte1=-10;
		TranslateXMainCarte2=80;
		setDistanceAnimationCartes(-150);
	}
	/**
	 * met � jour dimension si largeur inferieur a 1690
	 */
	private void largeurInferieurA1690() {
		scaleCartes=0.2;
		scaleJetons=0.13;
		largeurEntreJetons=30;
		largeurEntreCartes = -115;
		TranslateYMainCarte=-250;
		TranslateXMainCarte1=-20;
		TranslateXMainCarte2=50;
		setDistanceAnimationCartes(-75);
	}
	/***
	 * affecte les dimensions du parser
	 * @param scale
	 * @param distanceTop
	 * @param distanceRight
	 * @param taillePile
	 */
	public void affecterDimensionDuParser(double scale, double distanceTop, double distanceRight, int taillePile){
		this.parserScale=scale;
		this.parserDistanceTop=distanceTop;
		this.parserDistanceRight=distanceRight;
		this.parserTailleDePile=taillePile;		
	}

	
	/**
	 * redimensionne jeton
	 * @param jeton
	 * @return
	 */
	public AnchorPane redimensionneJeton(AnchorPane jeton) {
		jeton.setScaleX(scaleJetons);
		jeton.setScaleY(scaleJetons);
		jeton.setMinWidth(largeurEntreJetons);
		jeton.setPrefWidth(largeurEntreJetons);
		return jeton;
	}

	public AnchorPane modifieDimensionPile(AnchorPane zoneMiseAnchorPane) {
		zoneMiseAnchorPane.setScaleX(scaleJetons);
		zoneMiseAnchorPane.setScaleY(scaleJetons);
		zoneMiseAnchorPane.setPrefWidth(150);
		zoneMiseAnchorPane.setPrefHeight(5);
		return zoneMiseAnchorPane;
	}


	public AnchorPane modifieTailleJeton(AnchorPane jeton) {
		redimensionneJeton(jeton);
		jeton.setPrefHeight(5);
		return jeton;
	}

	/**
	 * redefinit les tailles de cartes
	 * @param carte
	 * @param anchor
	 * @param ratio
	 * @return
	 */
	public AnchorPane redefinirTailleCarte(Group carte, AnchorPane anchor, double ratio) {
		update();
		carte.setScaleX(scaleCartes);
		carte.setScaleY(carte.getScaleX());
		PlateauDeJeu.getInstance().getpMilieuCarte().getListeDesCartes().add(carte);
		anchor.getChildren().add(carte);
		anchor.setPrefSize(1, 1);
		anchor.setMinSize(Control.USE_PREF_SIZE, Control.USE_PREF_SIZE);
		anchor.setMaxSize(Control.USE_PREF_SIZE, Control.USE_PREF_SIZE);
		carte.setTranslateX(largeurEntreCartes);
		carte.setTranslateY(-120);
		return anchor;

	}
	public double getScaleCartes() {
		return scaleCartes;
	}

	public double getScaleJetons() {
		return scaleJetons;
	}

	public void setWidthFenetre(double widthFenetre) {
		this.widthFenetre = widthFenetre;
	}

	public void setHeightFenetre(double heightFenetre) {
		this.heightFenetre = heightFenetre;
	}

	public void setScaleCartes(double scaleCartes) {
		this.scaleCartes = scaleCartes;
	}

	public void setScaleJetons(double scaleJetons) {
		this.scaleJetons = scaleJetons;
	}

	public double getLargeurEntreCartes() {
		return largeurEntreCartes;
	}
	public void setLargeurEntreCartes(double largeurEntreCartes) {
		this.largeurEntreCartes = largeurEntreCartes;
	}

	public void setLargeurEntreJetons(double largeurEntreJetons) {
		this.largeurEntreJetons = largeurEntreJetons;
	}

	public double getTranslateXMainCarte1() {
		return TranslateXMainCarte1;
	}

	public void setTranslateXMainCarte1(double translateXMainCarte1) {
		TranslateXMainCarte1 = translateXMainCarte1;
	}

	public double getTranslateXMainCarte2() {
		return TranslateXMainCarte2;
	}

	public void setTranslateXMainCarte2(double translateXMainCarte2) {
		TranslateXMainCarte2 = translateXMainCarte2;
	}

	public double getTranslateYMainCarte() {
		return TranslateYMainCarte;
	}

	public double getLargeurEntreJetons() {
		return largeurEntreJetons;
	}
	public void setTranslateYMainCarte(double translateYMainCarte) {
		TranslateYMainCarte = translateYMainCarte;
	}

	public double getParserScale() {
		return parserScale;
	}

	public void setParserScale(double parserScale) {
		this.parserScale = parserScale;
	}


	public double getParserDistanceTop() {
		return parserDistanceTop;
	}

	public void setParserDistanceTop(double parserDistanceTop) {
		this.parserDistanceTop = parserDistanceTop;
	}

	public double getParserDistanceRight() {
		return parserDistanceRight;
	}

	public void setParserDistanceRight(double parserDistanceRight) {
		this.parserDistanceRight = parserDistanceRight;
	}

	public double getParserTailleDePile() {
		return parserTailleDePile;
	}

	public void setParserTailleDePile(int parserTailleDePile) {
		this.parserTailleDePile = parserTailleDePile;
	}

	public double getDistanceAnimationCartes() {
		return distanceAnimationCartes;
	}

	public void setDistanceAnimationCartes(double distanceAnimationCartes) {
		this.distanceAnimationCartes = distanceAnimationCartes;
	}
	public double getWidthFenetre() {
		return widthFenetre;
	}
	public double getHeightFenetre() {
		return heightFenetre;
	}
}
