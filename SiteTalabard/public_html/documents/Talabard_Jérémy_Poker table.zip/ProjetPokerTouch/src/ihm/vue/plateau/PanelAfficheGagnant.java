package ihm.vue.plateau;

import ihm.controleur.action_table.ActionRetourMenuPrincipal;
import javafx.animation.FadeTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;

public class PanelAfficheGagnant extends VBox{

	
	private Button quitter;
	
	private Stage stage;
	
	public PanelAfficheGagnant(ZoneJoueur joueur,Stage stage) {
		
		this.setAlignment(Pos.CENTER);
		this.stage = stage;
		Label quit = creerLabel("Quitter");
		creerBoutonQuitter(quit);
		Label titre = new Label("Gagnant");
		titre.getStyleClass().add("lbWinner");
		this.getChildren().add(titre);
		afficherWinner(joueur);
		ajouteChildren();
		VBox.setMargin(quitter, new Insets(0,0,50,0));
	}

	private void ajouteChildren() {
		this.getChildren().add(quitter);
	}
	
	
	public void afficherWinner(ZoneJoueur j)
	{
		Label win = new Label(j.getPseudo().getText());
		
		Label argent = new Label(String.valueOf(j.getArgent().getText()));
		argent.getStyleClass().add("lbWinner");
		win.getStyleClass().add("lbWinner");
		this.getChildren().add(win);
		this.getChildren().add(argent);
		this.getChildren().add(j.getPanelCentre());
		this.getChildren().get(2).setLayoutX(800);
		final FadeTransition fade = new FadeTransition(Duration.millis(300),win);
		fade.setFromValue(1.0);
		fade.setToValue(0);
		fade.setCycleCount(1000);
		fade.setAutoReverse(true);
		fade.play();
		
	}
	

	private Label creerLabel(String label) {
		Label quit=new Label(label);
		quit.getStyleClass().add("labelChoixMenu");
		return quit;
	}

	private void creerBoutonQuitter(Label quit) {
		quitter=new Button(null, quit);
		quitter.getStyleClass().add("boutonChoix");
		quitter.setPrefSize(400, 80);
		quitter.setOnMouseClicked(new ActionRetourMenuPrincipal(this.stage));
	}

}
