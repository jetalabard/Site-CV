package ihm.vue.plateau;

import application.dataloader.ParserJeton;
import application.metier.Joueur;
import application.modele.ListeJeton;
import application.modele.Partie;
import ihm.controleur.action_table.ActionBoutonLancer;
import ihm.controleur.action_table.ActionBoutonLancerJeu;
import javafx.application.Platform;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;

public class PanelBoutonLancer extends AnchorPane{

	private Button lancer;
	private double e;
	private double d;

	public PanelBoutonLancer(double d, double e) {
		this.d = d;
		this.e =e;
		System.gc();
	}

	public void boutonLancerPartie() {
		Label lb=new Label("Lancer la partie");
		lb.getStyleClass().add("labelLancer");

		lancer=new Button(null, lb);
		lancer.setOnAction(new ActionBoutonLancer());
		lancer.setPrefSize(d, e);
		lancer.getStyleClass().add("boutonChoix");

		this.getChildren().add(lancer);
	}

	public void boutonLancerJeu() {

		reinitialiseListeJetonMiseJoueur();

		for(Joueur j : Partie.getInstance().getListeJoueur())
		{
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).mettreAJourJeton(j);
				}
			});
		}
		Label lb=new Label("Lancer nouveau jeu");
		lb.getStyleClass().add("labelLancer");

		PlateauDeJeu.getInstance().setpMilieuCarte(null);
		lancer=new Button(null, lb);
		lancer.setOnAction(new ActionBoutonLancerJeu());
		lancer.setPrefSize(d, e);
		lancer.getStyleClass().add("boutonChoix");

		this.getChildren().add(lancer);
	}
	
	private void reinitialiseListeJetonMiseJoueur() {
		System.out.println("Panel bouton lancer r�initialise joueurs");
		for(Joueur j: Partie.getInstance().getListeJoueur())
		{
			j.setListeJetonMise(new ListeJeton());
			j.getListeJetonMise().initialiseListeJeton();
			j.setJetonsDejaMise(new ListeJeton());
			j.getJetonsDejaMise().initialiseListeJeton();
			
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					ParserJeton parser =new ParserJeton();
					parser.mettreAJourDocumentMisesJoueur(j);
					PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).getMise().setText("0");
					PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).creerZoneMise(j);
				}
			});
			j.setNbRelanceAuTour(0);
		}
	}


	public Button getLancer() {
		return lancer;
	}

	public void setLancer(Button lancer) {
		this.lancer = lancer;
	}
}
