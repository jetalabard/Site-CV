package ihm.vue.plateau;



import ihm.controleur.action_table.affichage.ActionAfficherMenu;

import java.net.InetAddress;
import java.net.UnknownHostException;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;

public class PanelChargement extends VBox{

	private Image image;

	private ImageView vue;
	
	private Button menu;

	public PanelChargement() {
		
		image=new RecupereImageFXML().recupereGif();
		Label lb=new Label("Menu");
		lb.getStyleClass().add("labelMenu");
		menu=new Button(null,lb);
		menu.setOnAction(new ActionAfficherMenu(1));
		menu.getStyleClass().add("boutonChoix");
		this.getChildren().add(menu);
		menu.setVisible(false);
		
		vue=new ImageView(image);
		Label label=new Label("En attente de joueurs ...");
		label.getStyleClass().add("labelChargement");
		
		Label ip=new Label(recupererIp());
		ip.getStyleClass().add("labelIP");
		getChildren().add(label);
		getChildren().add(vue);
		getChildren().add(ip);
		setAlignment(Pos.CENTER);
		
	}
	
	public String recupererIp(){
		String ip = null;
		try {
			ip = InetAddress.getLocalHost().getHostAddress();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		String message=new String("Adresse du serveur : "+ip);
		return message;
	}

	public void affiche() {
		menu.setVisible(true);// TODO Auto-generated method stub
		
	}

	public void efface() {
		menu.setVisible(false);
	}
	
}
