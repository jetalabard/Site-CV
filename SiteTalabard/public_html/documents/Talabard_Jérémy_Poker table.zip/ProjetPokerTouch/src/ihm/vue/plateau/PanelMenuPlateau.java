package ihm.vue.plateau;


import ihm.controleur.action_table.ActionContinuer;
import ihm.controleur.action_table.ActionRetourMenuPrincipal;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class PanelMenuPlateau extends VBox{

	private Button continuer;
	
	private Button quitter;
	
	private ZoneMilieu zone;
	
	private Stage stage;
	
	public PanelMenuPlateau(ZoneMilieu zone, Stage stage,int mode) {
		this.setZone(zone);
		this.stage=stage;
		this.setAlignment(Pos.CENTER);
		
		Label quit = creerLabel("Quitter");
		Label conti= creerLabel("Continuer");
		
		creerBoutonContinuer(zone, conti,mode);
		creerBoutonQuitter(quit);
		
		ajouteChildren();
		VBox.setMargin(continuer, new Insets(0,0,50,0));
	}

	private void ajouteChildren() {
		this.getChildren().add(continuer);
		this.getChildren().add(quitter);
	}

	private Label creerLabel(String label) {
		Label quit=new Label(label);
		quit.getStyleClass().add("labelChoixMenu");
		return quit;
	}

	private void creerBoutonQuitter(Label quit) {
		quitter=new Button(null, quit);
		quitter.getStyleClass().add("boutonChoix");
		quitter.setPrefSize(400, 80);
		quitter.setOnMouseClicked(new ActionRetourMenuPrincipal(this.stage));
	}

	private void creerBoutonContinuer(ZoneMilieu zone, Label conti,int mode) {
		continuer=new Button(null, conti);
		continuer.setOnAction(new ActionContinuer(zone,mode));
		continuer.setPrefSize(400, 80);
		continuer.getStyleClass().add("boutonChoix");
	}

	public ZoneMilieu getZone() {
		return zone;
	}

	public void setZone(ZoneMilieu zone) {
		this.zone = zone;
	}
}
