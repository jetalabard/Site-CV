package ihm.vue.plateau;

import ihm.controleur.action_table.ActionCliquerChargement;
import ihm.controleur.action_table.affichage.ActionAfficheBoutonPourInfo;
import ihm.controleur.action_table.affichage.ActionAfficherGagnantPartie;
import ihm.controleur.action_table.affichage.ActionEffacerBoutonZoneMilieu;

import java.util.ArrayList;

import javafx.animation.RotateTransition;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;
import application.metier.Joueur;
import application.modele.Partie;

public class PlateauDeJeu extends BorderPane{

	private static PlateauDeJeu instance=null;

	private HBox pHaut;
	private HBox pBas;
	private VBox pDroite;
	private VBox pGauche;	
	private PanelChargement pMilieuChargement;
	private ZoneMilieu pMilieuCarte;



	private PanelBoutonLancer pMilieuBouton;
	private PanelMenuPlateau pMiMenuPlateau;
	private PanelAfficheGagnant pMiAfficheGagnant;
	private ArrayList<ZoneJoueur> listeZoneJoueur;
	private double tailleWidth;
	private double tailleHeight;
	private double oldTailleH;
	private double oldTailleW;
	private Stage stage;
	private Label lb;	

	public static PlateauDeJeu getInstance(){
		if(instance==null){
			instance=new PlateauDeJeu();
		}
		return instance;
	}


	private PlateauDeJeu(){
		this.getStyleClass().add("plateau");
		tailleHeight=1080;
		tailleWidth=1920;
		Dimension.getInstance().setWidthFenetre(tailleWidth);
		Dimension.getInstance().setHeightFenetre(tailleHeight);
		initialise();
	}

	public void affiche()
	{
		if(Partie.getInstance().getListeJoueur().size() >=2)
		{
			if(Partie.getInstance().getJeuEncours() == null)
			{
				new ActionCliquerChargement(0);
			}
			else{
				new ActionCliquerChargement(1);
			}
		}
		else if(Partie.getInstance().getListeJoueur().size() == 1 && Partie.getInstance().getGagnant() != null)
		{
			new ActionAfficherGagnantPartie(Partie.getInstance().getGagnant());
		}
		else{
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					afficherChargement();
				}
			});
		}
	}

	private void initialise() {
		creerListeZoneJoueur();
		creerPanelHaut();
		creerPanelDroite();
		creerPanelBas();
		creerPanelGauche();	
		creerPanelCentre();
		placerComposants();
		redimensionPanel();
	}

	private void redimensionPanel() {

		Dimension.getInstance().setWidthFenetre(tailleWidth);
		Dimension.getInstance().setHeightFenetre(tailleHeight);

		for (ZoneJoueur j:listeZoneJoueur){
			redimensionneZoneJoueur(j);
			if(j.getPanelCentre()!=null && j.getPanelCentre().getChildren()!=null ){
				Dimension.getInstance().update();
				j.redimensionPanelBas(j.getWidth());
			}				
			if(j!=listeZoneJoueur.get(4) && j!=listeZoneJoueur.get(9)){
				j.setPrefSize(tailleWidth/4, tailleHeight/3.3);
				j.setMaxSize(tailleWidth/4, (tailleHeight/3.3)-50);
			}else
			{
				j.setPrefWidth((tailleWidth/4)-10);
				j.setPrefHeight(tailleHeight-((tailleHeight/2)));
				j.setMaxWidth((tailleWidth/4)-10);
				j.setMaxHeight(tailleHeight-((tailleHeight/2)));
			}

		}
		if(pMilieuBouton!=null){
			pMilieuBouton.getLancer().setPrefSize(tailleWidth/2, tailleHeight/3);
		}
		if(pMilieuChargement!=null){
			pMilieuChargement.setPrefSize(tailleWidth/2, tailleHeight/3);
		}
		if(pMilieuCarte != null)
		{
			pMilieuCarte.redimensionJetonPotPrincipal();
			if(pMilieuCarte.getListeDesCartes() != null)
			{
				for (Group g:pMilieuCarte.getListeDesCartes()){
					if(tailleWidth<1920){
						g.setScaleX(0.3);
						g.setScaleY(0.3);
						if(g.getTranslateY()>-148){
							g.setLayoutX(0);
							g.setTranslateY(-(tailleHeight/6.5));

						}
						pMilieuCarte.changerMargin(tailleHeight,tailleWidth);
						if(tailleWidth<1690){
							g.setScaleX(0.2);
							g.setScaleY(0.2);
							g.setTranslateX(-115);
						}
					}else 
					{
						g.setScaleX(0.3);
						g.setScaleY(g.getScaleX());
					}
				}
			}
		}
	}

	private void redimensionneZoneJoueur(ZoneJoueur j) 
	{
		if(j.getPanelCentre()!=null && j.getPanelCentre().getChildren()!=null )
		{
			Dimension.getInstance().update();
			if(j.getPanelCentre().getChildren().size()==2){
				miseAJourScaleDos(j);
			}else if(j.getPanelCentre().getChildren().size()==3){
				miseAJourScaleMain(j);
			}
			j.redimensionJetonsZoneJoueur();
		}				
		redimensionneTaille(j);
	}


	private void miseAJourScaleDos(ZoneJoueur j) {
		j.getPanelCentre().getChildren().get(1).setScaleX(Dimension.getInstance().getScaleCartes());
		j.getPanelCentre().getChildren().get(1).setScaleY(Dimension.getInstance().getScaleCartes());
	}


	private void redimensionneTaille(ZoneJoueur j) {
		if(j!=listeZoneJoueur.get(4) && j!=listeZoneJoueur.get(9)){
			j.setPrefSize(tailleWidth/4, tailleHeight/3.3);
			j.setMaxSize(tailleWidth/4, (tailleHeight/3.3)-50);
		}else
		{
			j.setPrefWidth((tailleWidth/4)-10);
			j.setPrefHeight(tailleHeight-((tailleHeight/2)));
			j.setMaxWidth((tailleWidth/4)-10);
			j.setMaxHeight(tailleHeight-((tailleHeight/2)));
		}
	}

	private void miseAJourScaleMain(ZoneJoueur j) {

		AnchorPane pane=(AnchorPane)j.getPanelCentre().getChildren().get(1);
		pane.getChildren().get(0).setScaleX(Dimension.getInstance().getScaleCartes());
		pane.getChildren().get(0).setScaleY(Dimension.getInstance().getScaleCartes());
		pane.getChildren().get(0).setTranslateY(Dimension.getInstance().getTranslateYMainCarte());
		pane.getChildren().get(0).setTranslateX(Dimension.getInstance().getTranslateXMainCarte1());
		pane=(AnchorPane)j.getPanelCentre().getChildren().get(2);
		pane.getChildren().get(0).setScaleX(Dimension.getInstance().getScaleCartes());
		pane.getChildren().get(0).setScaleY(Dimension.getInstance().getScaleCartes());
		pane.getChildren().get(0).setTranslateY(Dimension.getInstance().getTranslateYMainCarte());
		pane.getChildren().get(0).setTranslateX(Dimension.getInstance().getTranslateXMainCarte2());
	}			




	private void creerListeZoneJoueur() {
		listeZoneJoueur=new ArrayList<>();
		for(int i=0;i<10;i++){
			ZoneJoueur zoneJoueur=new ZoneJoueur(i);
			listeZoneJoueur.add(zoneJoueur);
		}

	}

	private void placerComposants() {
		this.setTop(pHaut);
		this.setRight(pDroite);
		this.setBottom(pBas);
		this.setLeft(pGauche);
		afficherChargement();
	}

	public void afficherChargement() {
		pMilieuChargement = null;
		pMilieuBouton = null;
		pMilieuChargement=new PanelChargement();
		pMilieuChargement.setOnMouseEntered(new ActionAfficheBoutonPourInfo(1));
		pMilieuChargement.setOnMouseExited(new ActionEffacerBoutonZoneMilieu(1));
		pMilieuChargement.setPrefSize(tailleWidth/2, tailleHeight/3);
		this.setCenter(pMilieuChargement);		
	}

	public void creerPanelCentre(){
		pMilieuCarte=new ZoneMilieu();
	}

	private void creerPanelGauche() {
		pGauche=new VBox();
		pGauche.getChildren().add(listeZoneJoueur.get(4));
		pGauche.setRotate(90);
	}
	private void creerPanelBas() {
		pBas=new HBox();
		for(int i=3;i>=0;i--){
			pBas.getChildren().add(listeZoneJoueur.get(i));			
		}

	}
	private void creerPanelDroite() {
		pDroite=new VBox();
		pDroite.getChildren().add(listeZoneJoueur.get(9));
		pDroite.setRotate(-90);
	}
	private void creerPanelHaut() {
		pHaut=new HBox();
		for(int i=5;i<9;i++){
			pHaut.getChildren().add(listeZoneJoueur.get(i));
			pHaut.getChildren().get(i-5).setRotate(180);;
		}


	}

	public void afficheCarteMilieu(int i, AnchorPane carte) {
		try{
			pMilieuCarte.getListeZoneCarte().get(i).getChildren().add(carte);
		}catch(IllegalStateException e){
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					pMilieuCarte.getListeZoneCarte().get(i).getChildren().add(carte);
				}			                                      
			});
		}		
	}


	public void afficherPanelBoutonLancer(int mode){
		pMilieuChargement = null;
		pMilieuBouton = null;
		pMilieuBouton=new PanelBoutonLancer(tailleWidth/2, tailleHeight/3);

		if(mode == 0)
		{
			pMilieuBouton.boutonLancerPartie();
		}
		else 
		{
			pMilieuBouton.boutonLancerJeu();
		}
		this.setCenter(pMilieuBouton);
	}

	public void afficherPanelCarte() {
		this.setCenter(pMilieuCarte);
	}
	public void afficherMenu(int mode) {
		pMiMenuPlateau=new PanelMenuPlateau(pMilieuCarte, this.stage,mode);
		this.setCenter(pMiMenuPlateau);

	}

	public void afficherGagnant(Joueur joueur) {
		Platform.runLater(new Runnable() {

			@Override
			public void run() {
				Partie.getInstance().effaceBlind();
			}
		});

		pMiAfficheGagnant=new PanelAfficheGagnant(PlateauDeJeu.getInstance().getListeZoneJoueur().get(joueur.getEmplacement()),stage);
		PlateauDeJeu.getInstance().getListeZoneJoueur().get(joueur.getEmplacement()).reinitialise();

		this.setCenter(pMiAfficheGagnant);


	}


	public void changerBlinds(int indexJoueurQuiAPayePetite){

		int emplacementPetiteBlind = Partie.getInstance().getListeJoueur().get(indexJoueurQuiAPayePetite).getEmplacement();
		listeZoneJoueur.get(emplacementPetiteBlind).getImagePetiteBlind().setVisible(true);

		int emplacementGrosseBlind = 0;

		if(indexJoueurQuiAPayePetite + 1 >= Partie.getInstance().getListeJoueur().size())
		{
			emplacementGrosseBlind = Partie.getInstance().getListeJoueur().get(indexJoueurQuiAPayePetite + 1 - Partie.getInstance().getListeJoueur().size()).getEmplacement();

			listeZoneJoueur.get(emplacementGrosseBlind).getImageGrosseBlind().setVisible(true);
		}
		else{
			emplacementGrosseBlind = Partie.getInstance().getListeJoueur().get(indexJoueurQuiAPayePetite + 1).getEmplacement();

			listeZoneJoueur.get(emplacementGrosseBlind).getImageGrosseBlind().setVisible(true);
		}
	}


	public int verifieSiJoueurDansZone()
	{
		int emplacement = 0;
		for(ZoneJoueur zj :listeZoneJoueur)
		{
			if(zj.isEstvide())
			{
				return zj.getNumeroZone();
			}
			else{
				emplacement = emplacement + 1;
			}
		}
		return emplacement;
	}

	public void reinitialise() {
		instance = null;
	}

	public void setWindowWidth(double newValue, double oldValue) {
		this.setWidth(newValue);
		tailleWidth=newValue;
		setOldTailleW(oldValue);
		redimensionPanel();		
	}


	public void setWindowHeight(double newValue, double oldValue) {		
		this.setHeight(newValue);
		tailleHeight=newValue;
		setOldTailleH(oldValue);
		redimensionPanel();

	}


	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public ZoneMilieu getpMilieuCarte() {
		return pMilieuCarte;
	}


	public Stage getStage() {
		return stage;
	}


	public void setpMilieuCarte(ZoneMilieu pMilieuCarte) {
		this.pMilieuCarte = pMilieuCarte;
	}


	public ArrayList<ZoneJoueur> getListeZoneJoueur() {
		return listeZoneJoueur;
	}


	public void setListeZoneJoueur(ArrayList<ZoneJoueur> listeZoneJoueur) {
		this.listeZoneJoueur = listeZoneJoueur;
	}
	public Label getLb() {
		return lb;
	}


	public void setLb(Label lb) {
		this.lb = lb;
	}


	public double getOldTailleH() {
		return oldTailleH;
	}


	public void setOldTailleH(double oldTailleH) {
		this.oldTailleH = oldTailleH;
	}


	public double getOldTailleW() {
		return oldTailleW;
	}


	public void setOldTailleW(double oldTailleW) {
		this.oldTailleW = oldTailleW;
	}



	public void distribuerCarte(ArrayList<Joueur> arrayList) {
		for(Joueur j:arrayList){
			int pos=j.getEmplacement();
			PlateauDeJeu.getInstance().getpMilieuCarte().initialiseCarteDos();
			TranslateTransition tr=new TranslateTransition();
			RotateTransition ro=new RotateTransition(Duration.millis(1400), PlateauDeJeu.getInstance().getpMilieuCarte().getCarteDos());
			ro.setByAngle(360);
			double posX=0;
			double posY=0;
			if(pos<4){
				posY=tailleHeight-(tailleHeight/3);
				posX=tailleWidth-(tailleWidth*0.50)-475*(pos+1);
			}
			else if (pos==4) {
				posY=0;
				posX=-(tailleWidth-(tailleWidth/4));
			}
			else if(pos==9){
				posY=0;
				posX=(tailleWidth-(tailleWidth/3));
			}
			else{
				posY=-(tailleHeight-(tailleHeight/3));
				int distance=-(-9+pos);
				posX=tailleWidth-(tailleWidth*0.50)-475*(pos+distance);
			}		
			tr.setToX(0);
			tr.setToX(posX);
			tr.setToY(0);
			tr.setToY(posY);
			tr.setDuration(Duration.millis(700));
			tr.setNode(PlateauDeJeu.getInstance().getpMilieuCarte().getCarteDos());
			tr.setCycleCount(2);
			tr.play();		
			ro.play();
		}

	}


	public PanelChargement getpMilieuChargement() {
		return pMilieuChargement;
	}


	public void setpMilieuChargement(PanelChargement pMilieuChargement) {
		this.pMilieuChargement = pMilieuChargement;
	}


	public HBox getpHaut() {
		return pHaut;
	}


	public void setpHaut(HBox pHaut) {
		this.pHaut = pHaut;
	}


	public HBox getpBas() {
		return pBas;
	}


	public void setpBas(HBox pBas) {
		this.pBas = pBas;
	}


	public VBox getpDroite() {
		return pDroite;
	}


	public void setpDroite(VBox pDroite) {
		this.pDroite = pDroite;
	}


	public VBox getpGauche() {
		return pGauche;
	}


	public void setpGauche(VBox pGauche) {
		this.pGauche = pGauche;
	}


	public PanelBoutonLancer getpMilieuBouton() {
		return pMilieuBouton;
	}


	public void setpMilieuBouton(PanelBoutonLancer pMilieuBouton) {
		this.pMilieuBouton = pMilieuBouton;
	}


	public PanelMenuPlateau getpMiMenuPlateau() {
		return pMiMenuPlateau;
	}


	public void setpMiMenuPlateau(PanelMenuPlateau pMiMenuPlateau) {
		this.pMiMenuPlateau = pMiMenuPlateau;
	}


	public PanelAfficheGagnant getpMiAfficheGagnant() {
		return pMiAfficheGagnant;
	}


	public void setpMiAfficheGagnant(PanelAfficheGagnant pMiAfficheGagnant) {
		this.pMiAfficheGagnant = pMiAfficheGagnant;
	}


	public double getTailleWidth() {
		return tailleWidth;
	}


	public void setTailleWidth(double tailleWidth) {
		this.tailleWidth = tailleWidth;
	}


	public double getTailleHeight() {
		return tailleHeight;
	}


	public void setTailleHeight(double tailleHeight) {
		this.tailleHeight = tailleHeight;
	}



}
