package ihm.vue.plateau;

import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import application.MainApp;
import application.metier.Carte;

/**
 * permet de recuperer une image d'une carte ou d'un jeton
 * @author J�r�my
 *
 */
public class RecupereImageFXML {

	public AnchorPane recupereImageFXMLCarte(Carte c)
	{
		AnchorPane anchor=new AnchorPane();
		try{
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainApp.class.getResource(c.getImage()));
			Group carte = (Group) loader.load();
			anchor = Dimension.getInstance().redefinirTailleCarte(carte,anchor,Dimension.getInstance().getScaleCartes());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return anchor;
	}
	public Image recupereGif() {
		return new Image(MainApp.class.getResourceAsStream("../ressources/jeton/140.GIF"));
	}
}
