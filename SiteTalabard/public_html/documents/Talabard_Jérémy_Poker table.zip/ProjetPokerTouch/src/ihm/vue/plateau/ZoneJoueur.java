package ihm.vue.plateau;

import java.io.IOException;

import javafx.animation.FadeTransition;
import javafx.animation.RotateTransition;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import application.MainApp;
import application.dataloader.ParserJeton;
import application.metier.Joueur;

public class ZoneJoueur extends BorderPane {

	private Label pseudo;
	private Label argent;

	private Label mise;
	private VBox panelBasPseudoSomme;
	private HBox panelHautImages;
	private HBox panelMiseJoueur;
	private HBox panelArgentJoueur;
	private ImageView imageGrosseBlind;
	private ImageView imagePetiteBlind;
	private HBox panelCentre;
	private HBox panelJetons;

	private int numeroZone;
	private boolean estvide;


	public ZoneJoueur(int i ) {
		this.numeroZone = i;
		estvide = true;
	}

	private void creerPanelNomSomme() {
		panelBasPseudoSomme =new VBox();
		panelBasPseudoSomme.setAlignment(Pos.CENTER);
		creerImages();
		HBox.setMargin(pseudo, new Insets(0,10,0,0));
		HBox.setMargin(imageGrosseBlind, new Insets(0,10,0,0));
		HBox.setMargin(imagePetiteBlind, new Insets(0,10,0,0));
		this.setBottom(panelBasPseudoSomme);
		BorderPane.setMargin(panelBasPseudoSomme, new Insets(0,0,5,0));
		if(numeroZone==4 || numeroZone==9){
			BorderPane.setMargin(panelBasPseudoSomme, new Insets(0,0,40,0));
		}else{
			BorderPane.setMargin(panelBasPseudoSomme, new Insets(0,0,5,0));

		}
	}

	private void creerImages() {
		panelHautImages=new HBox();
		panelHautImages.setPrefWidth(600);
		panelHautImages.setAlignment(Pos.CENTER_RIGHT);
		Image image=new Image("/ressources/jeton/GP.png");
		imageGrosseBlind = creerImageBlind(image,imageGrosseBlind);
		image=new Image("/ressources/jeton/PB.png");
		imagePetiteBlind = creerImageBlind(image,imagePetiteBlind);
		this.setTop(panelHautImages);
	}

	private ImageView creerImageBlind(Image image, ImageView imageview) {
		imageview=new ImageView();
		imageview.setImage(image);
		imageview.setFitHeight(30);
		imageview.setPreserveRatio(true);
		imageview.setVisible(false);
		return imageview;
	}

	private void creerPanelCentre()
	{
		panelCentre = new HBox();
		panelCentre.setAlignment(Pos.BOTTOM_LEFT);
		if(numeroZone>4 && numeroZone<9){
			panelCentre.setRotate(-180);
		}	
		this.setCenter(panelCentre);
	}

	private void placerComposant(Joueur j) {
		panelBasPseudoSomme.getChildren().add(pseudo);
		panelBasPseudoSomme.getChildren().add(creerPanelDesSommes());
		panelHautImages.getChildren().add(0,imageGrosseBlind);
		panelHautImages.getChildren().add(1,imagePetiteBlind);
		mettreAJourJeton(j);
	}


	private HBox creerPanelDesSommes() {
		HBox panelDesSommes=new HBox();
		panelDesSommes.setAlignment(Pos.CENTER);
		creerPanelArgentJoueur();
		creerPanelMiseJoueur();
		panelDesSommes.getChildren().add(panelArgentJoueur);
		panelDesSommes.getChildren().add(panelMiseJoueur);
		return panelDesSommes;
	}

	private void creerPanelMiseJoueur() {
		panelMiseJoueur=new HBox();
		panelMiseJoueur.setAlignment(Pos.CENTER);
		panelMiseJoueur.setMinWidth((this.getWidth()/2)-60);
		panelMiseJoueur.setMaxHeight(20);
		panelMiseJoueur.getStyleClass().add("zoneMiseJoueur");
		Label mise=new Label(" Mise : ");
		mise.getStyleClass().add("lbMiseJoueur");
		panelMiseJoueur.getChildren().add(mise);
		panelMiseJoueur.getChildren().add(this.mise);
	}

	private void creerPanelArgentJoueur() {
		panelArgentJoueur=new HBox();
		panelArgentJoueur.setAlignment(Pos.CENTER);
		panelArgentJoueur.setMinWidth((this.getWidth()/2)-60);
		panelArgentJoueur.setMaxHeight(20);
		panelArgentJoueur.getStyleClass().add("zoneArgentJoueur");
		Label argent=new Label("Argent : ");
		argent.getStyleClass().add("lbArgentJoueur");
		panelArgentJoueur.getChildren().add(argent);
		panelArgentJoueur.getChildren().add(this.argent);
	}

	private AnchorPane redefinirTailleCarte(Group carte, AnchorPane anchor,int i) {
		Dimension.getInstance().update();
		carte.setScaleX(Dimension.getInstance().getScaleCartes());
		carte.setScaleY(carte.getScaleX());
		anchor.setPrefSize(1, 1);
		anchor.setMinSize(Control.USE_PREF_SIZE, Control.USE_PREF_SIZE);
		anchor.setMaxSize(Control.USE_PREF_SIZE, Control.USE_PREF_SIZE);
		if( i==0)
		{
			carte.setTranslateX(Dimension.getInstance().getTranslateXMainCarte1());
		}
		else{
			carte.setTranslateX(Dimension.getInstance().getTranslateXMainCarte2());
		}
		carte.setTranslateY(Dimension.getInstance().getTranslateYMainCarte());
		return anchor;
	}

	private AnchorPane chargeCarteDos(AnchorPane cartes) {
		System.out.println("affiche carte");
		String path=new String("../ressources/carte/backCouche.fxml");
		FXMLLoader loader=new FXMLLoader(MainApp.class.getResource(path));
		try {
			cartes=(AnchorPane)loader.load();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return cartes;
	}

	private AnchorPane changeTailleCarte(AnchorPane cartes) {
		cartes.setScaleX(Dimension.getInstance().getScaleCartes());
		cartes.setScaleY(Dimension.getInstance().getScaleCartes());
		cartes.setMinWidth(60);
		cartes.setPrefWidth(30);
		cartes.setPrefHeight(5);
		return cartes;
	}

	private void changeLayoutCarte(AnchorPane cartes) {
		cartes.getChildren().get(0).setLayoutX(300);
		cartes.getChildren().get(1).setLayoutX(300);
	}

	private void desafficherCartes() {
		if(panelCentre.getChildren().size()>1){
			panelCentre.getChildren().remove(1);
		}
	}

	private void chargePile(Joueur j) {
		AnchorPane jeton = null;
		jeton = chargePileJeton(j, jeton);
		Dimension.getInstance().update();
		modifieTailleJeton(jeton);			
		panelCentre.getChildren().add(jeton);
	}

	private AnchorPane chargePileJeton(Joueur j, AnchorPane jeton) {
		int emplacement=j.getEmplacement();
		String path=new String("../ressources/jeton/pileJetonsJoueur_"+emplacement+".fxml");
		FXMLLoader loader=new FXMLLoader(MainApp.class.getResource(path));
		try {
			jeton=(AnchorPane)loader.load();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return jeton;
	}

	private void modifieTailleJeton(AnchorPane jeton) {
		redimensionneJeton(jeton);
		jeton.setPrefHeight(5);
	}

	private void mettreAJourLabelArgentJoueur(Joueur j) {
		PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).setArgent(String.valueOf(j.getListeJeton().retourneMontant()));
		PlateauDeJeu.getInstance().getListeZoneJoueur().get(j.getEmplacement()).getMise().setText(String.valueOf(j.getListeJetonMise().retourneMontant()));
	}

	private AnchorPane modifieDimendionPile(AnchorPane zoneMiseAnchorPane) {
		zoneMiseAnchorPane.setScaleX(Dimension.getInstance().getScaleJetons());
		zoneMiseAnchorPane.setScaleY(Dimension.getInstance().getScaleJetons());
		zoneMiseAnchorPane.setPrefWidth(150);
		zoneMiseAnchorPane.setPrefHeight(5);
		return zoneMiseAnchorPane;
	}

	private AnchorPane chargesPileMise(Joueur j, AnchorPane zoneMiseAnchorPane) {
		String path=new String("../ressources/jeton/pileJetonsMises_"+j.getEmplacement()+".fxml");
		FXMLLoader loader=new FXMLLoader(MainApp.class.getResource(path));
		try {
			zoneMiseAnchorPane=(AnchorPane)loader.load();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return zoneMiseAnchorPane;
	}

	private void initialise(Joueur j) {
		pseudo = new Label();	
		pseudo.getStyleClass().add("lbJoueurPlateau");
		argent = new Label();
		argent.getStyleClass().add("lbArgentJoueur");
		mise=new Label();
		mise.getStyleClass().add("lbMiseJoueur");
		argent.setText(String.valueOf(j.getListeJeton().retourneMontant()));
		pseudo.setText(j.getPseudo());
		mise.setText(String.valueOf(j.getListeJetonMise().retourneMontant()));
	}

	private AnchorPane redimensionneJeton(AnchorPane jeton) {
		jeton.setScaleX(Dimension.getInstance().getScaleJetons());
		jeton.setScaleY(Dimension.getInstance().getScaleJetons());
		jeton.setMinWidth(Dimension.getInstance().getLargeurEntreJetons());
		jeton.setPrefWidth(Dimension.getInstance().getLargeurEntreJetons());
		return jeton;
	}

	public void mettreAjourZone(Joueur j)
	{
		initialise(j);
		creerPanelNomSomme();
		creerPanelCentre();
		placerComposant(j);
		estvide=false;

	}

	public void afficherCartesDos() {

		desafficherCartes();
		AnchorPane cartes=null;
		cartes = chargeCarteDos(cartes);
		changeLayoutCarte(cartes);
		Dimension.getInstance().update();
		cartes = changeTailleCarte(cartes);
		RotateTransition rotate=creerRotation(cartes);
		TranslateTransition translate=creerTranslate(cartes);
		translate.play();
		rotate.play();
		panelCentre.getChildren().add(cartes);

	}

	private RotateTransition creerRotation(AnchorPane cartes) {
		RotateTransition ro=new RotateTransition(Duration.millis(1000), cartes);
		ro.setByAngle(360);
		return ro;
	}

	private TranslateTransition creerTranslate(AnchorPane cartes) {
		TranslateTransition tr=new TranslateTransition();
		tr.setFromY(300);
		tr.setToY(0);
		tr.setDuration(Duration.millis(1000));
		tr.setNode(cartes);
		return tr;
	}

	public void afficherMainJoueur(Joueur j){
		for (int i=0;i<2;i++){
			Group carte=null;
			String path=j.getMainJoueur().getListeCarte().get(i).getImage();			
			FXMLLoader loader=new FXMLLoader(MainApp.class.getResource(path));
			try {
				carte=(Group)loader.load();
				//carte.setLayoutY(100);
			} catch (IOException e) {
				e.printStackTrace();
			}
			AnchorPane anchor = new AnchorPane();

			anchor = redefinirTailleCarte(carte,anchor,i);
			anchor.getChildren().add(carte);
			RotateTransition rotate=creerRotation(anchor);
			TranslateTransition translate=creerTranslate(anchor);
			rotate.play();
			translate.play();
			panelCentre.getChildren().add(anchor);			
		}
	}

	public void mettreAJourJeton(Joueur j) 
	{
		effacerPanelCentre();
		mettreAJourLabelArgentJoueur(j);
		ParserJeton paseur=new ParserJeton();
		paseur.mettreAJourDocumentJeton(j);		
		chargePile(j);
	}

	public void effacerPanelCentre() {
		if(panelCentre.getChildren().size()>0)
		{
			panelCentre.getChildren().clear();
		}
	}

	public void effaceWinner()
	{
		this.getStyleClass().clear();
	}
	public void afficherWinner()
	{
		this.getStyleClass().add("zoneJoueurGagnant");
		final FadeTransition fade = new FadeTransition(Duration.millis(300),this);
		fade.setFromValue(1.0);
		fade.setToValue(0);
		fade.setCycleCount(10);
		fade.setAutoReverse(true);
		fade.play();

	}

	public void creerZoneMise(Joueur j) {
		effaceChildrenPanelHautImages();
		AnchorPane zoneMiseAnchorPane=null;

		zoneMiseAnchorPane = chargesPileMise(j, zoneMiseAnchorPane);
		zoneMiseAnchorPane = modifieDimendionPile(zoneMiseAnchorPane);		
		if(numeroZone>4 && numeroZone<9){
			zoneMiseAnchorPane.setRotate(-180);
		}		
		panelHautImages.getChildren().add(0, zoneMiseAnchorPane);
	}

	public void effaceChildrenPanelHautImages() {
		if(panelHautImages.getChildren().size()>2)
		{
			panelHautImages.getChildren().remove(0);
		}
	}

	public void reinitialise()
	{
		this.getChildren().removeAll(this.getChildren());
		this.getStyleClass().clear();
		estvide = true;
	}

	public void redimensionJetonsZoneJoueur() {
		AnchorPane jeton=(AnchorPane)panelCentre.getChildren().get(0); 
		jeton.setScaleX(Dimension.getInstance().getScaleJetons());
		jeton.setScaleY(Dimension.getInstance().getScaleJetons());
		jeton.setMinWidth(Dimension.getInstance().getLargeurEntreJetons());
		jeton.setPrefWidth(Dimension.getInstance().getLargeurEntreJetons());
		if(panelHautImages.getChildren().size()>2){
			panelHautImages.getChildren().get(0).setScaleX(Dimension.getInstance().getScaleJetons());
			panelHautImages.getChildren().get(0).setScaleY(Dimension.getInstance().getScaleJetons());
		}

	}

	public void redimensionPanelBas(double taille){
		panelArgentJoueur.setMinWidth((taille/2)-50);
		panelMiseJoueur.setMinWidth((taille/2)-50);
	}

	public HBox getPanelJetons() {
		return panelJetons;
	}

	public void setPanelJetons(HBox panelJetons) {
		this.panelJetons = panelJetons;
	}

	public Label getPseudo() {
		return pseudo;
	}

	public void setPseudo(String pseudo) {
		this.pseudo.setText(pseudo);
	}

	public ImageView getImageGrosseBlind() {
		return imageGrosseBlind;
	}

	public ImageView getImagePetiteBlind() {
		return imagePetiteBlind;
	}

	public void setImageGrosseBlind(ImageView imageGrosseBlind) {
		this.imageGrosseBlind = imageGrosseBlind;
	}

	public void setImagePetiteBlind(ImageView imagePetiteBlind) {
		this.imagePetiteBlind = imagePetiteBlind;
	}

	public boolean isEstvide() {
		return estvide;
	}

	public void setEstvide(boolean estvide) {
		this.estvide = estvide;
	}

	public int getNumeroZone() {
		return numeroZone;
	}

	public void setNumeroZone(int numeroZone) {
		this.numeroZone = numeroZone;
	}

	public HBox getPanelCentre() {
		return panelCentre;
	}

	public void setPanelCentre(HBox panelCentre) {
		this.panelCentre = panelCentre;
	}

	public Label getArgent() {
		return argent;
	}

	public void setArgent(String argent) {
		this.argent.setText(argent);	
	}

	public Label getMise() {
		return mise;
	}

	public void setMise(Label mise) {
		this.mise = mise;
	}

	public VBox getPanelBasPseudoSomme() {
		return panelBasPseudoSomme;
	}

	public void setPanelBasPseudoSomme(VBox panelBasPseudoSomme) {
		this.panelBasPseudoSomme = panelBasPseudoSomme;
	}

	public void animerZone() {
		TranslateTransition tr=new TranslateTransition(Duration.millis(1000),this);
		tr.setFromY(200);
		tr.setToY(0);
		FadeTransition transition=new FadeTransition(Duration.millis(1000), this);
		transition.setFromValue(0);
		transition.setToValue(1);
		transition.play();
		tr.play();
	}

	public HBox getPanelHautImages() {
		return panelHautImages;
	}

	public void setPanelHautImages(HBox panelHautImages) {
		this.panelHautImages = panelHautImages;
	}

	public HBox getPanelMiseJoueur() {
		return panelMiseJoueur;
	}

	public void setPanelMiseJoueur(HBox panelMiseJoueur) {
		this.panelMiseJoueur = panelMiseJoueur;
	}

	public HBox getPanelArgentJoueur() {
		return panelArgentJoueur;
	}

	public void setPanelArgentJoueur(HBox panelArgentJoueur) {
		this.panelArgentJoueur = panelArgentJoueur;
	}

	public void setPseudo(Label pseudo) {
		this.pseudo = pseudo;
	}

	public void setArgent(Label argent) {
		this.argent = argent;
	}

}
