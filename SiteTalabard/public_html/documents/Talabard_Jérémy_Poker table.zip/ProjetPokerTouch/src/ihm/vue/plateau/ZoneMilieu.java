package ihm.vue.plateau;

import ihm.controleur.action_table.affichage.ActionAfficheBoutonPourInfo;
import ihm.controleur.action_table.affichage.ActionAfficherMenu;
import ihm.controleur.action_table.affichage.ActionEffacerBoutonZoneMilieu;

import java.io.IOException;
import java.util.ArrayList;

import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import application.MainApp;
import application.dataloader.ParserJeton;
import application.modele.ListeJeton;

public class ZoneMilieu extends BorderPane{

	private Button menu;
	private Group carteDos;
	private HBox pHaut;
	private HBox pCentre;
	private HBox zonePot;
	private Label lbmontantPot;
	private Label montantPot;
	private ArrayList<AnchorPane> listeZoneCarte;
	private ArrayList<Group> listeDesCartes;
	
	public void setListeZoneCarte(ArrayList<AnchorPane> listeZoneCarte) {
		this.listeZoneCarte = listeZoneCarte;
	}

	private void initialise() {
		creerPanelCentre();
		creerPanelHaut();
		ajouterCartes();
		placerComposants();
		lbmontantPot=new Label("POT :");
		lbmontantPot.getStyleClass().add("lbJoueurPlateau");
		montantPot=new Label("");
		montantPot.getStyleClass().add("lbJoueurPlateau");
		
	}
	
	public void initialiseCarteDos(){
		AnchorPane anchor=new AnchorPane();
		carteDos=null;
		FXMLLoader loader=new FXMLLoader(getClass().getResource("/ressources/carte/backPoker.fxml"));
		try {
			carteDos = (Group)loader.load();
			listeDesCartes.add(carteDos);
		} catch (IOException e) {
			e.printStackTrace();
		}
		listeZoneCarte.get(5).getChildren().add(anchor);
		anchor = redimensionneCarte(anchor, carteDos);
		anchor.setPrefSize(0, 0);
		anchor.setVisible(true);
	}
	
	public void remettrePositionCarteDos(){
		carteDos.setLayoutX(0);
		carteDos.setLayoutY(0);
	}
	
	private void ajouterCartes() {
		listeDesCartes=new ArrayList<>();
		for (int i=0;i<6;i++){
			AnchorPane anchor=new AnchorPane();
			if(i<5){
				int pos=i+8;
				Group group = chargeCarte(pos);	
				anchor = redimensionneCarte(anchor, group);
				anchor.setVisible(false);
			}else{
				Group group = null;
				FXMLLoader loader=new FXMLLoader(getClass().getResource("/ressources/carte/backPoker.fxml"));
				try {
					group = (Group)loader.load();
					listeDesCartes.add(group);
				} catch (IOException e) {
					e.printStackTrace();
				}
				anchor = redimensionneCarte(anchor, group);
				anchor.setVisible(true);
			}
			
			listeZoneCarte.get(i).getChildren().add(anchor);
		}
		
	}


	private AnchorPane redimensionneCarte(AnchorPane anchor, Group group) {
		Dimension.getInstance().update();
		group.setScaleX(Dimension.getInstance().getScaleCartes());
		group.setScaleY(group.getScaleX());
		group.setTranslateX(-85);
		group.setTranslateY(-120);
		anchor.setPrefSize(1, 1);
		anchor.setMinSize(Control.USE_PREF_SIZE, Control.USE_PREF_SIZE);
		anchor.setMaxSize(Control.USE_PREF_SIZE, Control.USE_PREF_SIZE);
		anchor.getChildren().add(group);
		return anchor;
	}

	private Group chargeCarte(int pos) {
		FXMLLoader loader=new FXMLLoader(getClass().getResource("/ressources/carte/pique_"+pos+".fxml"));
		Group group=null;
		try {
			group = (Group)loader.load();
			listeDesCartes.add(group);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return group;
	}

	private AnchorPane recupererImagePot() {
		AnchorPane panel=null;
		String path=new String("../ressources/jeton/potPrincipal.fxml");
		FXMLLoader loader=new FXMLLoader(MainApp.class.getResource(path));
		try {
			panel=(AnchorPane)loader.load();
		} catch (IOException e) {
			e.printStackTrace();
		}
		Dimension.getInstance().update();
		panel.setScaleX(Dimension.getInstance().getScaleJetons());
		panel.setScaleY(Dimension.getInstance().getScaleJetons());
		panel.setMinWidth(Dimension.getInstance().getLargeurEntreJetons());
		panel.setPrefWidth(Dimension.getInstance().getLargeurEntreJetons());
		panel.setPrefHeight(5);		
		return panel;
	}

	private FlowPane creerZoneLabelPot() {
		FlowPane pot=new FlowPane();
		pot.getChildren().add(lbmontantPot);
		pot.getChildren().add(montantPot);
		return pot;
	}

	private void creerPanelHaut() {
		pHaut =new HBox();
		pHaut.setAlignment(Pos.CENTER);
		Label lb=new Label("Menu");
		lb.getStyleClass().add("labelMenu");
		menu=new Button(null,lb);
		menu.setOnAction(new ActionAfficherMenu(0));
		menu.getStyleClass().add("boutonChoix");
		pHaut.getChildren().add(menu);
		
	}

	private void placerComposants() {
		this.setCenter(pCentre);
		this.setTop(pHaut);
		
	}

	private void creerPanelCentre() {
		pCentre=new HBox();
		pCentre.setAlignment(Pos.CENTER);
		listeZoneCarte=new ArrayList<>();
		
		for (int i=0;i<6;i++){
			AnchorPane panel=new AnchorPane();
			panel.setPrefSize(300*0.4+30, 440*0.4);
			
			listeZoneCarte.add(panel);
			
			pCentre.getChildren().add(listeZoneCarte.get(i));
		}
		modifieMargin();
		
	}

	private void modifieMargin() {
		HBox.setMargin(listeZoneCarte.get(0), new Insets(50,10,60,100));
		HBox.setMargin(listeZoneCarte.get(1), new Insets(50,10,60,10));
		HBox.setMargin(listeZoneCarte.get(2), new Insets(50,10,60,10));
		HBox.setMargin(listeZoneCarte.get(3), new Insets(50,10,60,10));
		HBox.setMargin(listeZoneCarte.get(4), new Insets(50,70,60,10));
		HBox.setMargin(listeZoneCarte.get(5), new Insets(50,100,60,10));
	}

	public ZoneMilieu() {
		this.getStyleClass().add("zoneMilieu");
		initialise();
		this.setOnMouseEntered(new ActionAfficheBoutonPourInfo(0));
		this.setOnMouseExited(new ActionEffacerBoutonZoneMilieu(0));
	}

	public void mettreAJourZonePot(ListeJeton map) {
		zonePot =new HBox();
		zonePot.setAlignment(Pos.CENTER);
		zonePot.getChildren().add(creerZoneLabelPot());
		this.montantPot.setText(String.valueOf(map.retourneMontant()));
		ParserJeton parser=new ParserJeton();
		parser.mettreAJourDocumentPotPrincipal(map);
		zonePot.getChildren().add(recupererImagePot());
		this.setBottom(zonePot);
	}

	public void changerMargin(double tailleHeight, double tailleWidth) {
		for (int i=0;i<5;i++){
			if (tailleHeight<920) {
				HBox.setMargin(listeZoneCarte.get(0), new Insets(0,10,0,100));
				HBox.setMargin(listeZoneCarte.get(1), new Insets(0,10,0,10));
				HBox.setMargin(listeZoneCarte.get(2), new Insets(0,10,0,10));
				HBox.setMargin(listeZoneCarte.get(3), new Insets(0,10,0,10));
				HBox.setMargin(listeZoneCarte.get(4), new Insets(0,70,0,10));
				HBox.setMargin(listeZoneCarte.get(5), new Insets(0,100,0,10));

			}
		}
		
	}

	public void afficheMenu() {
		menu.setVisible(true);
	}
	
	public ArrayList<Group> getListeDesCartes() {
		return listeDesCartes;
	}

	public void setListeDesCartes(ArrayList<Group> listeDesCartes) {
		this.listeDesCartes = listeDesCartes;
	}

	public ArrayList<AnchorPane> getListeZoneCarte() {
		return listeZoneCarte;
	}

	public Button getMenu() {
		return menu;
	}

	public void setMenu(Button menu) {
		this.menu = menu;
	}
	public Group getCarteDos() {
		return carteDos;
	}

	public void setCarteDos(Group carteDos) {
		this.carteDos = carteDos;
	}

	public void redimensionJetonPotPrincipal(){
		if(zonePot!=null){
			zonePot.getChildren().get(1).setScaleX(Dimension.getInstance().getScaleJetons());
			zonePot.getChildren().get(1).setScaleY(Dimension.getInstance().getScaleJetons());

		}
	}

	public HBox getZonePot() {
		return zonePot;
	}

	public void setZonePot(HBox zonePot) {
		this.zonePot = zonePot;
	}
	
	
}


