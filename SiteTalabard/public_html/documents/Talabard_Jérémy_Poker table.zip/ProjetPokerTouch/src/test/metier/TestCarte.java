package test.metier;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import application.metier.Carte;

public class TestCarte {

	private Carte carte;
	
	@Before
	public void TestConstructeurDefaut()
	{
		carte = new Carte();
		Assert.assertNotEquals(carte, null);
	}
	@Test
	public void testConstructeur()
	{
		Carte c = new Carte("couleur","nom", 1, "image");
		Assert.assertNotEquals(c, null);
	}
	
	@Test
	public void testGetterAndSetter()
	{
		carte.setCouleur("carreau");
		Assert.assertEquals("carreau", carte.getCouleur());
		
		carte.setImage("image");
		Assert.assertEquals("image", carte.getImage());
		
		carte.setNom("nom");
		Assert.assertEquals("nom", carte.getNom());
		
		carte.setValeur(0);
		Assert.assertEquals(0, carte.getValeur());
		
		
	}
	
	@Test
	public void testToString()
	{
		carte.setCouleur("carreau");
		carte.setValeur(0);
		
		Assert.assertEquals(carte.toString(), "carreau_0");
	}
	
	@Test
	public void testCompareTo()
	{
		carte.setValeur(0);
		Carte c = new Carte();
		c.setValeur(1);
		Assert.assertEquals(c.compareTo(carte), 0);
		
	}
}
