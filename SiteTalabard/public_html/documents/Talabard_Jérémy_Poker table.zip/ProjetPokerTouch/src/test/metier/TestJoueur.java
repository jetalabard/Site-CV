package test.metier;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import application.metier.Carte;
import application.metier.Joueur;
import application.metier.Valeur;

public class TestJoueur {

	
	private Joueur j;
	
	@Before
	public void testConstructeur()
	{
		j= new Joueur("pseudo");
		Assert.assertNotEquals(j,null);
		
	}
	
	@Test
	public void testGetterAndSetter()
	{
		
		
		j.setEmplacement(0);
		Assert.assertEquals(j.getEmplacement(),0);
		
		
		j.setMainJoueur(new Carte(), new Carte());
		
		Assert.assertNotEquals(j.getMainJoueur().donnePremiereCarte(), null);
		
		Assert.assertNotEquals(j.getMainJoueur().donneDeuxiemeCarte(), null);
		
		j.setPseudo("nom");
		Assert.assertEquals(j.getPseudo(),"nom");
		
		j.setValeur(new Valeur(5));
		Assert.assertNotEquals(j.getValeur(), null);
	}
}
