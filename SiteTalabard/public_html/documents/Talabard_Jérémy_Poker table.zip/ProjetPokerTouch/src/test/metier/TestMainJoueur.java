package test.metier;

import java.util.ArrayList;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import application.metier.Carte;
import application.metier.MainJoueur;

public class TestMainJoueur {

	private MainJoueur main;
	
	@Before
	public void testConstructeur()
	{
		main = new MainJoueur();
		Assert.assertNotEquals(main, null);
	}
	@Test
	public void testRemplirMain()
	{
		main.remplirMain(new Carte(), new Carte());
		Assert.assertNotEquals(main.donnePremiereCarte(), null);
		Assert.assertNotEquals(main.donneDeuxiemeCarte(), null);
	}
	
	@Test
	public void testReinitialiserMain()
	{
		main.reinitialiserMain();
		Assert.assertEquals(main.getListeCarte().size(), 0);
	}
	
	@Test
	public void testGetterSetter()
	{
		ArrayList<Carte> listeCarte = new ArrayList<Carte>();
		listeCarte.add(new Carte());
		main.setListeCarte(listeCarte);
		Assert.assertEquals(main.getListeCarte().size(), 1);
	}
}
