package test.metier;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import application.metier.Pot;

public class TestPot {

	private Pot pot;
	
	@Before
	public void testConstructeur()
	{
		pot = new Pot();
		Assert.assertNotEquals(pot, null);
	}
	
	@Test
	public void testReinitialisePot()
	{
		pot.reinitialisePot();
	}
	@Test
	public void testGetterSetter()
	{
	}
}
